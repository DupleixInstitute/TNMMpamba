
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<TITLE>CREDIT SCORING</TITLE>


<link href="btu.css" rel="stylesheet" type="text/css">



</HEAD>

<BODY BGCOLOR=#FFFFFF >
<font class="s_text">









<table width="760" border="0" align="center" cellpadding="0" cellspacing="0" class="bdr" >
  <tr>
    <td colspan="6" class="s_text"><table width="100%" border="0" cellspacing="0" cellpadding="0" >
      <tr>
        <td width="1286"><table width="770" height="165">
<td><img src="img1.gif" alt="nknk" name="g" width="385" height="208"/>&nbsp;</td>
<td><font color="#FFFFFF" size="16" face="Arial Narrow"><img src="img2.JPG" alt="nknk" name="g" width="385" height="208"/></font></td>
</table></td>


</tr>
<tr>
<td width="1286" align="CENTER" bgcolor="#000040" class="s_text"><font  color="#FFFFFF" size="7" face="Arial Narrow">CREDIT SCORING</font></td><tr>
      </tr>
   <table class="s_text" >
        <tr bgcolor="#ECF8FF" class="s_text"> 
          <td>
        <p></br> 
        <form ACTION="" name="FAILED1" method="post">
            <td><table><tr><td><p align="justify" class="s_text"><br>
<table class="s_text">
<tr><td><FONT class="btn" color="#FF0000"><strong><i>ERROR!</i>....THE CUSTOMER HAS NEVER BEEN SCORED..</BR>PLEASE CHECK THE NUMBER OF LOANS AND THE ID NUMBER</strong></font></td></tr>

</table>
   
 </table> 
</table>




</BODY>
</HTML>