function round(number,decimalPlaces)
{
    var factorOf10 = Math.pow(10,decimalPlaces);
    return Math.round(number * factorOf10) / factorOf10;
}

function ToNumber(nStr) 
{
	if   (typeof(nStr) == "undefined") {  return 0;}
	else  
		{
		if (nStr == "") {return 0};
		if (nStr != "") {return parseFloat(nStr.replace(/,/g,''))};
		} 
}  
function InitialiseClientData()
// The function is called by the Corporate Add Menu to clear data before a new client is added

{
		 InitialiseCompanyData();
		 InitialiseLoanData();
		 InitialiseIncomeStatement();
		 InitialiseCurrentAssets();
		 InitialiseNonCurrentAssets();
		 InitialiseCurrentLiabilities();
		 InitialiseNonCurrentLiabilities();
		 InitialiseEquity();
		 InitialiseManagementAnalysisForm();
		 InitialiseIndustryAnalysis();
	     InitialiseShareholderAnalysisForm();	
         InitialiseBenchmarkOverrideForm();	
         InitialiseProgressTracker();		 
}	
function InitialiseCompanyData()
{
	     localStorage.CIF                               = "";
		 localStorage.registration_year                 = "";
         localStorage.vat_reg_no                        = "";
		 localStorage.customer_type                     = "";  
         localStorage.legal_name                        = "";
         localStorage.trading_name                      = "";
         localStorage.registration_country              = "";
         localStorage.financial_year0                   = "";
         localStorage.financial_year1                   = "";
         localStorage.financial_year2                   = "";
         localStorage.financial_year3                   = "";
         localStorage.reporting_month_year0             = "";
         localStorage.reporting_month_year1             = "";
		 localStorage.reporting_month_year2             = "";
         localStorage.reporting_month_year3             = "";
         localStorage.audit_status_year0                = "";
         localStorage.audit_status_year1                = "";
		 localStorage.audit_status_year2                = "";
		 localStorage.audit_status_year3                = "";
		 localStorage.real_inflation_year0              = "";
		 localStorage.real_inflation_year1              = "";
         localStorage.real_inflation_year2              = "";
         localStorage.real_inflation_year3              = "";
         localStorage.nominal_inflation_year0           = "";
         localStorage.nominal_inflation_year1           = "";
         localStorage.nominal_inflation_year2           = "";
         localStorage.nominal_inflation_year3           = "";
         localStorage.industrial_sector                 = "";
         localStorage.borrower_present_address          = "";
         localStorage.street_name_and_number            = "";
         localStorage.years_at_present_address          = "";
         localStorage.e_mail                            = "";
         localStorage.bond_plot                         = "";
	     localStorage.location_of_acquired_real_estate  = "";
         localStorage.main_bank                         = "";
         localStorage.second_bank                       = "";
         localStorage.third_bank                        = "";
	
}

function InitialiseLoanData()
{
       localStorage.loan_type             = "";
       localStorage.loan_amount           = "";
       localStorage.property_type         = "";
       localStorage.open_market_value     = "";
       localStorage.loan_maturity         = "";
       localStorage.rate_type             = "";
       localStorage.irate                 = "";
       localStorage.insurance_replacement = "";
       localStorage.insurance_premium     = "";
       localStorage.loan_installment      = "";
       localStorage.loanandinsurance      = "";
       localStorage.ltv_policy            = "";
       localStorage.ltv                   = "";
       localStorage.rent                  = "";
       localStorage.relationship          = "";
       localStorage.Savings               = "";
       localStorage.Deposit               = "";
       localStorage.Share                 = "";
       localStorage.ST                    = "";
       localStorage.Mortgages             = "";
       localStorage.total_bbs_products    = "";
       localStorage.loan_arrears          = "";
       localStorage.renegotiate           = "";
       localStorage.why_renogotiation     = "";
       localStorage.LoanName1             = "";
       localStorage.LoanName2             = "";
       localStorage.LoanName3             = "";
       localStorage.LoanName4             = "";
       localStorage.LoanName5             = "";
       localStorage.LoanName6             = "";
       localStorage.LoanName7             = "";
       localStorage.LoanName8             = "";
       localStorage.LoanName9             = "";
       localStorage.LoanInstalment1       = "";
       localStorage.LoanInstalment2       = "";
       localStorage.LoanInstalment3       = "";
       localStorage.LoanInstalment4       = "";
       localStorage.LoanInstalment5       = "";
       localStorage.LoanInstalment6       = "";
       localStorage.LoanInstalment7       = "";
       localStorage.LoanInstalment8       = "";
       localStorage.LoanInstalment9       = "";
       localStorage.TotalInstalments      = "";
       localStorage.loans_outstanding     = "";
       localStorage.itc_ref               = "";
       localStorage.paid_debts            = "";
       localStorage.judgement             = "";
       localStorage.default_data          = "";
       localStorage.trace_alerts          = "";
       localStorage.blacklisted           = "";
       localStorage.fraud_alert           = "";
       localStorage.deduct                = "";
	
}
function InitialiseIncomeStatement()
{
		   //1. Net Sales
	       localStorage.NetSales0 = 0;
	       localStorage.NetSales1 = 0;
	       localStorage.NetSales2 = 0;    
		   localStorage.NetSales3 = 0;  
		  
		   //2. Cost of Sales - Depreciation  
		   localStorage.CosDep0 = 0;
 		   localStorage.CosDep1 = 0;
           localStorage.CosDep2 = 0;
		   localStorage.CosDep3 = 0;
		   
		   //3. Cost of Sales - Other
		   localStorage.CosOther0 = 0;
		   localStorage.CosOther1 = 0;
	       localStorage.CosOther2 = 0;
		   localStorage.CosOther3 = 0;
		   
		   //4. Other Income Line 1
		   localStorage.OtherIncomeLine1_0 =0;
		   localStorage.OtherIncomeLine1_1 =0;
	       localStorage.OtherIncomeLine1_2 =0;
		   localStorage.OtherIncomeLine1_3 =0;
		  
		   //5. Other Income Line 2
		   localStorage.OtherIncomeLine2_0 =0;
		   localStorage.OtherIncomeLine2_1 =0;
	       localStorage.OtherIncomeLine2_2 =0;
		   localStorage.OtherIncomeLine2_3 =0;
		   
		   //6. Other Income Line 3
		   localStorage.OtherIncomeLine3_0 =0;
 		   localStorage.OtherIncomeLine3_1 =0;
           localStorage.OtherIncomeLine3_2 =0;
		   localStorage.OtherIncomeLine3_3 =0;
		   
		   //7. Other Income Line 4
		   localStorage.OtherIncomeLine4_0 =0;
		   localStorage.OtherIncomeLine4_1 =0;
		   localStorage.OtherIncomeLine4_2 =0;
		   localStorage.OtherIncomeLine4_3 =0;
		   
		   //8. Opex Line - Staff Costs
		   localStorage.StaffCosts0 =0;
		   localStorage.StaffCosts1 =0;
		   localStorage.StaffCosts2 =0;
		   localStorage.StaffCosts3 =0;

		   //9. Opex Line - Directors Fees
		   localStorage.DirectorsFees0 =0;
		   localStorage.DirectorsFees1 =0;
		   localStorage.DirectorsFees2 =0;
		   localStorage.DirectorsFees3 =0;
		   
		   //10. Opex Line - Depreciation
		   localStorage.Depreciation0 =0;
		   localStorage.Depreciation1 =0;
		   localStorage.Depreciation2 =0;
		   localStorage.Depreciation3 =0;
		   
		   //11. Opex Line - Amortisation
		   localStorage.Amortisation0 =0;
		   localStorage.Amortisation1 =0;
		   localStorage.Amortisation2 =0;
		   localStorage.Amortisation3 =0;
		   
		   //12. Opex Line - NoNameOpex Line 1
		   localStorage.NoNameOpexLine1_0 =0;
		   localStorage.NoNameOpexLine1_1 =0;
		   localStorage.NoNameOpexLine1_2 =0;
		   localStorage.NoNameOpexLine1_3 =0;

           //13. Opex Line - NoNameOPex Line 2
		   localStorage.NoNameOpexLine2_0 =0;
		   localStorage.NoNameOpexLine2_1 =0;
	       localStorage.NoNameOpexLine2_2 =0;
		   localStorage.NoNameOpexLine2_3 =0;
		   
		   //14. Opex Line - Other
		   localStorage.OtherOpex0 =0;
		   localStorage.OtherOpex1 =0;
           localStorage.OtherOpex2 =0;
           localStorage.OtherOpex3 =0;
           
		   //15. Net Finance Costs
           localStorage.NetFinanceCosts0 =0;
           localStorage.NetFinanceCosts1 =0;
		   localStorage.NetFinanceCosts2 =0;
		   localStorage.NetFinanceCosts3 =0;
           
		   //16. Income Tax
           localStorage.IncomeTax0 =0;
           localStorage.IncomeTax1 =0;
		   localStorage.IncomeTax2 =0;
		   localStorage.IncomeTax3 =0;
           
		   //16. Deferred Tax
           localStorage.DeferredTax0 =0;
           localStorage.DeferredTax1 =0;
		   localStorage.DeferredTax2 =0;
		   localStorage.DeferredTax3 =0;
				   
           //17. Other Income Line Descriptions
		   localStorage.OtherIncomeDescLine1 = ""
           localStorage.OtherIncomeDescLine2 = "";
           localStorage.OtherIncomeDescLine3 = "";
           localStorage.OtherIncomeDescLine4 = "";
           //18. Other Opex Line Descriptions
           localStorage.NoNameOpexDescLine1 = "";
           localStorage.NoNameOpexDescLine2 = "";
          //19. Saving the Calculated Items
 		   localStorage.CosTotal0 =0;
		   localStorage.CosTotal1 =0;
		   localStorage.CosTotal2 =0;
		   localStorage.CosTotal3 =0;
		   
		   //2. Gross Profit 
		   localStorage.GrossProfit0 =0;
		   localStorage.GrossProfit1 =0;
		   localStorage.GrossProfit2 =0;
		   localStorage.GrossProfit3 =0;
		   
		   //3. Total Other Income
		   localStorage.OtherIncomeTotal0 =0;
		   localStorage.OtherIncomeTotal1 =0;
		   localStorage.OtherIncomeTotal2 =0;
		   localStorage.OtherIncomeTotal3 =0;
		   
		   //4. Total Opex
		   localStorage.OpexTotal0 =0;
		   localStorage.OpexTotal1 =0;
		   localStorage.OpexTotal2 =0;
		   localStorage.OpexTotal3 =0;
		   
		   //5. EBIT
	       localStorage.EBIT0 =0;
           localStorage.EBIT1 =0;
		   localStorage.EBIT2 =0;
		   localStorage.EBIT3 =0;
		   
		   //6. PBT
	       localStorage.PBT0 = 0;
	       localStorage.PBT1 = 0;
		   localStorage.PBT2 = 0;
		   localStorage.PBT3 = 0;
		   //7. Taxation for the Year
	       localStorage.Taxation0 =0;
	       localStorage.Taxation1 =0;
		   localStorage.Taxation2 =0;
		   localStorage.Taxation3 =0;
		   //8. Net Profit
	       localStorage.NetProfit0 =0;
	       localStorage.NetProfit1 =0;
		   localStorage.NetProfit2 =0;
		   localStorage.NetProfit3 =0;
}

function InitialiseCurrentAssets()
{
		
		//Cash Balances
		 localStorage.CashBal0=0;
		 localStorage.CashBal1=0;
		 localStorage.CashBal2=0;
		 localStorage.CashBal3=0;
		
		//Saving Debtors
		localStorage.AccountsReceivable0=0;
		localStorage.AccountsReceivable1=0;
		localStorage.AccountsReceivable2=0;
		localStorage.AccountsReceivable3=0;
		//Saving Prepayments
		localStorage.Prepayments0=0;
		localStorage.Prepayments1=0;
		localStorage.Prepayments2=0;
		localStorage.Prepayments3=0;
		//Saving Prepaid Tax
		localStorage.PrepaidTax0=0;
		localStorage.PrepaidTax1=0;
		localStorage.PrepaidTax2=0;
		localStorage.PrepaidTax3=0;
		//Saving Inventory
		localStorage.Inventory0=0;
		localStorage.Inventory1=0;
		localStorage.Inventory2=0;
		localStorage.Inventory3=0;
		//Saving Other Current Assets NonInter Company Line 1
		localStorage.OtherCurrentAssetsNonInterCompanyLine1_0=0;
		localStorage.OtherCurrentAssetsNonInterCompanyLine1_1=0;
		localStorage.OtherCurrentAssetsNonInterCompanyLine1_2=0;
	  	localStorage.OtherCurrentAssetsNonInterCompanyLine1_3=0;
		//Saving Other Current Assets NonInter Company Line 2
		localStorage.OtherCurrentAssetsNonInterCompanyLine2_0=0;
		localStorage.OtherCurrentAssetsNonInterCompanyLine2_1=0;
		localStorage.OtherCurrentAssetsNonInterCompanyLine2_2=0;
	  	localStorage.OtherCurrentAssetsNonInterCompanyLine2_3=0;
		//Saving Other Current Assets NonInter Company Line 3
		localStorage.OtherCurrentAssetsNonInterCompanyLine3_0=0;
		localStorage.OtherCurrentAssetsNonInterCompanyLine3_1=0;
		localStorage.OtherCurrentAssetsNonInterCompanyLine3_2=0;
	  	localStorage.OtherCurrentAssetsNonInterCompanyLine3_3=0;
	    //Saving Other Current Assets Inter Company Line 1
		localStorage.OtherCurrentAssetsInterCompanyLine1_0=0;
		localStorage.OtherCurrentAssetsInterCompanyLine1_1=0;
		localStorage.OtherCurrentAssetsInterCompanyLine1_2=0;
	  	localStorage.OtherCurrentAssetsInterCompanyLine1_3=0;
		//Saving Other Current Assets Inter Company Line 2
		localStorage.OtherCurrentAssetsInterCompanyLine2_0=0;
		localStorage.OtherCurrentAssetsInterCompanyLine2_1=0;
		localStorage.OtherCurrentAssetsInterCompanyLine2_2=0;
	  	localStorage.OtherCurrentAssetsInterCompanyLine2_3=0;
		//Saving Other Current Assets Inter Company Line 3
		localStorage.OtherCurrentAssetsInterCompanyLine3_0=0;
		localStorage.OtherCurrentAssetsInterCompanyLine3_1=0;
		localStorage.OtherCurrentAssetsInterCompanyLine3_2=0;
	  	localStorage.OtherCurrentAssetsInterCompanyLine3_3=0;
	    // Saving Additional line descriptions entered by the user
	    //Loading Other Current Assets Non Inter Company Descriptions
		localStorage.OtherCurrentAssetsNonInterCompanyDescLine1="";
		localStorage.OtherCurrentAssetsNonInterCompanyDescLine2="";
	  	localStorage.OtherCurrentAssetsNonInterCompanyDescLine3="";
        //Loading Other Current Assets Inter Company Descriptions
	    localStorage.OtherCurrentAssetsInterCompanyDescLine1="";
		localStorage.OtherCurrentAssetsInterCompanyDescLine2="";
	  	localStorage.OtherCurrentAssetsInterCompanyDescLine3="";
  	
	
		
		//Saving a Total of Current Assets for export to the Summary Balance Sheet 
		 localStorage.CurrentAssets0 = 0;
		 localStorage.CurrentAssets1 = 0;
		 localStorage.CurrentAssets2 = 0;
		 localStorage.CurrentAssets3 = 0;
}
		
function InitialiseCurrentLiabilities()
{    
		//Bank Overdraft
		localStorage.BankOverdraft0=0;
		localStorage.BankOverdraft1=0;
		localStorage.BankOverdraft2=0;
		localStorage.BankOverdraft3=0;
		
		//Initialising Debtors
		localStorage.AccountsPayable0=0;
		localStorage.AccountsPayable1=0;
		localStorage.AccountsPayable2=0;
		localStorage.AccountsPayable3=0;
		//Initialising Accruals
		localStorage.Accruals0=0;
		localStorage.Accruals1=0;
		localStorage.Accruals2=0;
		localStorage.Accruals3=0;
		//Initialising Prepaid Tax
		localStorage.TaxPayable0=0;
		localStorage.TaxPayable1=0;
		localStorage.TaxPayable2=0;
		localStorage.TaxPayable3=0;
		//Initialising DividendsPayable
		localStorage.DividendsPayable0=0;
		localStorage.DividendsPayable1=0;
		localStorage.DividendsPayable2=0;
		localStorage.DividendsPayable3=0;
		//Initialising Current Portion Long Term Debt
		localStorage.CurrentPortionLongTermDebt0=0;
		localStorage.CurrentPortionLongTermDebt1=0;
		localStorage.CurrentPortionLongTermDebt2=0;
		localStorage.CurrentPortionLongTermDebt3=0;
		//Initialising Other Current Liabilities NonInter Company Line 1
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_0=0;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_1=0;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_2=0;
	  	localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_3=0;
		//Initialising Other Current Liabilities NonInter Company Line 2
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_0=0;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_1=0;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_2=0;
	  	localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_3=0;
		//Initialising Other Current Liabilities NonInter Company Line 3
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_0=0;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_1=0;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_2=0;
	  	localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_3=0;
	    //Initialising Other Current Liabilities Inter Company Line 1
		localStorage.OtherCurrentLiabilitiesInterCompanyLine1_0=0;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine1_1=0;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine1_2=0;
	  	localStorage.OtherCurrentLiabilitiesInterCompanyLine1_3=0;
		//Initialising Other Current Liabilities Inter Company Line 2
		localStorage.OtherCurrentLiabilitiesInterCompanyLine2_0=0;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine2_1=0;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine2_2=0;
	  	localStorage.OtherCurrentLiabilitiesInterCompanyLine2_3=0;
		//Initialising Other Current Liabilities Inter Company Line 3
		localStorage.OtherCurrentLiabilitiesInterCompanyLine3_0=0;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine3_1=0;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine3_2=0;
	  	localStorage.OtherCurrentLiabilitiesInterCompanyLine3_3=0;
	    // Initialising Additional line descriptions entered by the user
	    //Loading Other Current Liabilities Non Inter Company Descriptions
		localStorage.OtherCurrentLiabilitiesNonInterCompanyDescLine1="";
		localStorage.OtherCurrentLiabilitiesNonInterCompanyDescLine2="";
	  	localStorage.OtherCurrentLiabilitiesNonInterCompanyDescLine3="";
        //Loading Other Current Liabilities Inter Company Descriptions
	    localStorage.OtherCurrentLiabilitiesInterCompanyDescLine1="";
		localStorage.OtherCurrentLiabilitiesInterCompanyDescLine2="";
	  	localStorage.OtherCurrentLiabilitiesInterCompanyDescLine3="";
  	
		//Initialising a Total of Current Liabilities for export to the Summary Balance Sheet 
		
		 localStorage.CurrentLiabilities0 = 0;
		 localStorage.CurrentLiabilities1 = 0;
		 localStorage.CurrentLiabilities2 = 0;
		 localStorage.CurrentLiabilities3 = 0;
}

function InitialiseNonCurrentAssets()
{
		//Initialising Opening NBV
		 localStorage.OpeningNBV0=0;
		 localStorage.OpeningNBV1=0;
		 localStorage.OpeningNBV2=0;
		 localStorage.OpeningNBV3=0;
		
		//Additions
		localStorage.Additions0=0;
		localStorage.Additions1=0;
		localStorage.Additions2=0;
		localStorage.Additions3=0;
		//Initialising Revaluation
		localStorage.Revaluation0=0;
		localStorage.Revaluation1=0;
		localStorage.Revaluation2=0;
		localStorage.Revaluation3=0;
		//Initialising Depreciations - Costs Of Sales
		localStorage.DepreciationCostOfSales0=0;
		localStorage.DepreciationCostOfSales1=0;
		localStorage.DepreciationCostOfSales2=0;
		localStorage.DepreciationCostOfSales3=0;
		//Initialising Depreciation - Opex
		localStorage.DepreciationOpex0=0;
		localStorage.DepreciationOpex1=0;
		localStorage.DepreciationOpex2=0;
		localStorage.DepreciationOpex3=0;
		//Initialising Other Movements PPE
		localStorage.OtherMovementsPPE0=0;
		localStorage.OtherMovementsPPE1=0;
		localStorage.OtherMovementsPPE2=0;
		localStorage.OtherMovementsPPE3=0;
	
		//Initialising Other Non Current Assets Line 1
		localStorage.OtherNonCurrentAssetsLine1_0=0;
		localStorage.OtherNonCurrentAssetsLine1_1=0;
		localStorage.OtherNonCurrentAssetsLine1_2=0;
	  	localStorage.OtherNonCurrentAssetsLine1_3=0;
		//Initialising Other Non Current Assets Line 2
		localStorage.OtherNonCurrentAssetsLine2_0=0;
		localStorage.OtherNonCurrentAssetsLine2_1=0;
		localStorage.OtherNonCurrentAssetsLine2_2=0;
	  	localStorage.OtherNonCurrentAssetsLine2_3=0;
		//Initialising Other Non Current Assets Line 3
		localStorage.OtherNonCurrentAssetsLine3_0=0;
		localStorage.OtherNonCurrentAssetsLine3_1=0;
		localStorage.OtherNonCurrentAssetsLine3_2=0;
	  	localStorage.OtherNonCurrentAssetsLine3_3=0;
    
	        //Initialising Land and Buildings NBV
		localStorage.LandBuildingsNBV0=0;
		localStorage.LandBuildingsNBV1=0;
		localStorage.LandBuildingsNBV2=0;
		localStorage.LandBuildingsNBV3=0;
	
		//Initialising Investment Property
		localStorage.InvestmentProperty0=0;
		localStorage.InvestmentProperty1=0;
		localStorage.InvestmentProperty2=0;
		localStorage.InvestmentProperty3=0;
	     	//Initialising Intangible Assets
		localStorage.IntangibleAssets0=0;
		localStorage.IntangibleAssets1=0;
		localStorage.IntangibleAssets2=0;
		localStorage.IntangibleAssets3=0;
                
		     //Initialising Other Non Current Assets Line 1
		localStorage.OtherNonCurrentAssetsLine1_0=0;
		localStorage.OtherNonCurrentAssetsLine1_1=0;
		localStorage.OtherNonCurrentAssetsLine1_2=0;
	  	localStorage.OtherNonCurrentAssetsLine1_3=0;
             //Initialising Other Non Current Assets Line 2
		localStorage.OtherNonCurrentAssetsLine2_0=0;
		localStorage.OtherNonCurrentAssetsLine2_1=0;
		localStorage.OtherNonCurrentAssetsLine2_2=0;
	  	localStorage.OtherNonCurrentAssetsLine2_3=0;
		//Initialising Other Non Current Assets Line 3
		localStorage.OtherNonCurrentAssetsLine3_0=0;
		localStorage.OtherNonCurrentAssetsLine3_1=0;
		localStorage.OtherNonCurrentAssetsLine3_2=0;
	  	localStorage.OtherNonCurrentAssetsLine3_3=0;
	 		
         // Initialising Additional line descriptions entered by the user
	    //Loading Other Non Current Assets Descriptions
		localStorage.OtherNonCurrentAssetsDescLine1="";
		localStorage.OtherNonCurrentAssetsDescLine2="";
	  	localStorage.OtherNonCurrentAssetsDescLine3="";
        //Loading Other Non Current Assets Comments
	    localStorage.PPEComments="";
		localStorage.OtherNonCurrentAssetsComments="";
		
		//Initialising a Total of Non Current Assets for export to the Summary Balance Sheet 
		 localStorage.NonCurrentAssets0 = 0;		
		 localStorage.NonCurrentAssets1 = 0;
		 localStorage.NonCurrentAssets2 = 0;
		 localStorage.NonCurrentAssets3 = 0;
		 
}
	
function InitialiseNonCurrentLiabilities()
{
		
		//Mortgage Loans
		localStorage.MortgageLoans0=  0;
		localStorage.MortgageLoans1=  0;
		localStorage.MortgageLoans2=  0;
		localStorage.MortgageLoans3=  0;
		
		//Term Loans
		localStorage.TermLoans0=  0;
		localStorage.TermLoans1=  0;
		localStorage.TermLoans2=  0;
		localStorage.TermLoans3=  0;
		//Saving Bonds
		localStorage.Bonds0=  0;
		localStorage.Bonds1=  0;
		localStorage.Bonds2=  0;
		localStorage.Bonds3=  0;
		//Saving Finance Leases
		localStorage.FinanceLeases0=  0;
		localStorage.FinanceLeases1=  0;
		localStorage.FinanceLeases2=  0;
		localStorage.FinanceLeases3=  0;
		//Saving OtherLongTermBorrowings
		localStorage.OtherLongTermBorrowings0=  0;
		localStorage.OtherLongTermBorrowings1=  0;
		localStorage.OtherLongTermBorrowings2=  0;
		localStorage.OtherLongTermBorrowings3=  0;
		//Saving Shareholders Loans
		localStorage.ShareholdersLoans0=  0;
		localStorage.ShareholdersLoans1=  0;
		localStorage.ShareholdersLoans2=  0;
		localStorage.ShareholdersLoans3=  0;
       //Saving Inter Companyy Loans Line 1
		localStorage.InterCompanyLoansLine1_0=  0;
		localStorage.InterCompanyLoansLine1_1=  0;
		localStorage.InterCompanyLoansLine1_2=  0;
	  	localStorage.InterCompanyLoansLine1_3=  0;
		//Saving Inter Companyy Loans Line 2
		localStorage.InterCompanyLoansLine2_0=  0;
		localStorage.InterCompanyLoansLine2_1=  0;
		localStorage.InterCompanyLoansLine2_2=  0;
	  	localStorage.InterCompanyLoansLine2_3=  0;
		//Saving Inter Companyy Loans Line 3
		localStorage.InterCompanyLoansLine3_0=  0;
		localStorage.InterCompanyLoansLine3_1=  0;
		localStorage.InterCompanyLoansLine3_2=  0;
	  	localStorage.InterCompanyLoansLine3_3=  0;
	    //Saving Deferred Tax Balance
		localStorage.DeferredTaxBalance0=  0;
		localStorage.DeferredTaxBalance1=  0;
		localStorage.DeferredTaxBalance2=  0;
		localStorage.DeferredTaxBalance3=  0;
		//Saving Provisions
		localStorage.Provisions0=  0;
		localStorage.Provisions1=  0;
		localStorage.Provisions2=  0;
		localStorage.Provisions3=  0;
	    //Saving Other Non Current Liabilities Line 1
		localStorage.OtherNonCurrentLiabilitiesLine1_0=  0;
		localStorage.OtherNonCurrentLiabilitiesLine1_1=  0;
		localStorage.OtherNonCurrentLiabilitiesLine1_2=  0;
	  	localStorage.OtherNonCurrentLiabilitiesLine1_3=  0;
		//Saving Other Non Current Liabilities Line 2
		localStorage.OtherNonCurrentLiabilitiesLine2_0=  0;
		localStorage.OtherNonCurrentLiabilitiesLine2_1=  0;
		localStorage.OtherNonCurrentLiabilitiesLine2_2=  0;
	  	localStorage.OtherNonCurrentLiabilitiesLine2_3=  0;
		//Saving Other Non Current Liabilities Line 3
		localStorage.OtherNonCurrentLiabilitiesLine3_0=  0;
		localStorage.OtherNonCurrentLiabilitiesLine3_1=  0;
		localStorage.OtherNonCurrentLiabilitiesLine3_2=  0;
	  	localStorage.OtherNonCurrentLiabilitiesLine3_3=  0;
	    // Saving Additional line descriptions entered by the user
	    //Loading Other Current Assets Non Inter Company Descriptions
		localStorage.InterCompanyLoansDescLine1=  "";
		localStorage.InterCompanyLoansDescLine2=  "";
	  	localStorage.InterCompanyLoansDescLine3=  "";
        //Loading Other Current Assets Inter Company Descriptions
	    localStorage.OtherNonCurrentLiabilitiesDescLine1=  "";
		localStorage.OtherNonCurrentLiabilitiesDescLine2=  "";
	  	localStorage.OtherNonCurrentLiabilitiesDescLine3=  "";
  	
	
		
		//Saving a Total of Current Assets for export to the Summary Balance Sheet 
		
		 localStorage.NonCurrentLiabilities0 =  0;
		 localStorage.NonCurrentLiabilities1 =  0;
		 localStorage.NonCurrentLiabilities2 =  0;
		 localStorage.NonCurrentLiabilities3 =  0;
}	
		
function InitialiseEquity()
{
		//Initialising Opening Retained Profits
		 localStorage.OpeningRetainedProfits0= 0;
		 localStorage.OpeningRetainedProfits1= 0;
		 localStorage.OpeningRetainedProfits2= 0;
		 localStorage.OpeningRetainedProfits3= 0;
		//Initialising Closing Retained Profits
		 localStorage.ClosingRetainedProfits0= 0;
		 localStorage.ClosingRetainedProfits1= 0;
		 localStorage.ClosingRetainedProfits2= 0;
		 localStorage.ClosingRetainedProfits3= 0;
		
		//Share Capital
		localStorage.ShareCapital0= 0;
		localStorage.ShareCapital1= 0;
		localStorage.ShareCapital2= 0;
		localStorage.ShareCapital3= 0;
		//Initialising Share Premium
		localStorage.SharePremium0= 0;
		localStorage.SharePremium1= 0;
		localStorage.SharePremium2= 0;
		localStorage.SharePremium3= 0;
		//Initialising Revaluation Reserve
		localStorage.RevaluationReserve0= 0;
		localStorage.RevaluationReserve1= 0;
		localStorage.RevaluationReserve2= 0;
		localStorage.RevaluationReserve3= 0;
		//Initialising Net Profit
		localStorage.NetProfit0= 0;
		localStorage.NetProfit1= 0;
		localStorage.NetProfit2= 0;
		localStorage.NetProfit3= 0;
		//Initialising Dividends
		localStorage.Dividends0= 0;
		localStorage.Dividends1= 0;
		localStorage.Dividends2= 0;
		localStorage.Dividends3= 0;
	
		//Initialising Other Non Distributable Reserves Line 1
		localStorage.OtherNonDistributableReservesLine1_0= 0;
		localStorage.OtherNonDistributableReservesLine1_1= 0;
		localStorage.OtherNonDistributableReservesLine1_2= 0;
	  	localStorage.OtherNonDistributableReservesLine1_3= 0;
		//Initialising Other Non Distributable Reserves Line 2
		localStorage.OtherNonDistributableReservesLine2_0= 0;
		localStorage.OtherNonDistributableReservesLine2_1= 0;
	  	localStorage.OtherNonDistributableReservesLine2_2= 0;
		localStorage.OtherNonDistributableReservesLine2_3= 0;
		//Initialising Other Non Distributable Reserves Line 3
		localStorage.OtherNonDistributableReservesLine3_0= 0;
		localStorage.OtherNonDistributableReservesLine3_1= 0;
 		localStorage.OtherNonDistributableReservesLine3_2= 0;
 		localStorage.OtherNonDistributableReservesLine3_3= 0;
    
	    //Initialising Retained Profits Adjustment
		localStorage.RetainedProfitsAdjustments0= 0;
		localStorage.RetainedProfitsAdjustments1= 0;
		localStorage.RetainedProfitsAdjustments2= 0;
		localStorage.RetainedProfitsAdjustments3= 0;
	 
		//Initialising Other Distributable Reserves Line 1
		localStorage.OtherDistributableReservesLine1_0= 0;
		localStorage.OtherDistributableReservesLine1_1= 0;
		localStorage.OtherDistributableReservesLine1_2= 0;
	  	localStorage.OtherDistributableReservesLine1_3= 0;
        //Initialising Other Distributable Reserves Line 2
		localStorage.OtherDistributableReservesLine2_0= 0;
		localStorage.OtherDistributableReservesLine2_1= 0;
		localStorage.OtherDistributableReservesLine2_2= 0;
	  	localStorage.OtherDistributableReservesLine2_3= 0;
		//Initialising Other Distributable Reserves Line 3
		localStorage.OtherDistributableReservesLine3_0= 0;
		localStorage.OtherDistributableReservesLine3_1= 0;
		localStorage.OtherDistributableReservesLine3_2= 0;
	  	localStorage.OtherDistributableReservesLine3_3= 0;
	 		
        // Initialising Additional line descriptions entered by the user
	    //Initialising Other Non Distributable Reserves Descriptions
		localStorage.OtherNonDistributableReservesDescLine1= "";
		localStorage.OtherNonDistributableReservesDescLine2= "";
	  	localStorage.OtherNonDistributableReservesDescLine3= "";
      	     
         //Initialising Distributable Reserves Descriptions
		localStorage.OtherDistributableReservesDescLine1= "";
		localStorage.OtherDistributableReservesDescLine2= "";
	  	localStorage.OtherDistributableReservesDescLine3= "";
      	
		//Initialising a Total of Non Current Assets for export to the Summary Balance Sheet 
		localStorage.TotalEquity0 = 0; 
		localStorage.TotalEquity1 = 0; 
		localStorage.TotalEquity2 = 0; 
		localStorage.TotalEquity3 = 0; 
		 
}
//INITIALISE MANAGEMENT ANALYSIS LOCAL STOEAGE VARIABLES IF UNDEFINED ===============================================================

function InitialiseManagementAnalysisForm()
{
     
       localStorage.Commitment                          = "Deficient";
       localStorage.Integrity                           = "Deficient";
       localStorage.InformationQuality                  = "Deficient";
       localStorage.Leadership                          = "Deficient";
       localStorage.Strategy                            = "Deficient";
       localStorage.Structure                           = "Deficient";
       localStorage.Management                          = "Deficient";
       localStorage.SuccessionPlanning                  = "Deficient";
       localStorage.OrganisationalPlanning              = "Deficient";
       localStorage.CommitmentComment                   = "";
       localStorage.IntegrityComment                    = "";
       localStorage.InformationQualityComment           = "";
       localStorage.LeadershipComment                   = "";
       localStorage.StrategyComment                     = "";
       localStorage.StructureComment                    = "";
       localStorage.ManagementComment                   = "";
       localStorage.SuccessionPlanningComment           = "";
       localStorage.OrganisationalPlanningComment       = "";
       localStorage.CommitmentReviewComment             = "";
       localStorage.IntegrityReviewComment              = "";
       localStorage.InformationQualityReviewComment     = "";
       localStorage.LeadershipReviewComment             = "";
       localStorage.StrategyReviewComment               = "";
       localStorage.StructureReviewComment              = "";
       localStorage.ManagementReviewComment             = "";
       localStorage.SuccessionPlanningReviewComment     = "";
       localStorage.OrganisationalPlanningReviewComment = "";

}

// INITIALISE LOCAL STORAGE VARIABLES FOR INDUSTRY ANALYSIS=======================================================================

function InitialiseIndustryAnalysis()
{ 
       localStorage.IndustryCyclicality            = "";
       localStorage.IndustryPerformance            = "";
       localStorage.ThreatsOfNewEntryRating        = "Medium";
       localStorage.ThreatsOfNewEntryScore         = 1;
       localStorage.EntryCostsRating               = "Medium";
       localStorage.EntryCostsScore                = 0;
       localStorage.EntryCostsComment              = "";
       localStorage.SpecialistKnowledgeRating      = "Medium";
       localStorage.SpecialKnowledgeScore          = 0;
       localStorage.SpecialistKnowledgeComment     = "";
       localStorage.EconomiesOfScaleRating         = "Medium";
       localStorage.EconomiesOfScaleScore          = 0;
       localStorage.EconomiesOfScaleComment        = "";
       localStorage.CostAdvantagesRating           = "Medium";
       localStorage.CostAdvantagesScore            = 0;
       localStorage.CostAdvantagesComment          = "";
       localStorage.TechnologyProtectionRating     = "Medium";
       localStorage.TechnologyProtectionScore      = 0;
       localStorage.TechnologyProtectionComment    = "";
       localStorage.BarriersToEntryRating          = "Medium";
       localStorage.BarriersToEntryScore           = 0;
       localStorage.BarriersToEntryComment         = "";
       localStorage.CompetitiveRivalryRating       = "Medium";
       localStorage.CompetitiveRivalryScore        = 0;
       localStorage.NumberOfCompetitorsRating      = "Medium";
       localStorage.NumberOfCompetitorsScore       = 0;
       localStorage.NumberOfCompetitorsComment     = "";
       localStorage.QualityDifferencesRating       = "Medium";
       localStorage.QualityDifferencesScore        = 0;
       localStorage.QualityDifferencesComment      = "";
       localStorage.OtherDifferencesRating         = "Medium";
       localStorage.OtherDifferencesScore          = 0;
       localStorage.OtherDifferencesComment        = "";
       localStorage.SwitchingCostsRating           = "Medium";
       localStorage.SwitchingCostsScore            = 0;
       localStorage.SwitchingCostsComment          = "";
       localStorage.CustomerLoyaltyRating          = "Medium";
       localStorage.CustomerLoyaktyScore           = 0;
       localStorage.CustomerLoyaktyComment         = "";
       localStorage.SupplierPowerRating            = "Medium";
       localStorage.SupplierPowerScore             = 0;
       localStorage.NumberOfSuppliersrsRating      = "Medium";
       localStorage.NumberOfSuppliersOverallScore  = 0;
       localStorage.NumberOfSuppliersComment       = "";
       localStorage.SizeOfSuppliersRating          = "Medium";
       localStorage.SizeOfSuppliersOverallScore    = 0;
       localStorage.SizeOfSuppliersComment         = "";
       localStorage.UniquenessOfServiceRating      = "Medium";
       localStorage.UniquenessOfServiceScore       = 0;
       localStorage.UniquenessOfServiceComment     = "";
       localStorage.CostsOfSupplierChangeRating    = "Medium";
       localStorage.CostsOfSupplierChangeScore     = 0;
       localStorage.CostsOfSupplierChangeComment   = "";
       localStorage.SupplierSwitchingCostsRating   = "Medium";
       localStorage.SupplierSwitchingCostsScore    = 0;
       localStorage.SupplierSwitchingCostsComment  = "";
       localStorage.ThreatsOfSubstitutionRating    = "Medium";
       localStorage.ThreatsOfSubstitutionScore     = 0;
       localStorage.SubstitutePerfomanceRating     = "Medium";
       localStorage.SubstitutePerformanceScore     = 0;
       localStorage.SubstitutePerfomanceComment    = "";
       localStorage.CostsOfSubstitutionRating      = "Medium";
       localStorage.CostsOfSubstitutionScore       = 0;
       localStorage.CostsOfSubstitutionComment     = "";
       localStorage.BuyerPowerRating               = "Medium";
       localStorage.BuyerPowerScore                = 0;
       localStorage.NumberOfCustomersRating        = "Medium";
       localStorage.NumberOfCCustomersScore        = 0;
       localStorage.NumberOfCustomersComment       = "";
       localStorage.SingleOrderSizeRating          = "Medium";
       localStorage.SingleOrderSizeScore           = 0;
       localStorage.SingleOrderSizeComment         = "";
       localStorage.CompetitorDifferencesRating    = "Medium";
       localStorage.CompetitorDifferencesScore     = 0;
       localStorage.CompetitorDifferencesComment   = "";
       localStorage.PriceSensitivityRating         = "Medium";
       localStorage.PriceSensitivityScore          = 0;
       localStorage.PriceSensitivityComment        = "";
       localStorage.AbilityToSubstituteRating      = "Medium";
       localStorage.AbilityToSubstituteScore       = 0;
       localStorage.AbilityToSubstituteComment     = "";
       localStorage.CustomersSwitchingCostsRating  = "Medium";
       localStorage.CustomerSwitchingCostsScore    = 0;
       localStorage.CustomersSwitchingCostsComment = "";
       localStorage.SummaryRating                  = "Medium";
       localStorage.SummaryScore                   = 0;
}          
//================================================================================================================================
function InitialiseShareholderAnalysisForm()
{
       localStorage.ShareholderName1        		= "";
       localStorage.ShareholderDate1        		= "";
       localStorage.ShareholderGender1      		= "Female";
       localStorage.ShareholderAge1         		= "";
       localStorage.ShareholderPercentageShares1    = "";
       localStorage.ShareholderITCRef1      		= "";
       localStorage.ShareholderITCDate1     		= "";
       localStorage.ShareholderPaidDebts1   		= "0";
       localStorage.ShareholderDefaults1    		= "0";
       localStorage.ShareholderJudgements1  		= "0";
       localStorage.ShareholderTraceAlerts1 		= "0";
       localStorage.ShareholderBlacklisted1 		= "No";
       localStorage.ShareholderFraudAlert1  		= "No";
       localStorage.ShareholderTotalScore1  		= "";
       localStorage.ShareholderName2        		= "";
       localStorage.ShareholderDate2        		= "";
       localStorage.ShareholderGender2      		= "Female";
       localStorage.ShareholderAge2         		= "";
       localStorage.ShareholderPercentageShares2    = "";
       localStorage.ShareholderITCRef2      		= "";
       localStorage.ShareholderITCDate2     		= "";
       localStorage.ShareholderPaidDebts2   		= "0";
       localStorage.ShareholderDefaults2    		= "0";
       localStorage.ShareholderJudgements2  		= "0";
       localStorage.ShareholderTraceAlerts2 		= "0";
       localStorage.ShareholderBlacklisted2 		= "No";
       localStorage.ShareholderFraudAlert2  		= "No";
       localStorage.ShareholderTotalScore2  		= "";
       localStorage.ShareholderName3        		= "";
       localStorage.ShareholderDate3        		= "";
       localStorage.ShareholderGender3      		= "Female";
       localStorage.ShareholderAge3         		= "";
       localStorage.ShareholderPercentageShares3    = "";
       localStorage.ShareholderITCRef3      		= "";
       localStorage.ShareholderITCDate3     		= "";
       localStorage.ShareholderPaidDebts3   		= "0";
       localStorage.ShareholderDefaults3    		= "0";
       localStorage.ShareholderJudgements3  		= "0";
       localStorage.ShareholderTraceAlerts3 		= "0";
       localStorage.ShareholderBlacklisted3 		= "No";
       localStorage.ShareholderFraudAlert3  		= "No";
       localStorage.ShareholderTotalScore3  		= "";
       localStorage.ShareholderName4        		= "";
       localStorage.ShareholderDate4        		= "";
       localStorage.ShareholderGender4      		= "Female";
       localStorage.ShareholderAge4         		= "";
       localStorage.ShareholderPercentageShares4    = "";
       localStorage.ShareholderITCRef4      		= "";
       localStorage.ShareholderITCDate4     		= "";
       localStorage.ShareholderPaidDebts4   		= "0";
       localStorage.ShareholderDefaults4    		= "0";
       localStorage.ShareholderJudgements4  		= "0";
       localStorage.ShareholderTraceAlerts4 		= "0";
       localStorage.ShareholderBlacklisted4 		= "No";
       localStorage.ShareholderFraudAlert4  		= "No";
       localStorage.ShareholderTotalScore4  		= "";
       localStorage.ShareholderName5        		= "";
       localStorage.ShareholderDate5        		= "";
       localStorage.ShareholderGender5      		= "Female";
       localStorage.ShareholderAge5         		= "";
       localStorage.ShareholderPercentageShares5    = "";
       localStorage.ShareholderITCRef5      		= "";
       localStorage.ShareholderITCDate5     		= "";
       localStorage.ShareholderPaidDebts5   		= "0";
       localStorage.ShareholderDefaults5    		= "0";
       localStorage.ShareholderJudgements5  		= "0";
       localStorage.ShareholderTraceAlerts5 		= "0";
       localStorage.ShareholderBlacklisted5 		= "No";
       localStorage.ShareholderFraudAlert5  		= "No";
       localStorage.ShareholderTotalScore5  		= "";
       localStorage.ShareholderComment      		= "";
}
function InitialiseBenchmarkOverrideForm()
{
     localStorage.CurrentRatioOverrideBenchmarkType_             = "Industry";
     localStorage.CurrentRatioOverrideBenchmarkValue_            = ""  ;
     localStorage.CurrentRatioOverrideComment_                   = ""  ;
     localStorage.CurrentRatioBenchmarkFirstApproval_            = ""  ;
     localStorage.CurrentRatioBenchmarkSecondApproval_           = ""  ;
     localStorage.DebtorDaysOverrideBenchmarkType_               = "Industry"  ;
     localStorage.DebtorDaysOverrideBenchmarkValue_              = ""  ;
     localStorage.DebtorDaysOverrideComment_                     = ""  ;
     localStorage.DebtorDaysBenchmarkFirstApproval_              = ""  ;
     localStorage.DebtorDaysBenchmarkSecondApproval_             = ""  ;
     localStorage.TurnoverToWCOverrideBenchmarkType_             = "Industry"  ;
     localStorage.TurnoverToWCOverrideBenchmarkValue_            = ""  ;
     localStorage.TurnoverToWCOverrideComment_                   = ""  ;
     localStorage.TurnoverToWCBenchmarkFirstApproval_            = ""  ;
     localStorage.TurnoverToWCBenchmarkSecondApproval_           = ""  ;
     localStorage.TurnoverGrowthOverrideBenchmarkType_           = "Industry"  ;
     localStorage.TurnoverGrowthOverrideBenchmarkValue_          = ""  ;
     localStorage.TurnoverGrowthOverrideComment_                 = ""  ;
     localStorage.TurnoverGrowthBenchmarkFirstApproval_          = ""  ;
     localStorage.TurnoverGrowthBenchmarkSecondApproval_         = ""  ;
     localStorage.GrossProfitMarginOverrideBenchmarkType_        = "Industry"  ;
     localStorage.GrossProfitMarginOverrideBenchmarkValue_       = ""  ;
     localStorage.GrossProfitMarginOverrideComment_              = ""  ;
     localStorage.GrossProfitMarginBenchmarkFirstApproval_       = ""  ;
     localStorage.GrossProfitMarginBenchmarkSecondApproval_      = ""  ;
     localStorage.OperatingProfitMarginOverrideBenchmarkType_    = "Industry"  ;
     localStorage.OperatingProfitMarginOverrideBenchmarkValue_   = ""  ;
     localStorage.OperatingProfitMarginOverrideComment_          = ""  ;
     localStorage.OperatingProfitMarginBenchmarkFirstApproval_   = ""  ;
     localStorage.OperatingProfitMarginBenchmarkSecondApproval_  = ""  ;
     localStorage.ROAOverrideBenchmarkType_                      = "Industry"  ;
     localStorage.ROAOverrideBenchmarkValue_                     = ""  ;
     localStorage.ROAOverrideComment_                            = ""  ;
     localStorage.ROABenchmarkFirstApproval_                     = ""  ;
     localStorage.ROABenchmarkSecondApproval_                    = ""  ;
     localStorage.ROIOverrideBenchmarkType_                      = "Industry"  ;
     localStorage.ROIOverrideBenchmarkValue_                     = ""  ;
     localStorage.ROIOverrideComment_                            = ""  ;
     localStorage.ROIBenchmarkFirstApproval_                     = ""  ;
     localStorage.ROIBenchmarkSecondApproval_                    = ""  ;
     localStorage.LongtermDebtToEquityOverrideBenchmarkType_     = "Industry"  ;
     localStorage.LongtermDebtToEquityOverrideBenchmarkValue_    = ""  ;
     localStorage.LongtermDebtToEquityOverrideComment_           = ""  ;
     localStorage.LongtermDebtToEquityBenchmarkFirstApproval_    = ""  ;
     localStorage.LongtermDebtToEquityBenchmarkSecondApproval_   = ""  ;
     localStorage.DebtToTangibleNetWorthOverrideBenchmarkType_   = "Industry"  ;
     localStorage.DebtToTangibleNetWorthOverrideBenchmarkValue_  = ""  ;
     localStorage.DebtToTangibleNetWorthOverrideComment_         = ""  ;
     localStorage.DebtToTangibleNetWorthBenchmarkFirstApproval_  = ""  ;
     localStorage.DebtToTangibleNetWorthBenchmarkSecondApproval_ = ""  ;
     localStorage.EquityToTotalAssetsOverrideBenchmarkType_      = "Industry"  ;
     localStorage.EquityToTotalAssetsOverrideBenchmarkValue_     = ""  ;
     localStorage.EquityToTotalAssetsOverrideComment_            = ""  ;
     localStorage.EquityToTotalAssetsBenchmarkFirstApproval_     = ""  ;
     localStorage.EquityToTotalAssetsBenchmarkSecondApproval_    = ""  ;
     localStorage.InterestCoverOverrideBenchmarkType_            = "Industry"  ;
     localStorage.InterestCoverOverrideBenchmarkValue_           = ""  ;
     localStorage.InterestCoverOverrideComment_                  = ""  ;
     localStorage.InterestCoverBenchmarkFirstApproval_           = ""  ;
     localStorage.InterestCoverBenchmarkSecondApproval_          = ""  ;
     localStorage.EBITDAToDebtOverrideBenchmarkType_             = "Industry"  ;
     localStorage.EBITDAToDebtOverrideBenchmarkValue_            = ""  ;
     localStorage.EBITDAToDebtOverrideComment_                   = ""  ;
     localStorage.EBITDAToDebtBenchmarkFirstApproval_            = ""  ;
     localStorage.EBITDAToDebtBenchmarkSecondApproval_           = ""  ;
     localStorage.BenchmarkOverrideFirstReviewerComment_         = ""  ;
}
//===========================================================================================================================================================================
function InitialiseProgressTracker()
{
   localStorage.CompanyDataTrackerDateSaved = "";
   localStorage.CompanyDataTrackerSavedBy = "";
   localStorage.CompanyDataTracker1stReviewDate = "";
   localStorage.CompanyDataTracker1stReviewer = "";
   localStorage.CompanyDataTracker2ndReviewDate = "";
   localStorage.CompanyDataTracker2ndReviewer = "";
   localStorage.CompanyDataTracker1stReviewComment = "";
   localStorage.CompanyDataTracker2ndReviewComment = "";
   localStorage.LoanDataTrackerDateSaved = "";
   localStorage.LoanDataTrackerSavedBy = "";
   localStorage.LoanDataTracker1stReviewDate = "";
   localStorage.LoanDataTracker1stReviewer = "";
   localStorage.LoanDataTracker2ndReviewDate = "";
   localStorage.LoanDataTracker2ndReviewer = "";
   localStorage.LoanDataTracker1stReviewComment = "";
   localStorage.LoanDataTracker2ndReviewComment = "";
   localStorage.IncomeStatementTrackerDateSaved = "";
   localStorage.IncomeStatementTrackerSavedBy = "";
   localStorage.IncomeStatementTracker1stReviewDate = "";
   localStorage.IncomeStatementTracker1stReviewer = "";
   localStorage.IncomeStatementTracker2ndReviewDate = "";
   localStorage.IncomeStatementTracker2ndReviewer = "";
   localStorage.IncomeStatementTracker1stReviewComment = "";
   localStorage.IncomeStatementTracker2ndReviewComment = "";
   localStorage.CurrentAssetsTrackerDateSaved = "";
   localStorage.CurrentAssetsTrackerSavedBy = "";
   localStorage.CurrentAssetsTracker1stReviewDate = "";
   localStorage.CurrentAssetsTracker1stReviewer = "";
   localStorage.CurrentAssetsTracker2ndReviewDate = "";
   localStorage.CurrentAssetsTracker2ndReviewer = "";
   localStorage.CurrentAssetsTracker1stReviewComment = "";
   localStorage.CurrentAssetsTracker2ndReviewComment = "";
   localStorage.NonCurrentAssetsTrackerDateSaved = "";
   localStorage.NonCurrentAssetsTrackerSavedBy = "";
   localStorage.NonCurrentAssetsTracker1stReviewDate = "";
   localStorage.NonCurrentAssetsTracker1stReviewer = "";
   localStorage.NonCurrentAssetsTracker2ndReviewDate = "";
   localStorage.NonCurrentAssetsTracker2ndReviewer = "";
   localStorage.NonCurrentAssetsTracker1stReviewComment = "";
   localStorage.NonCurrentAssetsTracker2ndReviewComment = "";
   localStorage.CurrentLiabilitiesTrackerDateSaved = "";
   localStorage.CurrentLiabilitiesTrackerSavedBy = "";
   localStorage.CurrentLiabilitiesTracker1stReviewDate = "";
   localStorage.CurrentLiabilitiesTracker1stReviewer = "";
   localStorage.CurrentLiabilitiesTracker2ndReviewDate = "";
   localStorage.CurrentLiabilitiesTracker2ndReviewer = "";
   localStorage.CurrentLiabilitiesTracker1stReviewComment = "";
   localStorage.CurrentLiabilitiesTracker2ndReviewComment = "";
   localStorage.NonCurrentLiabilitiesTrackerDateSaved = "";
   localStorage.NonCurrentLiabilitiesTrackerSavedBy = "";
   localStorage.NonCurrentLiabilitiesTracker1stReviewDate = "";
   localStorage.NonCurrentLiabilitiesTracker1stReviewer = "";
   localStorage.NonCurrentLiabilitiesTracker2ndReviewDate = "";
   localStorage.NonCurrentLiabilitiesTracker2ndReviewer = "";
   localStorage.NonCurrentLiabilitiesTracker1stReviewComment = "";
   localStorage.NonCurrentLiabilitiesTracker2ndReviewComment = "";
   localStorage.EquityTrackerDateSaved = "";
   localStorage.EquityTrackerSavedBy = "";
   localStorage.EquityTracker1stReviewDate = "";
   localStorage.EquityTracker1stReviewer = "";
   localStorage.EquityTracker2ndReviewDate = "";
   localStorage.EquityTracker2ndReviewer = "";
   localStorage.EquityTracker1stReviewComment = "";
   localStorage.EquityTracker2ndReviewComment = "";
   localStorage.ManagementAnalysisTrackerDateSaved = "";
   localStorage.ManagementAnalysisTrackerSavedBy = "";
   localStorage.ManagementAnalysisTracker1stReviewDate = "";
   localStorage.ManagementAnalysisTracker1stReviewer = "";
   localStorage.ManagementAnalysisTracker2ndReviewDate = "";
   localStorage.ManagementAnalysisTracker2ndReviewer = "";
   localStorage.ManagementAnalysisTracker1stReviewComment = "";
   localStorage.ManagementAnalysisTracker2ndReviewComment = "";
   localStorage.IndustryAnalysisTrackerDateSaved = "";
   localStorage.IndustryAnalysisTrackerSavedBy = "";
   localStorage.IndustryAnalysisTracker1stReviewDate = "";
   localStorage.IndustryAnalysisTracker1stReviewer = "";
   localStorage.IndustryAnalysisTracker2ndReviewDate = "";
   localStorage.IndustryAnalysisTracker2ndReviewer = "";
   localStorage.IndustryAnalysisTracker1stReviewComment = "";
   localStorage.IndustryAnalysisTracker2ndReviewComment = "";
   localStorage.ShareholderAnalysisTrackerDateSaved = "";
   localStorage.ShareholderAnalysisTrackerSavedBy = "";
   localStorage.ShareholderAnalysisTracker1stReviewDate = "";
   localStorage.ShareholderAnalysisTracker1stReviewer = "";
   localStorage.ShareholderAnalysisTracker2ndReviewDate = "";
   localStorage.ShareholderAnalysisTracker2ndReviewer = "";
   localStorage.ShareholderAnalysisTracker1stReviewComment = "";
   localStorage.ShareholderAnalysisTracker2ndReviewComment = "";
   localStorage.BehavioralAnalysisTrackerDateSaved = "";
   localStorage.BehavioralAnalysisTrackerSavedBy = "";
   localStorage.BehavioralAnalysisTracker1stReviewDate = "";
   localStorage.BehavioralAnalysisTracker1stReviewer = "";
   localStorage.BehavioralAnalysisTracker2ndReviewDate = "";
   localStorage.BehavioralAnalysisTracker2ndReviewer = "";
   localStorage.BehavioralAnalysisTracker1stReviewComment = "";
   localStorage.BehavioralAnalysisTracker2ndReviewComment = "";
   localStorage.IndustryBenchmarksOverridesTrackerDateSaved = "";
   localStorage.IndustryBenchmarksOverridesTrackerSavedBy = "";
   localStorage.IndustryBenchmarksOverridesTracker1stReviewDate = "";
   localStorage.IndustryBenchmarksOverridesTracker1stReviewer = "";
   localStorage.IndustryBenchmarksOverridesTracker2ndReviewDate = "";
   localStorage.IndustryBenchmarksOverridesTracker2ndReviewer = "";
   localStorage.IndustryBenchmarksOverridesTracker1stReviewComment = "";
   localStorage.IndustryBenchmarksOverridesTracker2ndReviewComment = "";
}
function Load_Model_Settings_FromDbase_Into_LocalStorage()

{		  
	          console.log ("Starting Local Storage Assignment");             
				localStorage.bf = "<?php echo $bfFinancialAnalysis; ?>" ;
                alert(localStorage.bf);
			 // Saving Big Firms Data
			  localStorage.bfFinancialAnalysis = "<?php echo $bfFinancialAnalysis; ?>" ;
			  localStorage.bfManagementAnalysis = "<?php echo $bfManagementAnalysis; ?>" ;
			  localStorage.bfIndustryAnalysis = "<?php echo $bfIndustryAnalysis; ?>" ;
			  localStorage.bfShareholderAnalysis = "<?php echo $bfShareholderAnalysis; ?>" ;
			  localStorage.bfBehavioralAnalysis = "<?php echo $bfBehavioralAnalysis; ?>" ;
		      
			   alert (localStorage.bfShareholderAnalysis);
			  // Saving Small Firms Data
			  localStorage.sfFinancialAnalysis = "<?php echo $sfFinancialAnalysis; ?>" ;
			  localStorage.sfManagementAnalysis = "<?php echo $sfManagementAnalysis; ?>" ;
			  localStorage.sfIndustryAnalysis = "<?php echo $sfIndustryAnalysis; ?>" ;
			  localStorage.sfShareholderAnalysis = "<?php echo $sfShareholderAnalysis; ?>" ;
			  localStorage.sfBehavioralAnalysis = "<?php echo $sfBehavioralAnalysis; ?>" ;
			  localStorage.bfTotalScore = "<?php echo $bfTotalScore; ?>" ;
			  localStorage.sfTotalScore = "<?php echo $sfTotalScore; ?>" ;
			  
			  console.log ("Starting Local Storage Assignment - Financial Analysis");
			  
			  //Saving Financial Analysis Category Weights  
			  localStorage.LiquidityCategoryWeight = "<?php echo $LiquidityCategoryWeight; ?>" ;
		      localStorage.ProfitabilityCategoryWeight = "<?php echo $ProfitabilityCategoryWeight; ?>" ;
			  localStorage.CapitalStructureCategoryWeight = "<?php echo $CapitalStructureCategoryWeight; ?>" ;
			  localStorage.DebtServiceCategoryWeight = "<?php echo $DebtServiceCategoryWeight; ?>" ;
			  
			  //Saving Liquidity Metrics
			  localStorage.CurrentRatioWeight = "<?php echo $CurrentRatioWeight; ?>" ;
		      localStorage.DebtorDaysWeight = "<?php echo $DebtorDaysWeight; ?>" ;
		      localStorage.TurnoverToWorkingCapitalWeight = "<?php echo $TurnoverToWorkingCapitalWeight; ?>" ;
            //Saving Profitability Metrics
			  localStorage.GrossProfitMarginWeight = "<?php echo $GrossProfitMarginWeight; ?>" ;
		      localStorage.OperatingProfitMarginWeight = "<?php echo $OperatingProfitMarginWeight; ?>" ;
		      localStorage.TurnoverGrowthWeight = "<?php echo $TurnoverGrowthWeight; ?>" ;
		      localStorage.ReturnOnAssetsWeight = "<?php echo $ReturnOnAssetsWeight; ?>" ;
		      localStorage.ReturnOnInvestmentsWeight = "<?php echo $ReturnOnInvestmentsWeight; ?>" ;
              //Saving Capital Structure Metrics
			  localStorage.DebtToEquityWeight = "<?php echo $DebtToEquityWeight; ?>" ;
		      localStorage.DebtToTangibleNetWorthWeight = "<?php echo $DebtToTangibleNetWorthWeight; ?>" ;
		 	  localStorage.ShareholdersFundsToTotalAssetsWeight = "<?php echo $ShareholdersFundsToTotalAssetsWeight; ?>" ;  
              //Saving Debt Service Metrics 
			  localStorage.InterestCoverWeight = "<?php echo $InterestCoverWeight; ?>" ;
		      localStorage.EBITDAToGrossIntDebtsWeight = "<?php echo $EBITDAToGrossIntDebtsWeight; ?>" ;  
 			  //Saving Turnover Threshold and Ratio Weights
			  localStorage.TurnoverThreshold = "<?php echo $TurnoverThreshold; ?>" ;  
        	  localStorage.RatioWeightYear1 = "<?php echo $RatioWeightYear1; ?>" ;  
       	      localStorage.RatioWeightYear2 = "<?php echo $RatioWeightYear2; ?>" ;  
       	      localStorage.RatioWeightYear3 = "<?php echo $RatioWeightYear3; ?>" ;  
             //alert successfull save operation
		      
			  
			  
			  console.log ("Starting Local Storage Assignment - Management Analysis");
			  
	
  			  //SAVING MANAGEMENT ANALYSIS CATEGORY WEIGHTS 
			  //1. Sub Group Weights
			  localStorage.CommitmentCategoryWeight = "<?php echo $CommitmentCategoryWeight; ?>" ;
		      localStorage.IntegrityCategoryWeight = "<?php echo $IntegrityCategoryWeight; ?>" ;
			  localStorage.InformationQualityCategoryWeight = "<?php echo $InformationQualityCategoryWeight; ?>" ;
			  localStorage.LeadershipCategoryWeight = "<?php echo $LeadershipCategoryWeight; ?>" ;
			  localStorage.StrategyCategoryWeight = "<?php echo $StrategyCategoryWeight; ?>" ;
			  localStorage.StructureCategoryWeight = "<?php echo $StructureCategoryWeight; ?>" ;
			  localStorage.SuccessionPlanCategoryWeight = "<?php echo $SuccessionPlanCategoryWeight; ?>" ;
			  localStorage.OrganisationalDesignCategoryWeight = "<?php echo $OrganisationalDesignCategoryWeight; ?>" ;
              //2. Effective Weights
			  
			  //1.Big Firms
			  localStorage.CommitmentCategoryEffectiveWeight = "<?php echo $bfCommitmentCategoryEffectiveWeight; ?>" ;
		      localStorage.IntegrityCategoryEffectiveWeight = "<?php echo $bfIntegrityCategoryEffectiveWeight; ?>" ;
			  localStorage.InformationQualityCategoryEffectiveWeight = "<?php echo $bfInformationQualityCategoryEffectiveWeight; ?>" ;
			  localStorage.LeadershipCategoryEffectiveWeight = "<?php echo $bfLeadershipCategoryEffectiveWeight; ?>" ;
			  localStorage.StrategyCategoryEffectiveWeight = "<?php echo $bfStrategyCategoryEffectiveWeight; ?>" ;
			  localStorage.StructureCategoryEffectiveWeight = "<?php echo $bfStructureCategoryEffectiveWeight; ?>" ;
			  localStorage.ManagementCategoryEffectiveWeight = "<?php echo $bfManagementCategoryEffectiveWeight; ?>" ;
			  localStorage.SuccessionPlanCategoryEffectiveWeight = "<?php echo $bfSuccessionPlanCategoryEffectiveWeight; ?>" ;
			  localStorage.OrganisationalDesignCategoryEffectiveWeight = "<?php echo $bfOrganisationalDesignCategoryEffectiveWeight; ?>" ;
 			  //2.Big Firms
			  localStorage.CommitmentCategoryEffectiveWeight = "<?php echo $sfCommitmentCategoryEffectiveWeight; ?>" ;
		      localStorage.IntegrityCategoryEffectiveWeight = "<?php echo $sfIntegrityCategoryEffectiveWeight; ?>" ;
			  localStorage.InformationQualityCategoryEffectiveWeight = "<?php echo $sfInformationQualityCategoryEffectiveWeight; ?>" ;
			  localStorage.LeadershipCategoryEffectiveWeight = "<?php echo $sfLeadershipCategoryEffectiveWeight; ?>" ;
			  localStorage.StrategyCategoryEffectiveWeight = "<?php echo $sfStrategyCategoryEffectiveWeight; ?>" ;
			  localStorage.StructureCategoryEffectiveWeight = "<?php echo $sfStructureCategoryEffectiveWeight; ?>" ;
			  localStorage.ManagementCategoryEffectiveWeight = "<?php echo $sfManagementCategoryEffectiveWeight; ?>" ;
			  localStorage.SuccessionPlanCategoryEffectiveWeight = "<?php echo $sfSuccessionPlanCategoryEffectiveWeight; ?>" ;
			  localStorage.OrganisationalDesignCategoryEffectiveWeight = "<?php echo $sfOrganisationalDesignCategoryEffectiveWeight; ?>" ;
		  
		  
		      console.log ("Starting Local Storage Assignment - Industry Analysis");
			  
	   	  			
			 //SAVING INDUSTRY ANALYSIS METRICS
			  //1. Sub Group Weights
			  localStorage.BusinessCyclicalityWeight = "<?php echo $BusinessCyclicalityWeight; ?>" ;
			  localStorage.IndustryPerformanceWeight = "<?php echo $IndustryPerformanceWeight; ?>" ;
		      localStorage.ShareholderWeight = "<?php echo $ShareholderWeight; ?>" ;
              //2. Effective Weights
			  //Big Firms
			  localStorage.BusinessCyclicalityEffectiveWeight = "<?php echo $bfBusinessCyclicalityEffectiveWeight; ?>" ;
		      localStorage.IndustryPerformanceEffectiveWeight = "<?php echo $bfIndustryPerformanceEffectiveWeight; ?>" ;
		      localStorage.ShareholderEffectiveWeight = "<?php echo $bfShareholderEffectiveWeight; ?>" ;
 			 //Small Firms
			  localStorage.BusinessCyclicalityEffectiveWeight = "<?php echo $sfBusinessCyclicalityEffectiveWeight; ?>" ;
		      localStorage.IndustryPerformanceEffectiveWeight = "<?php echo $sfIndustryPerformanceEffectiveWeight; ?>" ;
		      localStorage.ShareholderEffectiveWeight = "<?php echo $sfShareholderEffectiveWeight; ?>" ;
 		  
		  
		      console.log ("Starting Local Storage Assignment - Shareholder Analysis");
			  
				  
			  //SAVING SHAREHOLDER ANALYSIS METRICS
			  //1. Sub Group Weights
			  localStorage.OwnersPaidDebtExceedsDefaultsWeight = "<?php echo $OwnersPaidDebtExceedsDefaultsWeight; ?>" ;
		      localStorage.OwnersNoOfJudgementsWeight = "<?php echo $OwnersNoOfJudgementsWeight; ?>" ;
		      localStorage.OwnersNoOfDefaultsWeight = "<?php echo $OwnersNoOfDefaultsWeight; ?>" ;
		      localStorage.OwnersNoOfTraceAlertsWeight = "<?php echo $OwnersNoOfTraceAlertsWeight; ?>" ;  
              //2. Effective Weights
 			  //Big Firms
			  localStorage.OwnersPaidDebtExceedsDefaultsEffectiveWeight = "<?php echo $bfOwnersPaidDebtExceedsDefaultsEffectiveWeight; ?>" ;
		      localStorage.OwnersNoOfJudgementsEffectiveWeight = "<?php echo $bfOwnersNoOfJudgementsEffectiveWeight; ?>" ;
		      localStorage.OwnersNoOfDefaultsEffectiveWeight = "<?php echo $bfOwnersNoOfDefaultsEffectiveWeight; ?>" ;
		      localStorage.OwnersNoOfTraceAlertsEffectiveWeight = "<?php echo $bfOwnersNoOfTraceAlertsEffectiveWeight; ?>" ;  
              //Small Firms
			  localStorage.OwnersPaidDebtExceedsDefaultsEffectiveWeight = "<?php echo $sfOwnersPaidDebtExceedsDefaultsEffectiveWeight; ?>" ;
		      localStorage.OwnersNoOfJudgementsEffectiveWeight = "<?php echo $sfOwnersNoOfJudgementsEffectiveWeight; ?>" ;
		      localStorage.OwnersNoOfDefaultsEffectiveWeight = "<?php echo $sfOwnersNoOfDefaultsEffectiveWeight; ?>" ;
		      localStorage.OwnersNoOfTraceAlertsEffectiveWeight = "<?php echo $sfOwnersNoOfTraceAlertsEffectiveWeight; ?>" ;
           
			  //SAVING BEHAVIORAL AND PRODUCTS ANALYSIS
			  //1. Sub Group Weights
			  localStorage.LoanRateTypeWeight = "<?php echo $LoanRateTypeWeight; ?>" ;
			  localStorage.LoanMaturityWeight = "<?php echo $LoanMaturityWeight; ?>" ;
			  localStorage.BBSBankingRelationshipYearsWeight = "<?php echo $BBSBankingRelationshipYearsWeight; ?>" ;
			  localStorage.BBSBankingProductsNoWeight = "<?php echo $BBSBankingProductsNoWeight; ?>" ;
			  localStorage.PastYearArrearIncidentsNoWeight = "<?php echo $PastYearArrearIncidentsNoWeight; ?>" ;
			  localStorage.Past2YearsArrearLoansRenegotiatedNoWeight = "<?php echo $Past2YearsArrearLoansRenegotiatedNoWeight; ?>" ;
			  localStorage.PaidDebtExceedsDefaultsWeight = "<?php echo $PaidDebtExceedsDefaultsWeight; ?>" ;
		      localStorage.NoOfJudgementsWeight = "<?php echo $NoOfJudgementsWeight; ?>" ;
		      localStorage.NoOfDefaultsWeight = "<?php echo $NoOfDefaultsWeight; ?>" ;
		      localStorage.NoOfTraceAlertsWeight = "<?php echo $NoOfTraceAlertsWeight; ?>" ;  
              //2. Effective Weights
			  //Big Firms
			  localStorage.LoanRateTypeEffectiveWeight = "<?php echo $bfLoanRateTypeEffectiveWeight; ?>" ;
			  localStorage.LoanMaturityEffectiveWeight = "<?php echo $bfLoanMaturityEffectiveWeight; ?>" ;
			  localStorage.BBSBankingRelationshipYearsEffectiveWeight = "<?php echo $bfBBSBankingRelationshipYearsEffectiveWeight; ?>" ;
			  localStorage.BBSBankingProductsNoEffectiveWeight = "<?php echo $bfBBSBankingProductsNoEffectiveWeight; ?>" ;
			  localStorage.PastYearArrearIncidentsNoEffectiveWeight = "<?php echo $bfPastYearArrearIncidentsNoEffectiveWeight; ?>" ;
			  localStorage.Past2YearsArrearLoansRenegotiatedNoEffectiveWeight = "<?php echo $bfPast2YearsArrearLoansRenegotiatedNoEffectiveWeight; ?>" ;
			  localStorage.PaidDebtExceedsDefaultsEffectiveWeight = "<?php echo $bfPaidDebtExceedsDefaultsEffectiveWeight; ?>" ;
		      localStorage.NoOfJudgementsEffectiveWeight = "<?php echo $bfNoOfJudgementsEffectiveWeight; ?>" ;
		      localStorage.NoOfDefaultsEffectiveWeight = "<?php echo $bfNoOfDefaultsEffectiveWeight; ?>" ;
		      localStorage.NoOfTraceAlertsEffectiveWeight = "<?php echo $bfNoOfTraceAlertsEffectiveWeight; ?>" ;  
   			  
			  //Small Firms
			  localStorage.LoanRateTypeEffectiveWeight = "<?php echo $sfLoanRateTypeEffectiveWeight; ?>" ;
			  localStorage.LoanMaturityEffectiveWeight = "<?php echo $sfLoanMaturityEffectiveWeight; ?>" ;
			  localStorage.BBSBankingRelationshipYearsEffectiveWeight = "<?php echo $sfBBSBankingRelationshipYearsEffectiveWeight; ?>" ;
			  localStorage.BBSBankingProductsNoEffectiveWeight = "<?php echo $sfBBSBankingProductsNoEffectiveWeight; ?>" ;
			  localStorage.PastYearArrearIncidentsNoEffectiveWeight = "<?php echo $sfPastYearArrearIncidentsNoEffectiveWeight; ?>" ;
			  localStorage.Past2YearsArrearLoansRenegotiatedNoEffectiveWeight = "<?php echo $sfPast2YearsArrearLoansRenegotiatedNoEffectiveWeight; ?>" ;
			  localStorage.PaidDebtExceedsDefaultsEffectiveWeight = "<?php echo $sfPaidDebtExceedsDefaultsEffectiveWeight; ?>" ;
		      localStorage.NoOfJudgementsEffectiveWeight = "<?php echo $sfNoOfJudgementsEffectiveWeight; ?>" ;
		      localStorage.NoOfDefaultsEffectiveWeight = "<?php echo $sfNoOfDefaultsEffectiveWeight; ?>" ;
		      localStorage.NoOfTraceAlertsEffectiveWeight = "<?php echo $sfNoOfTraceAlertsEffectiveWeight; ?>" ;  
  
              console.log ("Finished Local Storage Assignment - Model Settings");
			  
}	  
function CompanyDataForm2_LoadData()
{
 		 document.CompanyDataForm2.application_ref.value 			=localStorage.application_ref;
	     document.CompanyDataForm2.company_reg_no.value 			=localStorage.company_reg_no;
	     document.CompanyDataForm2.CIF.value 						=localStorage.CIF;
		 document.CompanyDataForm2.loan_number.value				=localStorage.loan_number;
		 document.CompanyDataForm2.username.value 					=localStorage.username;
		 document.CompanyDataForm2.registration_year.value			=localStorage.registration_year;
         document.CompanyDataForm2.vat_reg_no.value					=localStorage.vat_reg_no;
		 document.CompanyDataForm2.customer_type.value				=localStorage.customer_type;  
         document.CompanyDataForm2.legal_name.value					=localStorage.legal_name;
         document.CompanyDataForm2.trading_name.value				=localStorage.trading_name;
         document.CompanyDataForm2.registration_country.value		=localStorage.registration_country;
         document.CompanyDataForm2.financial_year0.value			=localStorage.financial_year0;
         document.CompanyDataForm2.financial_year1.value			=localStorage.financial_year1;
         document.CompanyDataForm2.financial_year2.value			=localStorage.financial_year2;
         document.CompanyDataForm2.financial_year3.value			=localStorage.financial_year3;
         document.CompanyDataForm2.reporting_month_year0.value		=localStorage.reporting_month_year0;
         document.CompanyDataForm2.reporting_month_year1.value		=localStorage.reporting_month_year1;
		 document.CompanyDataForm2.reporting_month_year2.value		=localStorage.reporting_month_year2;
         document.CompanyDataForm2.reporting_month_year3.value		=localStorage.reporting_month_year3;
         document.CompanyDataForm2.audit_status_year0value			=localStorage.audit_status_year0;
         document.CompanyDataForm2.audit_status_year1.value			=localStorage.audit_status_year1;
		 document.CompanyDataForm2.audit_status_year2.value			=localStorage.audit_status_year2;
		 document.CompanyDataForm2.audit_status_year3.value			=localStorage.audit_status_year3;
		 document.CompanyDataForm2.real_inflation_year0.value		=localStorage.real_inflation_year0;
		 document.CompanyDataForm2.real_inflation_year1.value		=localStorage.real_inflation_year1;
         document.CompanyDataForm2.real_inflation_year2.value		=localStorage.real_inflation_year2;
         document.CompanyDataForm2.real_inflation_year3.value		=localStorage.real_inflation_year3;
         document.CompanyDataForm2.nominal_inflation_year0.value	=localStorage.nominal_inflation_year0;
         document.CompanyDataForm2.nominal_inflation_year1.value	=localStorage.nominal_inflation_year1;
         document.CompanyDataForm2.nominal_inflation_year2.value	=localStorage.nominal_inflation_year2;
         document.CompanyDataForm2.nominal_inflation_year3.value	=localStorage.nominal_inflation_year3;
         document.CompanyDataForm2.industrial_sector.value			=localStorage.industrial_sector;
         document.CompanyDataForm2.borrower_present_address.value	=localStorage.borrower_present_address;
         document.CompanyDataForm2.street_name_and_number.value		=localStorage.street_name_and_number;
         document.CompanyDataForm2.years_at_present_address.value	=localStorage.years_at_present_address;
         document.CompanyDataForm2.e_mail.value						=localStorage.e_mail;
         document.CompanyDataForm2.bond_plot.value					=localStorage.bond_plot;
	     document.CompanyDataForm2.location_of_acquired_real_estate.value=localStorage.location_of_acquired_real_estate;
         document.CompanyDataForm2.main_bank.value					=localStorage.main_bank;
         document.CompanyDataForm2.second_bank.value				=localStorage.second_bank;
         document.CompanyDataForm2.third_bank.value					=localStorage.third_bank;
  }   
	
function CompanyDataForm2_SaveData()
{
		   //Save Log into the local Storage Tracker DashBoard
		   
		   var today = new Date();
           var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		   var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		   localStorage.CompanyDataTrackerDateSaved = date;
		   localStorage.CompanyDataTrackerSavedBy = localStorage.username;
		     
		 
		 localStorage.CIF                               = document.CompanyDataForm2.CIF.value;
		 localStorage.registration_year                 = document.CompanyDataForm2.registration_year.value;
         localStorage.vat_reg_no                        = document.CompanyDataForm2.vat_reg_no.value;
		 localStorage.customer_type                     = document.CompanyDataForm2.customer_type.value;  
         localStorage.legal_name                        = document.CompanyDataForm2.legal_name.value;
         localStorage.trading_name                      = document.CompanyDataForm2.trading_name.value;
         localStorage.registration_country              = document.CompanyDataForm2.registration_country.value;
         localStorage.financial_year0                   = document.CompanyDataForm2.financial_year0.value;
         localStorage.financial_year1                   = document.CompanyDataForm2.financial_year1.value;
         localStorage.financial_year2                   = document.CompanyDataForm2.financial_year2.value;
         localStorage.financial_year3                   = document.CompanyDataForm2.financial_year3.value;
         localStorage.reporting_month_year0             = document.CompanyDataForm2.reporting_month_year0.value;
         localStorage.reporting_month_year1             = document.CompanyDataForm2.reporting_month_year1.value;
		 localStorage.reporting_month_year2             = document.CompanyDataForm2.reporting_month_year2.value;
         localStorage.reporting_month_year3             = document.CompanyDataForm2.reporting_month_year3.value;
         localStorage.audit_status_year0                = document.CompanyDataForm2.audit_status_year0.value;
         localStorage.audit_status_year1                = document.CompanyDataForm2.audit_status_year1.value;
		 localStorage.audit_status_year2                = document.CompanyDataForm2.audit_status_year2.value;
		 localStorage.audit_status_year3                = document.CompanyDataForm2.audit_status_year3.value;
		 localStorage.real_inflation_year0              = document.CompanyDataForm2.real_inflation_year0.value;
		 localStorage.real_inflation_year1              = document.CompanyDataForm2.real_inflation_year1.value;
         localStorage.real_inflation_year2              = document.CompanyDataForm2.real_inflation_year2.value;
         localStorage.real_inflation_year3              = document.CompanyDataForm2.real_inflation_year3.value;
         localStorage.nominal_inflation_year0           = document.CompanyDataForm2.nominal_inflation_year0.value;
         localStorage.nominal_inflation_year1           = document.CompanyDataForm2.nominal_inflation_year1.value;
         localStorage.nominal_inflation_year2           = document.CompanyDataForm2.nominal_inflation_year2.value;
         localStorage.nominal_inflation_year3           = document.CompanyDataForm2.nominal_inflation_year3.value;
         localStorage.industrial_sector                 = document.CompanyDataForm2.industrial_sector.value;
         localStorage.borrower_present_address          = document.CompanyDataForm2.borrower_present_address.value;
         localStorage.street_name_and_number            = document.CompanyDataForm2.street_name_and_number.value;
         localStorage.years_at_present_address          = document.CompanyDataForm2.years_at_present_address.value;
         localStorage.e_mail                            = document.CompanyDataForm2.e_mail.value;
         localStorage.bond_plot                         = document.CompanyDataForm2.bond_plot.value;
	     localStorage.location_of_acquired_real_estate  = document.CompanyDataForm2.location_of_acquired_real_estate.value;
         localStorage.main_bank                         = document.CompanyDataForm2.main_bank.value;
         localStorage.second_bank                       = document.CompanyDataForm2.second_bank .value;
         localStorage.third_bank                        = document.CompanyDataForm2.third_bank.value;
          
         if (CompanyData_Validate()){
		    alert ("Company Data temporarilly saved(overwritten) to Local Machine");
		 }}    

function LoanDataForm_LoadData()
{
         document.LoanDataForm.loan_type.value =  localStorage.loan_type;
         document.LoanDataForm.loan_amount.value =  localStorage.loan_amount;
         document.LoanDataForm.property_type.value =  localStorage.property_type;
         document.LoanDataForm.open_market_value.value =  localStorage.open_market_value;
         document.LoanDataForm.loan_maturity.value =  localStorage.loan_maturity;
         document.LoanDataForm.rate_type.value =  localStorage.rate_type;
         document.LoanDataForm.irate.value =  localStorage.irate;
         document.LoanDataForm.insurance_replacement.value =  localStorage.insurance_replacement;
         document.LoanDataForm.insurance_premium.value =  localStorage.insurance_premium;
         document.LoanDataForm.loan_installment.value =  localStorage.loan_installment;
         document.LoanDataForm.loanandinsurance.value =  localStorage.loanandinsurance;
         document.LoanDataForm.ltv_policy.value =  localStorage.ltv_policy;
         document.LoanDataForm.ltv.value =  localStorage.ltv;
         document.LoanDataForm.rent.value =  localStorage.rent;
         document.LoanDataForm.relationship.value =  localStorage.relationship;
         document.LoanDataForm.Savings.value =  localStorage.Savings;
         document.LoanDataForm.Deposit.value =  localStorage.Deposit;
         document.LoanDataForm.Share.value =  localStorage.Share;
         document.LoanDataForm.ST.value =  localStorage.ST;
         document.LoanDataForm.Mortgages.value =  localStorage.Mortgages;
         document.LoanDataForm.total_bbs_products.value =  localStorage.total_bbs_products;
         document.LoanDataForm.loan_arrears.value =  localStorage.loan_arrears;
         document.LoanDataForm.renegotiate.value =  localStorage.renegotiate;
         document.LoanDataForm.why_renogotiation.value =  localStorage.why_renogotiation;
         document.LoanDataForm.LoanName1.value =  localStorage.LoanName1;
         document.LoanDataForm.LoanName2.value =  localStorage.LoanName2;
         document.LoanDataForm.LoanName3.value =  localStorage.LoanName3;
         document.LoanDataForm.LoanName4.value =  localStorage.LoanName4;
         document.LoanDataForm.LoanName5.value =  localStorage.LoanName5;
         document.LoanDataForm.LoanName6.value =  localStorage.LoanName6;
         document.LoanDataForm.LoanName7.value =  localStorage.LoanName7;
         document.LoanDataForm.LoanName8.value =  localStorage.LoanName8;
         document.LoanDataForm.LoanName9.value =  localStorage.LoanName9;
         document.LoanDataForm.LoanInstalment1.value =  localStorage.LoanInstalment1;
         document.LoanDataForm.LoanInstalment2.value =  localStorage.LoanInstalment2;
         document.LoanDataForm.LoanInstalment3.value =  localStorage.LoanInstalment3;
         document.LoanDataForm.LoanInstalment4.value =  localStorage.LoanInstalment4;
         document.LoanDataForm.LoanInstalment5.value =  localStorage.LoanInstalment5;
         document.LoanDataForm.LoanInstalment6.value =  localStorage.LoanInstalment6;
         document.LoanDataForm.LoanInstalment7.value =  localStorage.LoanInstalment7;
         document.LoanDataForm.LoanInstalment8.value =  localStorage.LoanInstalment8;
         document.LoanDataForm.LoanInstalment9.value =  localStorage.LoanInstalment9;
         document.LoanDataForm.TotalInstalments.value =  localStorage.TotalInstalments;
         document.LoanDataForm.loans_outstanding.value =  localStorage.loans_outstanding;
         document.LoanDataForm.itc_ref.value =  localStorage.itc_ref;
         document.LoanDataForm.paid_debts.value =  localStorage.paid_debts;
         document.LoanDataForm.judgement.value =  localStorage.judgement;
         document.LoanDataForm.default_data.value =  localStorage.default_data;
         document.LoanDataForm.trace_alerts.value =  localStorage.trace_alerts;
         document.LoanDataForm.blacklisted.value =  localStorage.blacklisted;
         document.LoanDataForm.fraud_alert.value =  localStorage.fraud_alert;
         document.LoanDataForm.deduct.value =  localStorage.deduct;
	
}
function LoanDataForm_SaveData()
{
		   //Save Log into the local Storage Tracker DashBoard
		   
		   var today = new Date();
           var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		   var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		   localStorage.LoanDataTrackerDateSaved = date;
		   localStorage.LoanDataTrackerSavedBy = localStorage.username;
	

       localStorage.loan_type             =  document.LoanDataForm.loan_type.value;
       localStorage.loan_amount           =  document.LoanDataForm.loan_amount.value;
       localStorage.property_type         =  document.LoanDataForm.property_type.value;
       localStorage.open_market_value     =  document.LoanDataForm.open_market_value.value;
       localStorage.loan_maturity         =  document.LoanDataForm.loan_maturity.value;
       localStorage.rate_type             =  document.LoanDataForm.rate_type.value;
       localStorage.irate                 =  document.LoanDataForm.irate.value;
       localStorage.insurance_replacement =  document.LoanDataForm.insurance_replacement.value;
       localStorage.insurance_premium     =  document.LoanDataForm.insurance_premium.value;
       localStorage.loan_installment      =  document.LoanDataForm.loan_installment.value;
       localStorage.loanandinsurance      =  document.LoanDataForm.loanandinsurance.value;
       localStorage.ltv_policy            =  document.LoanDataForm.ltv_policy.value;
       localStorage.ltv                   =  document.LoanDataForm.ltv.value;
       localStorage.rent                  =  document.LoanDataForm.rent.value;
       localStorage.relationship          =  document.LoanDataForm.relationship.value;
       localStorage.Savings               =  document.LoanDataForm.Savings.value;
       localStorage.Deposit               =  document.LoanDataForm.Deposit.value;
       localStorage.Share                 =  document.LoanDataForm.Share.value;
       localStorage.ST                    =  document.LoanDataForm.ST.value;
       localStorage.Mortgages             =  document.LoanDataForm.Mortgages.value;
       localStorage.total_bbs_products    =  document.LoanDataForm.total_bbs_products.value;
       localStorage.loan_arrears          =  document.LoanDataForm.loan_arrears.value;
       localStorage.renegotiate           =  document.LoanDataForm.renegotiate.value;
       localStorage.why_renogotiation     =  document.LoanDataForm.why_renogotiation.value;
       localStorage.LoanName1             =  document.LoanDataForm.LoanName1.value;
       localStorage.LoanName2             =  document.LoanDataForm.LoanName2.value;
       localStorage.LoanName3             =  document.LoanDataForm.LoanName3.value;
       localStorage.LoanName4             =  document.LoanDataForm.LoanName4.value;
       localStorage.LoanName5             =  document.LoanDataForm.LoanName5.value;
       localStorage.LoanName6             =  document.LoanDataForm.LoanName6.value;
       localStorage.LoanName7             =  document.LoanDataForm.LoanName7.value;
       localStorage.LoanName8             =  document.LoanDataForm.LoanName8.value;
       localStorage.LoanName9             =  document.LoanDataForm.LoanName9.value;
       localStorage.LoanInstalment1       =  document.LoanDataForm.LoanInstalment1.value;
       localStorage.LoanInstalment2       =  document.LoanDataForm.LoanInstalment2.value;
       localStorage.LoanInstalment3       =  document.LoanDataForm.LoanInstalment3.value;
       localStorage.LoanInstalment4       =  document.LoanDataForm.LoanInstalment4.value;
       localStorage.LoanInstalment5       =  document.LoanDataForm.LoanInstalment5.value;
       localStorage.LoanInstalment6       =  document.LoanDataForm.LoanInstalment6.value;
       localStorage.LoanInstalment7       =  document.LoanDataForm.LoanInstalment7.value;
       localStorage.LoanInstalment8       =  document.LoanDataForm.LoanInstalment8.value;
       localStorage.LoanInstalment9       =  document.LoanDataForm.LoanInstalment9.value;
       localStorage.TotalInstalments      =  document.LoanDataForm.TotalInstalments.value;
       localStorage.loans_outstanding     =  document.LoanDataForm.loans_outstanding.value;
       localStorage.itc_ref               =  document.LoanDataForm.itc_ref.value;
       localStorage.paid_debts            =  document.LoanDataForm.paid_debts.value;
       localStorage.judgement             =  document.LoanDataForm.judgement.value;
       localStorage.default_data          =  document.LoanDataForm.default_data.value;
       localStorage.trace_alerts          =  document.LoanDataForm.trace_alerts.value;
       localStorage.blacklisted           =  document.LoanDataForm.blacklisted.value;
       localStorage.fraud_alert           =  document.LoanDataForm.fraud_alert.value;
       localStorage.deduct                =  document.LoanDataForm.deduct.value;
       alert ("Loan parameters successfully save to local storage. Press OK to save to database");
}

function ISForm_LoadData()
{
		   //1. Net Sales
	       document.forms["ISForm"]["NetSalesYear0"].value = Thousands_Separators(ToNumber(localStorage.NetSales0)) ;
	       document.forms["ISForm"]["NetSalesYear1"].value = Thousands_Separators(ToNumber(localStorage.NetSales1)) ;
	       document.forms["ISForm"]["NetSalesYear2"].value = Thousands_Separators(ToNumber(localStorage.NetSales2)) ;
	       document.forms["ISForm"]["NetSalesYear3"].value = Thousands_Separators(ToNumber(localStorage.NetSales3)) ;
		   
		   //2. Cost of Sales - Depreciation  
	       document.forms["ISForm"]["CosDepYear0"].value = Thousands_Separators(ToNumber(localStorage.CosDep0)) ;
  	       document.forms["ISForm"]["CosDepYear1"].value = Thousands_Separators(ToNumber(localStorage.CosDep1)) ;
 	       document.forms["ISForm"]["CosDepYear2"].value = Thousands_Separators(ToNumber(localStorage.CosDep2)) ;
 	       document.forms["ISForm"]["CosDepYear3"].value = Thousands_Separators(ToNumber(localStorage.CosDep3) );
		   
		   //3. Cost of Sales - Other
	       document.forms["ISForm"]["CosOtherYear0"].value = Thousands_Separators(ToNumber(localStorage.CosOther0)) ;
	       document.forms["ISForm"]["CosOtherYear1"].value = Thousands_Separators(ToNumber(localStorage.CosOther1)) ;
	       document.forms["ISForm"]["CosOtherYear2"].value = Thousands_Separators(ToNumber(localStorage.CosOther2)) ;
	       document.forms["ISForm"]["CosOtherYear3"].value = Thousands_Separators(ToNumber(localStorage.CosOther3));
		   
		   //4. Other Income Line 1
	       document.forms["ISForm"]["OtherIncomeLine1Year0"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine1_0)) ;
	       document.forms["ISForm"]["OtherIncomeLine1Year1"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine1_1)) ;
	       document.forms["ISForm"]["OtherIncomeLine1Year2"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine1_2)) ;
	       document.forms["ISForm"]["OtherIncomeLine1Year3"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine1_3)) ;
		   
		   //5. Other Income Line 2
	       document.forms["ISForm"]["OtherIncomeLine2Year0"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine2_0)) ;
	       document.forms["ISForm"]["OtherIncomeLine2Year1"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine2_1)) ;
	       document.forms["ISForm"]["OtherIncomeLine2Year2"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine2_2)) ;
	       document.forms["ISForm"]["OtherIncomeLine2Year3"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine2_3)) ;
		   
		   //6. Other Income Line 3
	       document.forms["ISForm"]["OtherIncomeLine3Year0"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine3_0)) ;
	       document.forms["ISForm"]["OtherIncomeLine3Year1"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine3_1)) ;
	       document.forms["ISForm"]["OtherIncomeLine3Year2"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine3_2)) ;
	       document.forms["ISForm"]["OtherIncomeLine3Year3"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine3_3)) ;
		   
		   //7. Other Income Line 4
	       document.forms["ISForm"]["OtherIncomeLine4Year0"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine4_0)) ;
	       document.forms["ISForm"]["OtherIncomeLine4Year1"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine4_1));
	       document.forms["ISForm"]["OtherIncomeLine4Year2"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine4_2)) ;
	       document.forms["ISForm"]["OtherIncomeLine4Year3"].value = Thousands_Separators(ToNumber(localStorage.OtherIncomeLine4_3)) ;
		   
		   //8. Opex Line - Staff Costs
	       document.forms["ISForm"]["StaffCostsYear0"].value = Thousands_Separators(ToNumber(localStorage.StaffCosts0)) ;
	       document.forms["ISForm"]["StaffCostsYear1"].value = Thousands_Separators(ToNumber(localStorage.StaffCosts1)) ;
	       document.forms["ISForm"]["StaffCostsYear2"].value = Thousands_Separators(ToNumber(localStorage.StaffCosts2)) ;
	       document.forms["ISForm"]["StaffCostsYear3"].value = Thousands_Separators(ToNumber(localStorage.StaffCosts3)) ;

		   //9. Opex Line - Directors Fees
	       document.forms["ISForm"]["DirectorsFeesYear0"].value = Thousands_Separators(ToNumber(localStorage.DirectorsFees0)) ;
	       document.forms["ISForm"]["DirectorsFeesYear1"].value = Thousands_Separators(ToNumber(localStorage.DirectorsFees1)) ;
	       document.forms["ISForm"]["DirectorsFeesYear2"].value = Thousands_Separators(ToNumber(localStorage.DirectorsFees2)) ;
	       document.forms["ISForm"]["DirectorsFeesYear3"].value = Thousands_Separators(ToNumber(localStorage.DirectorsFees3)) ;
		   
		   //10. Opex Line - Depreciation
	       document.forms["ISForm"]["DepreciationYear0"].value = Thousands_Separators(ToNumber(localStorage.Depreciation0)) ;
	       document.forms["ISForm"]["DepreciationYear1"].value = Thousands_Separators(ToNumber(localStorage.Depreciation1)) ;
	       document.forms["ISForm"]["DepreciationYear2"].value = Thousands_Separators(ToNumber(localStorage.Depreciation2)) ;
	       document.forms["ISForm"]["DepreciationYear3"].value = Thousands_Separators(ToNumber(localStorage.Depreciation3)) ;
		   
		   //11. Opex Line - Amortisation
	       document.forms["ISForm"]["AmortisationYear0"].value = Thousands_Separators(ToNumber(localStorage.Amortisation0)) ;
	       document.forms["ISForm"]["AmortisationYear1"].value = Thousands_Separators(ToNumber(localStorage.Amortisation1)) ;
	       document.forms["ISForm"]["AmortisationYear2"].value = Thousands_Separators(ToNumber(localStorage.Amortisation2)) ;
	       document.forms["ISForm"]["AmortisationYear3"].value = Thousands_Separators(ToNumber(localStorage.Amortisation3)) ;
		   
		   //12. Opex Line - NoNameOpex Line 1
	       document.forms["ISForm"]["NoNameOpexLine1Year0"].value = Thousands_Separators(ToNumber(localStorage.NoNameOpexLine1_0)) ;
	       document.forms["ISForm"]["NoNameOpexLine1Year1"].value = Thousands_Separators(ToNumber(localStorage.NoNameOpexLine1_1)) ;
	       document.forms["ISForm"]["NoNameOpexLine1Year2"].value = Thousands_Separators(ToNumber(localStorage.NoNameOpexLine1_2)) ;
	       document.forms["ISForm"]["NoNameOpexLine1Year3"].value = Thousands_Separators(ToNumber(localStorage.NoNameOpexLine1_3)) ;

           //13. Opex Line - NoNameOPex Line 2
	       document.forms["ISForm"]["NoNameOpexLine2Year0"].value = Thousands_Separators(ToNumber(localStorage.NoNameOpexLine2_0)) ;
	       document.forms["ISForm"]["NoNameOpexLine2Year1"].value = Thousands_Separators(ToNumber(localStorage.NoNameOpexLine2_1)) ;
	       document.forms["ISForm"]["NoNameOpexLine2Year2"].value = Thousands_Separators(ToNumber(localStorage.NoNameOpexLine2_2)) ;
	       document.forms["ISForm"]["NoNameOpexLine2Year3"].value = Thousands_Separators(ToNumber(localStorage.NoNameOpexLine2_3)) ;
		   
		   //14. Opex Line - Other
	       document.forms["ISForm"]["OtherOpexYear0"].value = Thousands_Separators(ToNumber(localStorage.OtherOpex0)) ;
	       document.forms["ISForm"]["OtherOpexYear1"].value = Thousands_Separators(ToNumber(localStorage.OtherOpex1)) ;
	       document.forms["ISForm"]["OtherOpexYear2"].value = Thousands_Separators(ToNumber(localStorage.OtherOpex2)) ;
 	       document.forms["ISForm"]["OtherOpexYear3"].value = Thousands_Separators(ToNumber(localStorage.OtherOpex3)) ;
           
		   //15. Net Finance Costs
 	       document.forms["ISForm"]["NetFinanceCostsYear0"].value = Thousands_Separators(ToNumber(localStorage.NetFinanceCosts0)) ;
	       document.forms["ISForm"]["NetFinanceCostsYear1"].value = Thousands_Separators(ToNumber(localStorage.NetFinanceCosts1)) ;
	       document.forms["ISForm"]["NetFinanceCostsYear2"].value = Thousands_Separators(ToNumber(localStorage.NetFinanceCosts2)) ;
 	       document.forms["ISForm"]["NetFinanceCostsYear3"].value = Thousands_Separators(ToNumber(localStorage.NetFinanceCosts3)) ;
            
		   //16. Income Tax
  	       document.forms["ISForm"]["IncomeTaxYear0"].value = Thousands_Separators(ToNumber(localStorage.IncomeTax0)) ;
 	       document.forms["ISForm"]["IncomeTaxYear1"].value = Thousands_Separators(ToNumber(localStorage.IncomeTax1)) ;
	       document.forms["ISForm"]["IncomeTaxYear2"].value = Thousands_Separators(ToNumber(localStorage.IncomeTax2)) ;
 	       document.forms["ISForm"]["IncomeTaxYear3"].value = Thousands_Separators(ToNumber(localStorage.IncomeTax3)) ;
             
		   //16. Deferred Tax
  	       document.forms["ISForm"]["DeferredTaxYear0"].value = Thousands_Separators(ToNumber(localStorage.DeferredTax0)) ;
 	       document.forms["ISForm"]["DeferredTaxYear1"].value = Thousands_Separators(ToNumber(localStorage.DeferredTax1)) ;
	       document.forms["ISForm"]["DeferredTaxYear2"].value = Thousands_Separators(ToNumber(localStorage.DeferredTax2)) ;
 	       document.forms["ISForm"]["DeferredTaxYear3"].value = Thousands_Separators(ToNumber(localStorage.DeferredTax3)) ;
 				   
           //17. Other Income Line Descriptions
 	       document.forms["ISForm"]["OtherIncomeDescLine1"].value = localStorage.OtherIncomeDescLine1 ;
	       document.forms["ISForm"]["OtherIncomeDescLine2"].value = localStorage.OtherIncomeDescLine2 ;
 	       document.forms["ISForm"]["OtherIncomeDescLine3"].value = localStorage.OtherIncomeDescLine3 ;
	       document.forms["ISForm"]["OtherIncomeDescLine4"].value = localStorage.OtherIncomeDescLine4 ;
          //18. Other Opex Line Descriptions
	       document.forms["ISForm"]["NoNameOpexDescLine1"].value = localStorage.NoNameOpexDescLine1 ;
 	       document.forms["ISForm"]["NoNameOpexDescLine2"].value = localStorage.NoNameOpexDescLine2 ;

 }

function CurrentAssetsForm_LoadData()
{
	  	//Loading Cash Balances
		document.forms["CurrentAssetsForm"]["CashBalYear0"].value = localStorage.CashBal0;
		document.forms["CurrentAssetsForm"]["CashBalYear1"].value = localStorage.CashBal1;
		document.forms["CurrentAssetsForm"]["CashBalYear2"].value = localStorage.CashBal2;
		document.forms["CurrentAssetsForm"]["CashBalYear3"].value = localStorage.CashBal3;
		
		//Loading Debtors
		document.forms["CurrentAssetsForm"]["AccountsReceivableYear0"].value = localStorage.AccountsReceivable0;
		document.forms["CurrentAssetsForm"]["AccountsReceivableYear1"].value = localStorage.AccountsReceivable1;
		document.forms["CurrentAssetsForm"]["AccountsReceivableYear2"].value = localStorage.AccountsReceivable2;
		document.forms["CurrentAssetsForm"]["AccountsReceivableYear3"].value = localStorage.AccountsReceivable3;
		//Loading Prepayments
		document.forms["CurrentAssetsForm"]["PrepaymentsYear0"].value = localStorage.Prepayments0;
		document.forms["CurrentAssetsForm"]["PrepaymentsYear1"].value = localStorage.Prepayments1;
		document.forms["CurrentAssetsForm"]["PrepaymentsYear2"].value = localStorage.Prepayments2;
		document.forms["CurrentAssetsForm"]["PrepaymentsYear3"].value = localStorage.Prepayments3;
		//Loading Prepaid Tax
		document.forms["CurrentAssetsForm"]["PrepaidTaxYear0"].value = localStorage.PrepaidTax0;
		document.forms["CurrentAssetsForm"]["PrepaidTaxYear1"].value = localStorage.PrepaidTax1;
		document.forms["CurrentAssetsForm"]["PrepaidTaxYear2"].value = localStorage.PrepaidTax2;
		document.forms["CurrentAssetsForm"]["PrepaidTaxYear3"].value = localStorage.PrepaidTax3;
		//Loading Inventory
		document.forms["CurrentAssetsForm"]["InventoryYear0"].value = localStorage.Inventory0;
		document.forms["CurrentAssetsForm"]["InventoryYear1"].value = localStorage.Inventory1;
		document.forms["CurrentAssetsForm"]["InventoryYear2"].value = localStorage.Inventory2;
		document.forms["CurrentAssetsForm"]["InventoryYear3"].value = localStorage.Inventory3;
		//Loading Other Current Assets NonInter Company Line 1
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year0"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine1_0;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year1"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine1_1;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year2"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine1_2;
	  	document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year3"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine1_3;
		//Loading Other Current Assets NonInter Company Line 2
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year0"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine2_0;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year1"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine2_1;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year2"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine2_2;
	  	document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year3"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine2_3;
		//Loading Other Current Assets NonInter Company Line 3
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year0"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine3_0;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year1"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine3_1;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year2"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine3_2;
	  	document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year3"].value = localStorage.OtherCurrentAssetsNonInterCompanyLine3_3;
	    //Loading Other Current Assets Inter Company Line 1
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year0"].value = localStorage.OtherCurrentAssetsInterCompanyLine1_0;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year1"].value = localStorage.OtherCurrentAssetsInterCompanyLine1_1;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year2"].value = localStorage.OtherCurrentAssetsInterCompanyLine1_2;
	  	document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year3"].value = localStorage.OtherCurrentAssetsInterCompanyLine1_3;
		//Loading Other Current Assets Inter Company Line 2
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year0"].value = localStorage.OtherCurrentAssetsInterCompanyLine2_0;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year1"].value = localStorage.OtherCurrentAssetsInterCompanyLine2_1;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year2"].value = localStorage.OtherCurrentAssetsInterCompanyLine2_2;
	  	document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year3"].value = localStorage.OtherCurrentAssetsInterCompanyLine2_3;
		//Loading Other Current Assets Inter Company Line 3
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year0"].value = localStorage.OtherCurrentAssetsInterCompanyLine3_0;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year1"].value = localStorage.OtherCurrentAssetsInterCompanyLine3_1;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year2"].value = localStorage.OtherCurrentAssetsInterCompanyLine3_2;
	  	document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year3"].value = localStorage.OtherCurrentAssetsInterCompanyLine3_3;
		//Loading Other Current Assets Non Inter Company Descriptions
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyDescLine1"].value = localStorage.OtherCurrentAssetsNonInterCompanyDescLine1;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyDescLine2"].value = localStorage.OtherCurrentAssetsNonInterCompanyDescLine2;
	  	document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyDescLine3"].value = localStorage.OtherCurrentAssetsNonInterCompanyDescLine3;
        //Loading Other Current Assets Inter Company Descriptions
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyDescLine1"].value = localStorage.OtherCurrentAssetsInterCompanyDescLine1;
		document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyDescLine2"].value = localStorage.OtherCurrentAssetsInterCompanyDescLine2;
	  	document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyDescLine3"].value = localStorage.OtherCurrentAssetsInterCompanyDescLine3;

	
	
		//Recalculate totals
		CurrentAssetsForm_Recalculate();
}
function CurrentLiabilitiesForm_LoadData()
{
	  	
		//Loading Bamk Overdraft
		document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear0"].value = localStorage.BankOverdraft0;
		document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear1"].value = localStorage.BankOverdraft1;
		document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear2"].value = localStorage.BankOverdraft2;
		document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear3"].value = localStorage.BankOverdraft3;
		
		//Loading Creditors
		document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear0"].value = localStorage.AccountsPayable0;
		document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear1"].value = localStorage.AccountsPayable1;
		document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear2"].value = localStorage.AccountsPayable2;
		document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear3"].value = localStorage.AccountsPayable3;
		//Loading Accruals
		document.forms["CurrentLiabilitiesForm"]["AccrualsYear0"].value = localStorage.Accruals0;
		document.forms["CurrentLiabilitiesForm"]["AccrualsYear1"].value = localStorage.Accruals1;
		document.forms["CurrentLiabilitiesForm"]["AccrualsYear2"].value = localStorage.Accruals2;
		document.forms["CurrentLiabilitiesForm"]["AccrualsYear3"].value = localStorage.Accruals3;
		//Loading Tax Payable
		document.forms["CurrentLiabilitiesForm"]["TaxPayableYear0"].value = localStorage.TaxPayable0;
		document.forms["CurrentLiabilitiesForm"]["TaxPayableYear1"].value = localStorage.TaxPayable1;
		document.forms["CurrentLiabilitiesForm"]["TaxPayableYear2"].value = localStorage.TaxPayable2;
		document.forms["CurrentLiabilitiesForm"]["TaxPayableYear3"].value = localStorage.TaxPayable3;
		//Loading Dividends Payable
		document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear0"].value = localStorage.DividendsPayable0;
		document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear1"].value = localStorage.DividendsPayable1;
		document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear2"].value = localStorage.DividendsPayable2;
		document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear3"].value = localStorage.DividendsPayable3;
		//Loading Current Portion Long Term Debt
		document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear0"].value = localStorage.CurrentPortionLongTermDebt0;
		document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear1"].value = localStorage.CurrentPortionLongTermDebt1;
		document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear2"].value = localStorage.CurrentPortionLongTermDebt2;
		document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear3"].value = localStorage.CurrentPortionLongTermDebt3;
		//Loading Other Current Liabilities NonInter Company Line 1
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year0"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_0;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year1"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_1;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year2"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_2;
	  	document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year3"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_3;
		//Loading Other Current Liabilities NonInter Company Line 2
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year0"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_0;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year1"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_1;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year2"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_2;
	  	document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year3"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_3;
		//Loading Other Current Liabilities NonInter Company Line 3
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year0"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_0;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year1"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_1;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year2"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_2;
	  	document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year3"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_3;
	    //Loading Other Current Liabilities Inter Company Line 1
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year0"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine1_0;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year1"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine1_1;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year2"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine1_2;
	  	document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year3"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine1_3;
		//Loading Other Current Liabilities Inter Company Line 2
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year0"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine2_0;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year1"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine2_1;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year2"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine2_2;
	  	document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year3"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine2_3;
		//Loading Other Current Liabilities Inter Company Line 3
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year0"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine3_0;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year1"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine3_1;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year2"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine3_2;
	  	document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year3"].value = localStorage.OtherCurrentLiabilitiesInterCompanyLine3_3;
		//Loading Other Current Liabilities Non Inter Company Descriptions
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyDescLine1"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyDescLine1;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyDescLine2"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyDescLine2;
	  	document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyDescLine3"].value = localStorage.OtherCurrentLiabilitiesNonInterCompanyDescLine3;
        //Loading Other Current Liabilities Inter Company Descriptions
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyDescLine1"].value = localStorage.OtherCurrentLiabilitiesInterCompanyDescLine1;
		document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyDescLine2"].value = localStorage.OtherCurrentLiabilitiesInterCompanyDescLine2;
        document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyDescLine3"].value = localStorage.OtherCurrentLiabilitiesInterCompanyDescLine3;

		//Recalculate totals
		CurrentLiabilitiesForm_Recalculate();
				
}
function NonCurrentAssets_LoadData()
{
	  	//Loading Opening NBV1
		document.forms["NonCurrentAssetsForm"]["OpeningNBVYear0"].value = localStorage.OpeningNBV0;
		//document.forms["NonCurrentAssetsForm"]["OpeningNBVYear2"].value = localStorage.OpeningNBV2;
		//document.forms["NonCurrentAssetsForm"]["OpeningNBVYear3"].value = localStorage.OpeningNBV3;
		
		//Loading Additions
		document.forms["NonCurrentAssetsForm"]["AdditionsYear0"].value = localStorage.Additions0;
		document.forms["NonCurrentAssetsForm"]["AdditionsYear1"].value = localStorage.Additions1;
		document.forms["NonCurrentAssetsForm"]["AdditionsYear2"].value = localStorage.Additions2;
		document.forms["NonCurrentAssetsForm"]["AdditionsYear3"].value = localStorage.Additions3;
		//Loading Revaluation
		document.forms["NonCurrentAssetsForm"]["RevaluationYear0"].value = localStorage.Revaluation0;
		document.forms["NonCurrentAssetsForm"]["RevaluationYear1"].value = localStorage.Revaluation1;
		document.forms["NonCurrentAssetsForm"]["RevaluationYear2"].value = localStorage.Revaluation2;
		document.forms["NonCurrentAssetsForm"]["RevaluationYear3"].value = localStorage.Revaluation3;
		//Loading Depreciation - Cost Of Sales
		document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear0"].value = localStorage.DepreciationCostOfSales0;
		document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear1"].value = localStorage.DepreciationCostOfSales1;
		document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear2"].value = localStorage.DepreciationCostOfSales2;
		document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear3"].value = localStorage.DepreciationCostOfSales3;
		//Loading Depreciation - Opex
		document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear0"].value = localStorage.DepreciationOpex0;
		document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear1"].value = localStorage.DepreciationOpex1;
		document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear2"].value = localStorage.DepreciationOpex2;
		document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear3"].value = localStorage.DepreciationOpex3;
		//Loading Other Movements PPE
		document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear0"].value = localStorage.OtherMovementsPPE0;
		document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear1"].value = localStorage.OtherMovementsPPE1;
		document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear2"].value = localStorage.OtherMovementsPPE2;
		document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear3"].value = localStorage.OtherMovementsPPE3;
		//Loading Other Non Current Assets Line 1
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year0"].value = localStorage.OtherNonCurrentAssetsLine1_0;
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year1"].value = localStorage.OtherNonCurrentAssetsLine1_1;
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year2"].value = localStorage.OtherNonCurrentAssetsLine1_2;
	  	document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year3"].value = localStorage.OtherNonCurrentAssetsLine1_3;
		//Loading Other Non Current Assets Line 2
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year0"].value = localStorage.OtherNonCurrentAssetsLine2_0;
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year1"].value = localStorage.OtherNonCurrentAssetsLine2_1;
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year2"].value = localStorage.OtherNonCurrentAssetsLine2_2;
	  	document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year3"].value = localStorage.OtherNonCurrentAssetsLine2_3;
		//Loading Other Non Current Assets Line 3
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year0"].value = localStorage.OtherNonCurrentAssetsLine3_0;
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year1"].value = localStorage.OtherNonCurrentAssetsLine3_1;
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year2"].value = localStorage.OtherNonCurrentAssetsLine3_2;
	  	document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year3"].value = localStorage.OtherNonCurrentAssetsLine3_3;
	       //Loading Land and Buildings NBV
		document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear0"].value = localStorage.LandBuildingsNBV0;
		document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear1"].value = localStorage.LandBuildingsNBV1;
		document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear2"].value = localStorage.LandBuildingsNBV2;
		document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear3"].value = localStorage.LandBuildingsNBV3;
		//Loading InvestmentProperty
		document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear0"].value = localStorage.InvestmentProperty0;
		document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear1"].value = localStorage.InvestmentProperty1;
		document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear2"].value = localStorage.InvestmentProperty2;
		document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear3"].value = localStorage.InvestmentProperty3;
		//Loading Intangible Assets
		document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear0"].value = localStorage.IntangibleAssets0;
		document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear1"].value = localStorage.IntangibleAssets1;
		document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear2"].value = localStorage.IntangibleAssets2;
	  	document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear3"].value = localStorage.IntangibleAssets3;
		//Loading PPE Comments
		document.forms["NonCurrentAssetsForm"]["PPEComments"].value = localStorage.PPEComments;
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsComments"].value = localStorage.OtherNonCurrentAssetsComments;
		//Loading Other Non Current Assets Descriptions
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsDescLine1"].value = localStorage.OtherNonCurrentAssetsDescLine1;
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsDescLine2"].value = localStorage.OtherNonCurrentAssetsDescLine2;
	  	document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsDescLine3"].value = localStorage.OtherNonCurrentAssetsDescLine3;
        //Loading Other Current Assets Inter Company Descriptions
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsDescLine1"].value = localStorage.OtherNonCurrentAssetsDescLine1;
		document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsDescLine2"].value = localStorage.OtherNonCurrentAssetsDescLine2;
	  	document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsDescLine3"].value = localStorage.OtherNonCurrentAssetsDescLine3;

		//Recalculate totals
		NonCurrentAssets_Recalculate();
 }
function NonCurrentLiabilitiesForm_LoadData()
{
	  	//Loading Mortgage Loans
		document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear0"].value = localStorage.MortgageLoans0;
		document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear1"].value = localStorage.MortgageLoans1;
		document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear2"].value = localStorage.MortgageLoans2;
		document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear3"].value = localStorage.MortgageLoans3;
		
		//Loading Term Loans
		document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear0"].value = localStorage.TermLoans0;
		document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear1"].value = localStorage.TermLoans1;
		document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear2"].value = localStorage.TermLoans2;
		document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear3"].value = localStorage.TermLoans3;
		//Loading Bonds
		document.forms["NonCurrentLiabilitiesForm"]["BondsYear0"].value = localStorage.Bonds0;
		document.forms["NonCurrentLiabilitiesForm"]["BondsYear1"].value = localStorage.Bonds1;
		document.forms["NonCurrentLiabilitiesForm"]["BondsYear2"].value = localStorage.Bonds2;
		document.forms["NonCurrentLiabilitiesForm"]["BondsYear3"].value = localStorage.Bonds3;
		//Loading Finance Leases
		document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear0"].value = localStorage.FinanceLeases0;
		document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear1"].value = localStorage.FinanceLeases1;
		document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear2"].value = localStorage.FinanceLeases2;
		document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear3"].value = localStorage.FinanceLeases3;
		//Loading OtherLongTermBorrowings
		document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear0"].value = localStorage.OtherLongTermBorrowings0;
		document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear1"].value = localStorage.OtherLongTermBorrowings1;
		document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear2"].value = localStorage.OtherLongTermBorrowings2;
		document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear3"].value = localStorage.OtherLongTermBorrowings3;
		//Loading Shareholders Loans
		document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear0"].value = localStorage.ShareholdersLoans0;
		document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear1"].value = localStorage.ShareholdersLoans1;
		document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear2"].value = localStorage.ShareholdersLoans2;
		document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear3"].value = localStorage.ShareholdersLoans3;
		//Loading Inter Company  Loan Line 1
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year0"].value = localStorage.InterCompanyLoansLine1_0;
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year1"].value = localStorage.InterCompanyLoansLine1_1;
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year2"].value = localStorage.InterCompanyLoansLine1_2;
	  	document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year3"].value = localStorage.InterCompanyLoansLine1_3;
		//Loading Inter Company  Loan Line 2
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year0"].value = localStorage.InterCompanyLoansLine2_0;
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year1"].value = localStorage.InterCompanyLoansLine2_1;
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year2"].value = localStorage.InterCompanyLoansLine2_2;
	  	document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year3"].value = localStorage.InterCompanyLoansLine2_3;
		//Loading Inter Company  Loan Line 3
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year0"].value = localStorage.InterCompanyLoansLine3_0;
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year1"].value = localStorage.InterCompanyLoansLine3_1;
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year2"].value = localStorage.InterCompanyLoansLine3_2;
	  	document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year3"].value = localStorage.InterCompanyLoansLine3_3;
	    //Loading Deferred Tax Balance
		document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear0"].value = localStorage.DeferredTaxBalance0;
		document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear1"].value = localStorage.DeferredTaxBalance1;
		document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear2"].value = localStorage.DeferredTaxBalance2;
		document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear3"].value = localStorage.DeferredTaxBalance3;
		//Loading Provisions
		document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear0"].value = localStorage.Provisions0;
		document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear1"].value = localStorage.Provisions1;
		document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear2"].value = localStorage.Provisions2;
		document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear3"].value = localStorage.Provisions3;
		//Loading Other Non Current Liabilities Line 1
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year0"].value = localStorage.OtherNonCurrentLiabilitiesLine1_0;
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year1"].value = localStorage.OtherNonCurrentLiabilitiesLine1_1;
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year2"].value = localStorage.OtherNonCurrentLiabilitiesLine1_2;
	  	document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year3"].value = localStorage.OtherNonCurrentLiabilitiesLine1_3;
		//Loading Other Non Current Liabilities Line 2
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year0"].value = localStorage.OtherNonCurrentLiabilitiesLine2_0;
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year1"].value = localStorage.OtherNonCurrentLiabilitiesLine2_1;
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year2"].value = localStorage.OtherNonCurrentLiabilitiesLine2_2;
	  	document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year3"].value = localStorage.OtherNonCurrentLiabilitiesLine2_3;
		//Loading Other Non Current Liabilities Line 3
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year0"].value = localStorage.OtherNonCurrentLiabilitiesLine3_0;
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year1"].value = localStorage.OtherNonCurrentLiabilitiesLine3_1;
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year2"].value = localStorage.OtherNonCurrentLiabilitiesLine3_2;
	  	document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year3"].value = localStorage.OtherNonCurrentLiabilitiesLine3_3;
		//Loading Other Current Assets Non Inter Company Descriptions
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansDescLine1"].value = localStorage.InterCompanyLoansDescLine1;
		document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansDescLine2"].value = localStorage.InterCompanyLoansDescLine2;
	  	document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansDescLine3"].value = localStorage.InterCompanyLoansDescLine3;
        //Loading Other Current Assets Inter Company Descriptions
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesDescLine1"].value = localStorage.OtherNonCurrentLiabilitiesDescLine1;
		document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesDescLine2"].value = localStorage.OtherNonCurrentLiabilitiesDescLine2;
	  	document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesDescLine3"].value = localStorage.OtherNonCurrentLiabilitiesDescLine3;

		//Recalculate totals
		NonCurrentLiabilitiesForm_Recalculate();
}
		
function EquityForm_LoadData()
{
	  	//Loading Opening Retained Profits
		document.forms["EquityForm"]["OpeningRetainedProfitsYear0"].value = localStorage.OpeningRetainedProfits0;
		//document.forms["EquityForm"]["OpeningRetainedProfitsYear2"].value = localStorage.OpeningRetainedProfits2;
		//document.forms["EquityForm"]["OpeningRetainedProfitsYear3"].value = localStorage.OpeningRetainedProfits3;
		
		//Loading ShareCapital
		document.forms["EquityForm"]["ShareCapitalYear0"].value = localStorage.ShareCapital0;
		document.forms["EquityForm"]["ShareCapitalYear1"].value = localStorage.ShareCapital1;
		document.forms["EquityForm"]["ShareCapitalYear2"].value = localStorage.ShareCapital2;
		document.forms["EquityForm"]["ShareCapitalYear3"].value = localStorage.ShareCapital3;
		//Loading SharePremium
		document.forms["EquityForm"]["SharePremiumYear0"].value = localStorage.SharePremium0;
		document.forms["EquityForm"]["SharePremiumYear1"].value = localStorage.SharePremium1;
		document.forms["EquityForm"]["SharePremiumYear2"].value = localStorage.SharePremium2;
		document.forms["EquityForm"]["SharePremiumYear3"].value = localStorage.SharePremium3;
	    //Loading Revaluation Reserve
		document.forms["EquityForm"]["RevaluationReserveYear0"].value = localStorage.RevaluationReserve0;
		document.forms["EquityForm"]["RevaluationReserveYear1"].value = localStorage.RevaluationReserve1;
		document.forms["EquityForm"]["RevaluationReserveYear2"].value = localStorage.RevaluationReserve2;
		document.forms["EquityForm"]["RevaluationReserveYear3"].value = localStorage.RevaluationReserve3;
		//Loading Net Profit
		document.forms["EquityForm"]["NetProfitYear0"].value = localStorage.NetProfit0;
		document.forms["EquityForm"]["NetProfitYear1"].value = localStorage.NetProfit1;
		document.forms["EquityForm"]["NetProfitYear2"].value = localStorage.NetProfit2;
		document.forms["EquityForm"]["NetProfitYear3"].value = localStorage.NetProfit3;
		//Loading Dividends
		document.forms["EquityForm"]["DividendsYear0"].value = localStorage.Dividends0;
		document.forms["EquityForm"]["DividendsYear1"].value = localStorage.Dividends1;
		document.forms["EquityForm"]["DividendsYear2"].value = localStorage.Dividends2;
		document.forms["EquityForm"]["DividendsYear3"].value = localStorage.Dividends3;
		//Loading Other Non Distributable Reserves Line 1
		document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year0"].value = localStorage.OtherNonDistributableReservesLine1_0;
		document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year1"].value = localStorage.OtherNonDistributableReservesLine1_1;
		document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year2"].value = localStorage.OtherNonDistributableReservesLine1_2;
	  	document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year3"].value = localStorage.OtherNonDistributableReservesLine1_3;
		//Loading Other Non Distributable Reserves Line 2
		document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year0"].value = localStorage.OtherNonDistributableReservesLine2_0;
		document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year1"].value = localStorage.OtherNonDistributableReservesLine2_1;
		document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year2"].value = localStorage.OtherNonDistributableReservesLine2_2;
	  	document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year3"].value = localStorage.OtherNonDistributableReservesLine2_3;

		//Loading Other Non Distributable Reserves Line 3
		document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year0"].value = localStorage.OtherNonDistributableReservesLine3_0;
		document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year1"].value = localStorage.OtherNonDistributableReservesLine3_1;
		document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year2"].value = localStorage.OtherNonDistributableReservesLine3_2;
	  	document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year3"].value = localStorage.OtherNonDistributableReservesLine3_3;

	       //Loading Other Distributable Reserves Line 1
		document.forms["EquityForm"]["OtherDistributableReservesLine1Year0"].value = localStorage.OtherDistributableReservesLine1_0;
		document.forms["EquityForm"]["OtherDistributableReservesLine1Year1"].value = localStorage.OtherDistributableReservesLine1_1;
		document.forms["EquityForm"]["OtherDistributableReservesLine1Year2"].value = localStorage.OtherDistributableReservesLine1_2;
	  	document.forms["EquityForm"]["OtherDistributableReservesLine1Year3"].value = localStorage.OtherDistributableReservesLine1_3;
				  
	    //Loading Other Distributable Reserves Line 2
		document.forms["EquityForm"]["OtherDistributableReservesLine2Year0"].value = localStorage.OtherDistributableReservesLine2_0;
		document.forms["EquityForm"]["OtherDistributableReservesLine2Year1"].value = localStorage.OtherDistributableReservesLine2_1;
		document.forms["EquityForm"]["OtherDistributableReservesLine2Year2"].value = localStorage.OtherDistributableReservesLine2_2;
	  	document.forms["EquityForm"]["OtherDistributableReservesLine2Year3"].value = localStorage.OtherDistributableReservesLine2_3;
		//Loading Other Distributable Reserves Line 3
		document.forms["EquityForm"]["OtherDistributableReservesLine3Year0"].value = localStorage.OtherDistributableReservesLine3_0;
		document.forms["EquityForm"]["OtherDistributableReservesLine3Year1"].value = localStorage.OtherDistributableReservesLine3_1;
		document.forms["EquityForm"]["OtherDistributableReservesLine3Year2"].value = localStorage.OtherDistributableReservesLine3_2;
	  	document.forms["EquityForm"]["OtherDistributableReservesLine3Year3"].value = localStorage.OtherDistributableReservesLine3_3;
		 //Loading Retained Profits Adjustments
		document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear0"].value = localStorage.RetainedProfitsAdjustments0;
		document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear1"].value = localStorage.RetainedProfitsAdjustments1;
		document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear2"].value = localStorage.RetainedProfitsAdjustments2;
		document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear3"].value = localStorage.RetainedProfitsAdjustments3;
		//Loading Other Non Distributable Reserves Line Descriptions
		document.forms["EquityForm"]["OtherNonDistributableReservesDescLine1"].value = localStorage.OtherNonDistributableReservesDescLine1;
		document.forms["EquityForm"]["OtherNonDistributableReservesDescLine2"].value = localStorage.OtherNonDistributableReservesDescLine2;
	  	document.forms["EquityForm"]["OtherNonDistributableReservesDescLine3"].value = localStorage.OtherNonDistributableReservesDescLine3;
        //Loading Other Distributable Reserves Line Descriptions
		document.forms["EquityForm"]["OtherDistributableReservesDescLine1"].value = localStorage.OtherDistributableReservesDescLine1;
		document.forms["EquityForm"]["OtherDistributableReservesDescLine2"].value = localStorage.OtherDistributableReservesDescLine2;
	  	document.forms["EquityForm"]["OtherDistributableReservesDescLine3"].value = localStorage.OtherDistributableReservesDescLine3;

		//Recalculate totals
		EquityForm_Recalculate();
}
//==============================================================================================================================================	
function LoadManagementAnalysisForm()
{
	
	      //Loading the ratings
	      document.getElementById("legal_name").innerHTML = localStorage.legal_name + " " + localStorage.customer_type;
		  document.ManagementAnalysisForm.application_ref.value = localStorage.application_ref;
		  document.ManagementAnalysisForm.company_reg_no.value = localStorage.company_reg_no;
		  document.ManagementAnalysisForm.username.value = localStorage.username;
		  document.ManagementAnalysisForm.loan_number.value = localStorage.loan_number;
		  
		  document.ManagementAnalysisForm.Commitment.value = localStorage.Commitment;
		  document.ManagementAnalysisForm.Integrity.value = localStorage.Integrity;
		  document.ManagementAnalysisForm.InformationQuality.value = localStorage.InformationQuality;
		  document.ManagementAnalysisForm.Leadership.value = localStorage.Leadership;
		  document.ManagementAnalysisForm.Strategy.value = localStorage.Strategy;
		  document.ManagementAnalysisForm.Structure.value = localStorage.Structure;
		  document.ManagementAnalysisForm.Management.value = localStorage.Management;
		  document.ManagementAnalysisForm.SuccessionPlanning.value = localStorage.SuccessionPlanning;
		  document.ManagementAnalysisForm.OrganisationalPlanning.value = localStorage.OrganisationalPlanning; 
		  
		  console.log (localStorage.Commitment);
		  //Loading the Justifications
		  document.ManagementAnalysisForm.CommitmentComment.value = localStorage.CommitmentComment;
		  document.ManagementAnalysisForm.IntegrityComment.value = localStorage.IntegrityComment;
		  document.ManagementAnalysisForm.InformationQualityComment.value = localStorage.InformationQualityComment;
		  document.ManagementAnalysisForm.LeadershipComment.value = localStorage.LeadershipComment;
		  document.ManagementAnalysisForm.StrategyComment.value = localStorage.StrategyComment;
		  document.ManagementAnalysisForm.StructureComment.value = localStorage.StructureComment;
		  document.ManagementAnalysisForm.ManagementComment.value = localStorage.ManagementComment;
		  document.ManagementAnalysisForm.SuccessionPlanningComment.value = localStorage.SuccessionPlanningComment;
		  document.ManagementAnalysisForm.OrganisationalPlanningComment.value = localStorage.OrganisationalPlanningComment; 
		  //Loading the Review Comments
		  document.ManagementAnalysisForm.CommitmentReviewComment.value = localStorage.CommitmentReviewComment;
		  document.ManagementAnalysisForm.IntegrityReviewComment.value = localStorage.IntegrityReviewComment;
		  document.ManagementAnalysisForm.InformationQualityReviewComment.value = localStorage.InformationQualityReviewComment;
		  document.ManagementAnalysisForm.LeadershipReviewComment.value = localStorage.LeadershipReviewComment;
		  document.ManagementAnalysisForm.StrategyReviewComment.value = localStorage.StrategyReviewComment;
		  document.ManagementAnalysisForm.StructureReviewComment.value = localStorage.StructureReviewComment;
		  document.ManagementAnalysisForm.ManagementReviewComment.value = localStorage.ManagementReviewComment;
		  document.ManagementAnalysisForm.SuccessionPlanningReviewComment.value = localStorage.SuccessionPlanningReviewComment;
		  document.ManagementAnalysisForm.OrganisationalPlanningReviewComment.value = localStorage.OrganisationalPlanningReviewComment; 
		  
}
	  
function LoadIndustryAnalysis()
{
 	     document.getElementById("legal_name").innerHTML = localStorage.legal_name + " " + localStorage.customer_type;
		 document.PortersForm.application_ref.value = localStorage.application_ref;
		 document.PortersForm.company_reg_no.value = localStorage.company_reg_no;
		 document.PortersForm.username.value = localStorage.username;
		 document.PortersForm.loan_number.value = localStorage.loan_number;
	        
		 
		 document.PortersForm.IndustryCyclicality.value =  localStorage.IndustryCyclicality;
		 document.PortersForm.IndustryPerformance.value =  localStorage.IndustryPerformance;
         console.log (document.PortersForm.IndustryPerformance.value);
		 
		 document.PortersForm.ThreatsOfNewEntryRating.value =  localStorage.ThreatsOfNewEntryRating;
         document.PortersForm.ThreatsOfNewEntryScore.value =  localStorage.ThreatsOfNewEntryScore;
         document.PortersForm.EntryCostsRating.value =  localStorage.EntryCostsRating;
         document.PortersForm.EntryCostsScore.value =  localStorage.EntryCostsScore;
         document.PortersForm.EntryCostsComment.value =  localStorage.EntryCostsComment;
         document.PortersForm.SpecialistKnowledgeRating.value =  localStorage.SpecialistKnowledgeRating;
         document.PortersForm.SpecialKnowledgeScore.value =  localStorage.SpecialKnowledgeScore;
         document.PortersForm.SpecialistKnowledgeComment.value =  localStorage.SpecialistKnowledgeComment;
         document.PortersForm.EconomiesOfScaleRating.value =  localStorage.EconomiesOfScaleRating;
         document.PortersForm.EconomiesOfScaleScore.value =  localStorage.EconomiesOfScaleScore;
         document.PortersForm.EconomiesOfScaleComment.value =  localStorage.EconomiesOfScaleComment;
         document.PortersForm.CostAdvantagesRating.value =  localStorage.CostAdvantagesRating;
         document.PortersForm.CostAdvantagesScore.value =  localStorage.CostAdvantagesScore;
         document.PortersForm.CostAdvantagesComment.value =  localStorage.CostAdvantagesComment;
         document.PortersForm.TechnologyProtectionRating.value =  localStorage.TechnologyProtectionRating;
         document.PortersForm.TechnologyProtectionScore.value =  localStorage.TechnologyProtectionScore;
         document.PortersForm.TechnologyProtectionComment.value =  localStorage.TechnologyProtectionComment;
         document.PortersForm.BarriersToEntryRating.value =  localStorage.BarriersToEntryRating;
         document.PortersForm.BarriersToEntryScore.value =  localStorage.BarriersToEntryScore;
         document.PortersForm.BarriersToEntryComment.value =  localStorage.BarriersToEntryComment;
         document.PortersForm.CompetitiveRivalryRating.value =  localStorage.CompetitiveRivalryRating;
         document.PortersForm.CompetitiveRivalryScore.value =  localStorage.CompetitiveRivalryScore;
         document.PortersForm.NumberOfCompetitorsRating.value =  localStorage.NumberOfCompetitorsRating;
         document.PortersForm.NumberOfCompetitorsScore.value =  localStorage.NumberOfCompetitorsScore;
         document.PortersForm.NumberOfCompetitorsComment.value =  localStorage.NumberOfCompetitorsComment;
         document.PortersForm.QualityDifferencesRating.value =  localStorage.QualityDifferencesRating;
         document.PortersForm.QualityDifferencesScore.value =  localStorage.QualityDifferencesScore;
         document.PortersForm.QualityDifferencesComment.value =  localStorage.QualityDifferencesComment;
         document.PortersForm.OtherDifferencesRating.value =  localStorage.OtherDifferencesRating;
         document.PortersForm.OtherDifferencesScore.value =  localStorage.OtherDifferencesScore;
         document.PortersForm.OtherDifferencesComment.value =  localStorage.OtherDifferencesComment;
         document.PortersForm.SwitchingCostsRating.value =  localStorage.SwitchingCostsRating;
         document.PortersForm.SwitchingCostsScore.value =  localStorage.SwitchingCostsScore;
         document.PortersForm.SwitchingCostsComment.value =  localStorage.SwitchingCostsComment;
         document.PortersForm.CustomerLoyaltyRating.value =  localStorage.CustomerLoyaltyRating;
         document.PortersForm.CustomerLoyaktyScore.value =  localStorage.CustomerLoyaktyScore;
         document.PortersForm.CustomerLoyaktyComment.value =  localStorage.CustomerLoyaktyComment;
         document.PortersForm.SupplierPowerRating.value =  localStorage.SupplierPowerRating;
         document.PortersForm.SupplierPowerScore.value =  localStorage.SupplierPowerScore;
         document.PortersForm.NumberOfSuppliersrsRating.value =  localStorage.NumberOfSuppliersrsRating;
         document.PortersForm.NumberOfSuppliersOverallScore.value =  localStorage.NumberOfSuppliersOverallScore;
         document.PortersForm.NumberOfSuppliersComment.value =  localStorage.NumberOfSuppliersComment;
         document.PortersForm.SizeOfSuppliersRating.value =  localStorage.SizeOfSuppliersRating;
         document.PortersForm.SizeOfSuppliersOverallScore.value =  localStorage.SizeOfSuppliersOverallScore;
         document.PortersForm.SizeOfSuppliersComment.value =  localStorage.SizeOfSuppliersComment;
         document.PortersForm.UniquenessOfServiceRating.value =  localStorage.UniquenessOfServiceRating;
         document.PortersForm.UniquenessOfServiceScore.value =  localStorage.UniquenessOfServiceScore;
         document.PortersForm.UniquenessOfServiceComment.value =  localStorage.UniquenessOfServiceComment;
         document.PortersForm.CostsOfSupplierChangeRating.value =  localStorage.CostsOfSupplierChangeRating;
         document.PortersForm.CostsOfSupplierChangeScore.value =  localStorage.CostsOfSupplierChangeScore;
         document.PortersForm.CostsOfSupplierChangeComment.value =  localStorage.CostsOfSupplierChangeComment;
         document.PortersForm.SupplierSwitchingCostsRating.value =  localStorage.SupplierSwitchingCostsRating;
         document.PortersForm.SupplierSwitchingCostsScore.value =  localStorage.SupplierSwitchingCostsScore;
         document.PortersForm.SupplierSwitchingCostsComment.value =  localStorage.SupplierSwitchingCostsComment;
         document.PortersForm.ThreatsOfSubstitutionRating.value =  localStorage.ThreatsOfSubstitutionRating;
         document.PortersForm.ThreatsOfSubstitutionScore.value =  localStorage.ThreatsOfSubstitutionScore;
         document.PortersForm.SubstitutePerfomanceRating.value =  localStorage.SubstitutePerfomanceRating;
         document.PortersForm.SubstitutePerformanceScore.value =  localStorage.SubstitutePerformanceScore;
         document.PortersForm.SubstitutePerfomanceComment.value =  localStorage.SubstitutePerfomanceComment;
         document.PortersForm.CostsOfSubstitutionRating.value =  localStorage.CostsOfSubstitutionRating;
         document.PortersForm.CostsOfSubstitutionScore.value =  localStorage.CostsOfSubstitutionScore;
         document.PortersForm.CostsOfSubstitutionComment.value =  localStorage.CostsOfSubstitutionComment;
         document.PortersForm.BuyerPowerRating.value =  localStorage.BuyerPowerRating;
         document.PortersForm.BuyerPowerScore.value =  localStorage.BuyerPowerScore;
         document.PortersForm.NumberOfCustomersRating.value =  localStorage.NumberOfCustomersRating;
         document.PortersForm.NumberOfCCustomersScore.value =  localStorage.NumberOfCCustomersScore;
         document.PortersForm.NumberOfCustomersComment.value =  localStorage.NumberOfCustomersComment;
         document.PortersForm.SingleOrderSizeRating.value =  localStorage.SingleOrderSizeRating;
         document.PortersForm.SingleOrderSizeScore.value =  localStorage.SingleOrderSizeScore;
         document.PortersForm.SingleOrderSizeComment.value =  localStorage.SingleOrderSizeComment;
         document.PortersForm.CompetitorDifferencesRating.value =  localStorage.CompetitorDifferencesRating;
         document.PortersForm.CompetitorDifferencesScore.value =  localStorage.CompetitorDifferencesScore;
         document.PortersForm.CompetitorDifferencesComment.value =  localStorage.CompetitorDifferencesComment;
         document.PortersForm.PriceSensitivityRating.value =  localStorage.PriceSensitivityRating;
         document.PortersForm.PriceSensitivityScore.value =  localStorage.PriceSensitivityScore;
         document.PortersForm.PriceSensitivityComment.value =  localStorage.PriceSensitivityComment;
         document.PortersForm.AbilityToSubstituteRating.value =  localStorage.AbilityToSubstituteRating;
         document.PortersForm.AbilityToSubstituteScore.value =  localStorage.AbilityToSubstituteScore;
         document.PortersForm.AbilityToSubstituteComment.value =  localStorage.AbilityToSubstituteComment;
         document.PortersForm.CustomersSwitchingCostsRating.value =  localStorage.CustomersSwitchingCostsRating;
         document.PortersForm.CustomerSwitchingCostsScore.value =  localStorage.CustomerSwitchingCostsScore;
         document.PortersForm.CustomersSwitchingCostsComment.value =  localStorage.CustomersSwitchingCostsComment;
         document.PortersForm.SummaryRating.value =  localStorage.SummaryRating;
         document.PortersForm.SummaryScore.value =  localStorage.SummaryScore;

}
function 	BenchmarkOverrideForm_LoadIndustryPolicyBenchmarks()

{
   console.log("Starting Indusrty Benchmarks Override Ratio Display");
   switch (localStorage.industrial_sector)
   {
     case "Trade":
 		console.log("Industrial Sector = "+localStorage.industrial_sector);
		console.log("Starting to show the industry benchmarks");
		console.log(localStorage.CurrentRatioBenchmark_Trade);
	    document.BenchmarksOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Trade;
 		document.BenchmarksOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Trade;
		document.BenchmarksOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWCBenchmark_Trade;
		document.BenchmarksOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Trade;
		document.BenchmarksOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Trade;
		document.BenchmarksOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Trade;
		document.BenchmarksOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Trade;
		document.BenchmarksOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Trade;
		document.BenchmarksOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Trade;
		document.BenchmarksOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Trade;
		document.BenchmarksOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Trade;
	    document.BenchmarksOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Trade;
		document.BenchmarksOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Trade;		
		break;
	 case "Finance And Business Services":
	    console.log("Industrial Sector = "+localStorage.industrial_sector);
		console.log("Starting to show the industry benchmarks");
		//console.log(localStorage.CurrentRatioBenchmark_RealEstate);
	    document.BenchmarksOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Finance;
		document.BenchmarksOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Finance;
		document.BenchmarksOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWCBenchmark_Finance;
		document.BenchmarksOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Finance;
		document.BenchmarksOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Finance;
		document.BenchmarksOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Finance;
		document.BenchmarksOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Finance;
		document.BenchmarksOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Finance;
		document.BenchmarksOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Finance;
		document.BenchmarksOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Finance;
		document.BenchmarksOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Finance;
	    document.BenchmarksOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Finance;
		document.BenchmarksOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Finance;
 	    break;
	 case "RealEstate":
	    console.log("Industrial Sector = "+localStorage.industrial_sector);
		console.log("Starting to show the Real Estate industry benchmarks");
		//console.log(localStorage.CurrentRatioBenchmark_RealEstate);
	    document.BenchmarksOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_RealEstate;

		document.BenchmarksOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_RealEstate;
		document.BenchmarksOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWCBenchmark_RealEstate;
		document.BenchmarksOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_RealEstate;
		document.BenchmarksOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_RealEstate;
		document.BenchmarksOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_RealEstate;
		document.BenchmarksOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_RealEstate;
		document.BenchmarksOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_RealEstate;
		document.BenchmarksOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_RealEstate;
		document.BenchmarksOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_RealEstate;
		document.BenchmarksOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_RealEstate;
	    document.BenchmarksOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_RealEstate;
		document.BenchmarksOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_RealEstate;
 	    break;
	 case "Manufacturing":
	    document.BenchmarksOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Manufacturing;
		document.BenchmarksOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Manufacturing;
		document.BenchmarksOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWCBenchmark_Manufacturing;
		document.BenchmarksOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Manufacturing;
		document.BenchmarksOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Manufacturing;
		document.BenchmarksOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Manufacturing;
		document.BenchmarksOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Manufacturing;
		document.BenchmarksOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Manufacturing;
		document.BenchmarksOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Manufacturing;
		document.BenchmarksOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Manufacturing;
		document.BenchmarksOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Manufacturing;
	    document.BenchmarksOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Manufacturing;
		document.BenchmarksOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Manufacturing;
 	    break;
	 case "Construction":
	    document.BenchmarksOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Construction;
		document.BenchmarksOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Construction;
		document.BenchmarksOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWCBenchmark_Construction;
		document.BenchmarksOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Construction;
		document.BenchmarksOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Construction;
		document.BenchmarksOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Construction;
		document.BenchmarksOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Construction;
		document.BenchmarksOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Construction;
		document.BenchmarksOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Construction;
		document.BenchmarksOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Construction;
		document.BenchmarksOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Construction;
	    document.BenchmarksOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Construction;
		document.BenchmarksOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Construction;
 	    break;
	 case "Agriculture":
	    document.BenchmarksOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Agriculture;
		document.BenchmarksOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Agriculture;
		document.BenchmarksOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWCBenchmark_Agriculture;
		document.BenchmarksOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Agriculture;
		document.BenchmarksOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Agriculture;
		document.BenchmarksOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Agriculture;
		document.BenchmarksOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Agriculture;
		document.BenchmarksOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Agriculture;
		document.BenchmarksOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Agriculture;
		document.BenchmarksOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Agriculture;
		document.BenchmarksOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Agriculture;
	    document.BenchmarksOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Agriculture;
		document.BenchmarksOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Agriculture;
 	    break;
	 case "Parastatals":
	    document.BenchmarksOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Parastatals;
		document.BenchmarksOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Parastatals;
		document.BenchmarksOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWCBenchmark_Parastatals;
		document.BenchmarksOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Parastatals;
		document.BenchmarksOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Parastatals;
		document.BenchmarksOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Parastatals;
		document.BenchmarksOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Parastatals;
		document.BenchmarksOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Parastatals;
		document.BenchmarksOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Parastatals;
		document.BenchmarksOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Parastatals;
		document.BenchmarksOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Parastatals;
	    document.BenchmarksOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Parastatals;
		document.BenchmarksOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Parastatals;
 	    break;
	 case "Transport And Communications":
	    document.BenchmarksOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Transport;
		document.BenchmarksOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Transport;
		document.BenchmarksOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWCBenchmark_Transport;
		document.BenchmarksOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Transport;
		document.BenchmarksOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Transport;
		document.BenchmarksOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Transport;
		document.BenchmarksOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Transport;
		document.BenchmarksOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Transport;
		document.BenchmarksOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Transport;
		document.BenchmarksOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Transport;
		document.BenchmarksOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Transport;
	    document.BenchmarksOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Transport;
		document.BenchmarksOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Transport;
	    break;
	 case "Mining":
	    document.BenchmarksOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Mining;
		document.BenchmarksOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Mining;
		document.BenchmarksOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWCBenchmark_Mining;
		document.BenchmarksOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Mining;
		document.BenchmarksOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Mining;
		document.BenchmarksOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Mining;
		document.BenchmarksOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Mining;
		document.BenchmarksOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Mining;
		document.BenchmarksOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Mining;
		document.BenchmarksOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Mining;
		document.BenchmarksOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Mining;
	    document.BenchmarksOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Mining;
		document.BenchmarksOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Mining;
 	    break;
	}	
}
function 	BenchmarkOverrideForm_LoadIndustryOverridesBenchmarks()

	  {
         //Loading industry benchmarks via ToNumber functions in case the local storage variables are undefined
         document.BenchmarksOverrideForm.application_ref.value  = localStorage.application_ref;
         document.BenchmarksOverrideForm.company_reg_no.value  = localStorage.company_reg_no;
         document.BenchmarksOverrideForm.loan_number.value  = localStorage.loan_number;
         document.BenchmarksOverrideForm.CurrentRatioOverrideBenchmarkType_.value  =  typeof(localStorage.CurrentRatioOverrideBenchmarkType_) == "undefined"?"":localStorage.CurrentRatioOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.CurrentRatioOverrideBenchmarkValue_.value  =  typeof(localStorage.CurrentRatioOverrideBenchmarkValue_) == "undefined"?"":localStorage.CurrentRatioOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.CurrentRatioOverrideComment_.value  =  typeof(localStorage.CurrentRatioOverrideComment_) == "undefined"?"":localStorage.CurrentRatioOverrideComment_;
         document.BenchmarksOverrideForm.CurrentRatioBenchmarkFirstApproval_.value  =  typeof(localStorage.CurrentRatioBenchmarkFirstApproval_) == "undefined"?"No":localStorage.CurrentRatioBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.CurrentRatioBenchmarkSecondApproval_.value  =  typeof(localStorage.CurrentRatioBenchmarkSecondApproval_) == "undefined"?"No":localStorage.CurrentRatioBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.DebtorDaysOverrideBenchmarkType_.value  =  typeof(localStorage.DebtorDaysOverrideBenchmarkType_) == "undefined"?"":localStorage.DebtorDaysOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.DebtorDaysOverrideBenchmarkValue_.value  =  typeof(localStorage.DebtorDaysOverrideBenchmarkValue_) == "undefined"?"":localStorage.DebtorDaysOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.DebtorDaysOverrideComment_.value  =  typeof(localStorage.DebtorDaysOverrideComment_) == "undefined"?"":localStorage.DebtorDaysOverrideComment_;
         document.BenchmarksOverrideForm.DebtorDaysBenchmarkFirstApproval_.value  =  typeof(localStorage.DebtorDaysBenchmarkFirstApproval_) == "undefined"?"No":localStorage.DebtorDaysBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.DebtorDaysBenchmarkSecondApproval_.value  =  typeof(localStorage.DebtorDaysBenchmarkSecondApproval_) == "undefined"?"No":localStorage.DebtorDaysBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.TurnoverToWCOverrideBenchmarkType_.value  =  typeof(localStorage.TurnoverToWCOverrideBenchmarkType_) == "undefined"?"":localStorage.TurnoverToWCOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.TurnoverToWCOverrideBenchmarkValue_.value  =  typeof(localStorage.TurnoverToWCOverrideBenchmarkValue_) == "undefined"?"":localStorage.TurnoverToWCOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.TurnoverToWCOverrideComment_.value  =  typeof(localStorage.TurnoverToWCOverrideComment_) == "undefined"?"":localStorage.TurnoverToWCOverrideComment_;
         document.BenchmarksOverrideForm.TurnoverToWCBenchmarkFirstApproval_.value  =  typeof(localStorage.TurnoverToWCBenchmarkFirstApproval_) == "undefined"?"No":localStorage.TurnoverToWCBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.TurnoverToWCBenchmarkSecondApproval_.value  =  typeof(localStorage.TurnoverToWCBenchmarkSecondApproval_) == "undefined"?"No":localStorage.TurnoverToWCBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.TurnoverGrowthOverrideBenchmarkType_.value  =  typeof(localStorage.TurnoverGrowthOverrideBenchmarkType_) == "undefined"?"":localStorage.TurnoverGrowthOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.TurnoverGrowthOverrideBenchmarkValue_.value  =  typeof(localStorage.TurnoverGrowthOverrideBenchmarkValue_) == "undefined"?"":localStorage.TurnoverGrowthOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.TurnoverGrowthOverrideComment_.value  =  typeof(localStorage.TurnoverGrowthOverrideComment_) == "undefined"?"":localStorage.TurnoverGrowthOverrideComment_;
         document.BenchmarksOverrideForm.TurnoverGrowthBenchmarkFirstApproval_.value  =  typeof(localStorage.TurnoverGrowthBenchmarkFirstApproval_) == "undefined"?"No":localStorage.TurnoverGrowthBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.TurnoverGrowthBenchmarkSecondApproval_.value  =  typeof(localStorage.TurnoverGrowthBenchmarkSecondApproval_) == "undefined"?"No":localStorage.TurnoverGrowthBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.GrossProfitMarginOverrideBenchmarkType_.value  =  typeof(localStorage.GrossProfitMarginOverrideBenchmarkType_) == "undefined"?"":localStorage.GrossProfitMarginOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.GrossProfitMarginOverrideBenchmarkValue_.value  =  typeof(localStorage.GrossProfitMarginOverrideBenchmarkValue_) == "undefined"?"":localStorage.GrossProfitMarginOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.GrossProfitMarginOverrideComment_.value  =  typeof(localStorage.GrossProfitMarginOverrideComment_) == "undefined"?"":localStorage.GrossProfitMarginOverrideComment_;
         document.BenchmarksOverrideForm.GrossProfitMarginBenchmarkFirstApproval_.value  =  typeof(localStorage.GrossProfitMarginBenchmarkFirstApproval_) == "undefined"?"No":localStorage.GrossProfitMarginBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.GrossProfitMarginBenchmarkSecondApproval_.value  =  typeof(localStorage.GrossProfitMarginBenchmarkSecondApproval_) == "undefined"?"No":localStorage.GrossProfitMarginBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.OperatingProfitMarginOverrideBenchmarkType_.value  =  typeof(localStorage.OperatingProfitMarginOverrideBenchmarkType_) == "undefined"?"":localStorage.OperatingProfitMarginOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.OperatingProfitMarginOverrideBenchmarkValue_.value  =  typeof(localStorage.OperatingProfitMarginOverrideBenchmarkValue_) == "undefined"?"":localStorage.OperatingProfitMarginOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.OperatingProfitMarginOverrideComment_.value  =  typeof(localStorage.OperatingProfitMarginOverrideComment_) == "undefined"?"":localStorage.OperatingProfitMarginOverrideComment_;
         document.BenchmarksOverrideForm.OperatingProfitMarginBenchmarkFirstApproval_.value  =  typeof(localStorage.OperatingProfitMarginBenchmarkFirstApproval_) == "undefined"?"No":localStorage.OperatingProfitMarginBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.OperatingProfitMarginBenchmarkSecondApproval_.value  =  typeof(localStorage.OperatingProfitMarginBenchmarkSecondApproval_) == "undefined"?"No":localStorage.OperatingProfitMarginBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.ROAOverrideBenchmarkType_.value  =  typeof(localStorage.ROAOverrideBenchmarkType_) == "undefined"?"":localStorage.ROAOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.ROAOverrideBenchmarkValue_.value  =  typeof(localStorage.ROAOverrideBenchmarkValue_) == "undefined"?"":localStorage.ROAOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.ROAOverrideComment_.value  =  typeof(localStorage.ROAOverrideComment_) == "undefined"?"":localStorage.ROAOverrideComment_;
         document.BenchmarksOverrideForm.ROABenchmarkFirstApproval_.value  =  typeof(localStorage.ROABenchmarkFirstApproval_) == "undefined"?"No":localStorage.ROABenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.ROABenchmarkSecondApproval_.value  =  typeof(localStorage.ROABenchmarkSecondApproval_) == "undefined"?"No":localStorage.ROABenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.ROIOverrideBenchmarkType_.value  =  typeof(localStorage.ROIOverrideBenchmarkType_) == "undefined"?"":localStorage.ROIOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.ROIOverrideBenchmarkValue_.value  =  typeof(localStorage.ROIOverrideBenchmarkValue_) == "undefined"?"":localStorage.ROIOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.ROIOverrideComment_.value  =  typeof(localStorage.ROIOverrideComment_) == "undefined"?"":localStorage.ROIOverrideComment_;
         document.BenchmarksOverrideForm.ROIBenchmarkFirstApproval_.value  =  typeof(localStorage.ROIBenchmarkFirstApproval_) == "undefined"?"No":localStorage.ROIBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.ROIBenchmarkSecondApproval_.value  =  typeof(localStorage.ROIBenchmarkSecondApproval_) == "undefined"?"No":localStorage.ROIBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.LongtermDebtToEquityOverrideBenchmarkType_.value  =  typeof(localStorage.LongtermDebtToEquityOverrideBenchmarkType_) == "undefined"?"":localStorage.LongtermDebtToEquityOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.LongtermDebtToEquityOverrideBenchmarkValue_.value  =  typeof(localStorage.LongtermDebtToEquityOverrideBenchmarkValue_) == "undefined"?"":localStorage.LongtermDebtToEquityOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.LongtermDebtToEquityOverrideComment_.value  =  typeof(localStorage.LongtermDebtToEquityOverrideComment_) == "undefined"?"":localStorage.LongtermDebtToEquityOverrideComment_;
         document.BenchmarksOverrideForm.LongtermDebtToEquityBenchmarkFirstApproval_.value  =  typeof(localStorage.LongtermDebtToEquityBenchmarkFirstApproval_) == "undefined"?"No":localStorage.LongtermDebtToEquityBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.LongtermDebtToEquityBenchmarkSecondApproval_.value  =  typeof(localStorage.LongtermDebtToEquityBenchmarkSecondApproval_) == "undefined"?"No":localStorage.LongtermDebtToEquityBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.DebtToTangibleNetWorthOverrideBenchmarkType_.value  =  typeof(localStorage.DebtToTangibleNetWorthOverrideBenchmarkType_) == "undefined"?"":localStorage.DebtToTangibleNetWorthOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.DebtToTangibleNetWorthOverrideBenchmarkValue_.value  =  typeof(localStorage.DebtToTangibleNetWorthOverrideBenchmarkValue_) == "undefined"?"":localStorage.DebtToTangibleNetWorthOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.DebtToTangibleNetWorthOverrideComment_.value  =  typeof(localStorage.DebtToTangibleNetWorthOverrideComment_) == "undefined"?"":localStorage.DebtToTangibleNetWorthOverrideComment_;
         document.BenchmarksOverrideForm.DebtToTangibleNetWorthBenchmarkFirstApproval_.value  =  typeof(localStorage.DebtToTangibleNetWorthBenchmarkFirstApproval_) == "undefined"?"No":localStorage.DebtToTangibleNetWorthBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.DebtToTangibleNetWorthBenchmarkSecondApproval_.value  =  typeof(localStorage.DebtToTangibleNetWorthBenchmarkSecondApproval_) == "undefined"?"No":localStorage.DebtToTangibleNetWorthBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.EquityToTotalAssetsOverrideBenchmarkType_.value  =  typeof(localStorage.EquityToTotalAssetsOverrideBenchmarkType_) == "undefined"?"":localStorage.EquityToTotalAssetsOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.EquityToTotalAssetsOverrideBenchmarkValue_.value  =  typeof(localStorage.EquityToTotalAssetsOverrideBenchmarkValue_) == "undefined"?"":localStorage.EquityToTotalAssetsOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.EquityToTotalAssetsOverrideComment_.value  =  typeof(localStorage.EquityToTotalAssetsOverrideComment_) == "undefined"?"":localStorage.EquityToTotalAssetsOverrideComment_;
         document.BenchmarksOverrideForm.EquityToTotalAssetsBenchmarkFirstApproval_.value  =  typeof(localStorage.EquityToTotalAssetsBenchmarkFirstApproval_) == "undefined"?"No":localStorage.EquityToTotalAssetsBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.EquityToTotalAssetsBenchmarkSecondApproval_.value  =  typeof(localStorage.EquityToTotalAssetsBenchmarkSecondApproval_) == "undefined"?"No":localStorage.EquityToTotalAssetsBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.InterestCoverOverrideBenchmarkType_.value  =  typeof(localStorage.InterestCoverOverrideBenchmarkType_) == "undefined"?"":localStorage.InterestCoverOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.InterestCoverOverrideBenchmarkValue_.value  =  typeof(localStorage.InterestCoverOverrideBenchmarkValue_) == "undefined"?"":localStorage.InterestCoverOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.InterestCoverOverrideComment_.value  =  typeof(localStorage.InterestCoverOverrideComment_) == "undefined"?"":localStorage.InterestCoverOverrideComment_;
         document.BenchmarksOverrideForm.InterestCoverBenchmarkFirstApproval_.value  =  typeof(localStorage.InterestCoverBenchmarkFirstApproval_) == "undefined"?"No":localStorage.InterestCoverBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.InterestCoverBenchmarkSecondApproval_.value  =  typeof(localStorage.InterestCoverBenchmarkSecondApproval_) == "undefined"?"No":localStorage.InterestCoverBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.EBITDAToDebtOverrideBenchmarkType_.value  =  typeof(localStorage.EBITDAToDebtOverrideBenchmarkType_) == "undefined"?"":localStorage.EBITDAToDebtOverrideBenchmarkType_;
         document.BenchmarksOverrideForm.EBITDAToDebtOverrideBenchmarkValue_.value  =  typeof(localStorage.EBITDAToDebtOverrideBenchmarkValue_) == "undefined"?"":localStorage.EBITDAToDebtOverrideBenchmarkValue_;
         document.BenchmarksOverrideForm.EBITDAToDebtOverrideComment_.value  =  typeof(localStorage.EBITDAToDebtOverrideComment_) == "undefined"?"":localStorage.EBITDAToDebtOverrideComment_;
         document.BenchmarksOverrideForm.EBITDAToDebtBenchmarkFirstApproval_.value  =  typeof(localStorage.EBITDAToDebtBenchmarkFirstApproval_) == "undefined"?"No":localStorage.EBITDAToDebtBenchmarkFirstApproval_;
         document.BenchmarksOverrideForm.EBITDAToDebtBenchmarkSecondApproval_.value  =  typeof(localStorage.EBITDAToDebtBenchmarkSecondApproval_) == "undefined"?"No":localStorage.EBITDAToDebtBenchmarkSecondApproval_;
         document.BenchmarksOverrideForm.BenchmarkOverrideFirstReviewerComment_.value  =  typeof(localStorage.BenchmarkOverrideFirstReviewerComment_) == "undefined"?"":localStorage.BenchmarkOverrideFirstReviewerComment_;
         document.BenchmarksOverrideForm.BenchmarkOverrideSecondReviewerComment_.value  =  typeof(localStorage.BenchmarkOverrideSecondReviewerComment_) == "undefined"?"":localStorage.BenchmarkOverrideSecondReviewerComment_;
         document.BenchmarksOverrideForm.username.value  = localStorage.username;
	  
}
function IndustryBenchmarksOverrideForm_LoadData()
{
   console.log("StartingmBechmarks Ratio Display");
   switch (localStorage.industrial_sector)
   {
     case "Trade":
	    console.log("Industrial Sector = "+localStorage.industrial_sector);
		console.log("Starting to show the industry benchmarks");
		console.log(CurrentRatioBenchmark_Trade);
		document.BenchmarkOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Trade;
		document.BenchmarkOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Trade;
		document.BenchmarkOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWC_Trade;
		document.BenchmarkOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Trade;
		document.BenchmarkOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Trade;
		document.BenchmarkOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Trade;
		document.BenchmarkOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Trade;
		document.BenchmarkOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Trade;
		document.BenchmarkOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Trade;
		document.BenchmarkOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Trade;
		document.BenchmarkOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Trade;
	    document.BenchmarkOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Trade;
		document.BenchmarkOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Trade;
		break;
	 case "Finance And Business Services":
	    console.log("Industrial Sector = "+localStorage.industrial_sector);
		console.log("Starting to show the industry benchmarks");
		console.log(CurrentRatioBenchmark_RealEsstate);
	    document.BenchmarkOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Finance;
		document.BenchmarkOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Finance;
		document.BenchmarkOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWC_Finance;
		document.BenchmarkOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Finance;
		document.BenchmarkOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Finance;
		document.BenchmarkOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Finance;
		document.BenchmarkOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Finance;
		document.BenchmarkOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Finance;
		document.BenchmarkOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Finance;
		document.BenchmarkOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Finance;
		document.BenchmarkOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Finance;
	    document.BenchmarkOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Finance;
		document.BenchmarkOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Finance;
 	    break;
	 case "RealEstate":
	    console.log("Industrial Sector = "+localStorage.industrial_sector);
		console.log("Starting to show the Real Estate industry benchmarks");
		console.log(localStorage.CurrentRatioBenchmark_RealEstate);
	    document.BenchmarkOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_RealEstate;

		document.BenchmarkOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_RealEstate;
		document.BenchmarkOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWCBenchmark_RealEstate;
		document.BenchmarkOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_RealEstate;
		document.BenchmarkOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_RealEstate;
		document.BenchmarkOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_RealEstate;
		document.BenchmarkOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_RealEstate;
		document.BenchmarkOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_RealEstate;
		document.BenchmarkOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_RealEstate;
		document.BenchmarkOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_RealEstate;
		document.BenchmarkOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_RealEstate;
	    document.BenchmarkOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_RealEstate;
		document.BenchmarkOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_RealEstate;
 	    break;
	 case "Manufacturing":
	    document.BenchmarkOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Manufacturing;
		document.BenchmarkOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Manufacturing;
		document.BenchmarkOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWC_Manufacturing;
		document.BenchmarkOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Manufacturing;
		document.BenchmarkOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Manufacturing;
		document.BenchmarkOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Manufacturing;
		document.BenchmarkOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Manufacturing;
		document.BenchmarkOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Manufacturing;
		document.BenchmarkOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Manufacturing;
		document.BenchmarkOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Manufacturing;
		document.BenchmarkOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Manufacturing;
	    document.BenchmarkOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Manufacturing;
		document.BenchmarkOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Manufacturing;
 	    break;
	 case "Construction":
	    document.BenchmarkOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Construction;
		document.BenchmarkOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Construction;
		document.BenchmarkOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWC_Construction;
		document.BenchmarkOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Construction;
		document.BenchmarkOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Construction;
		document.BenchmarkOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Construction;
		document.BenchmarkOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Construction;
		document.BenchmarkOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Construction;
		document.BenchmarkOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Construction;
		document.BenchmarkOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Construction;
		document.BenchmarkOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Construction;
	    document.BenchmarkOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Construction;
		document.BenchmarkOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Construction;
 	    break;
	 case "Agriculture":
	    document.BenchmarkOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Agriculture;
		document.BenchmarkOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Agriculture;
		document.BenchmarkOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWC_Agriculture;
		document.BenchmarkOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Agriculture;
		document.BenchmarkOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Agriculture;
		document.BenchmarkOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Agriculture;
		document.BenchmarkOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Agriculture;
		document.BenchmarkOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Agriculture;
		document.BenchmarkOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Agriculture;
		document.BenchmarkOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Agriculture;
		document.BenchmarkOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Agriculture;
	    document.BenchmarkOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Agriculture;
		document.BenchmarkOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Agriculture;
 	    break;
	 case "Parastatals":
	    document.BenchmarkOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Parastatals;
		document.BenchmarkOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Parastatals;
		document.BenchmarkOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWC_Parastatals;
		document.BenchmarkOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Parastatals;
		document.BenchmarkOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Parastatals;
		document.BenchmarkOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Parastatals;
		document.BenchmarkOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Parastatals;
		document.BenchmarkOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Parastatals;
		document.BenchmarkOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Parastatals;
		document.BenchmarkOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Parastatals;
		document.BenchmarkOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Parastatals;
	    document.BenchmarkOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Parastatals;
		document.BenchmarkOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Parastatals;
 	    break;
	 case "Transport And Communications":
	    document.BenchmarkOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Transport;
		document.BenchmarkOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Transport;
		document.BenchmarkOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWC_Transport;
		document.BenchmarkOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Transport;
		document.BenchmarkOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Transport;
		document.BenchmarkOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Transport;
		document.BenchmarkOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Transport;
		document.BenchmarkOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Transport;
		document.BenchmarkOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Transport;
		document.BenchmarkOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Transport;
		document.BenchmarkOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Transport;
	    document.BenchmarkOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Transport;
		document.BenchmarkOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Transport;
	    break;
	 case "Mining":
	    document.BenchmarkOverrideForm.CurrentRatioPolicyBenchmarkValue_.value = localStorage.CurrentRatioBenchmark_Mining;
		document.BenchmarkOverrideForm.DebtorDaysPolicyBenchmarkValue_.value = localStorage.DebtorDaysBenchmark_Mining;
		document.BenchmarkOverrideForm.TurnoverToWCPolicyBenchmarkValue_.value = localStorage.TurnoverToWC_Mining;
		document.BenchmarkOverrideForm.GrossProfitMarginPolicyBenchmarkValue_.value = localStorage.GrossProfitMarginBenchmark_Mining;
		document.BenchmarkOverrideForm.OperatingProfitMarginPolicyBenchmarkValue_.value = localStorage.OperatingProfitMarginBenchmark_Mining;
		document.BenchmarkOverrideForm.TurnoverGrowthPolicyBenchmarkValue_.value = localStorage.TurnoverGrowthBenchmark_Mining;
		document.BenchmarkOverrideForm.ROAPolicyBenchmarkValue_.value = localStorage.ROABenchmark_Mining;
		document.BenchmarkOverrideForm.ROIPolicyBenchmarkValue_.value = localStorage.ROIBenchmark_Mining;
		document.BenchmarkOverrideForm.LongtermDebtToEquityPolicyBenchmarkValue_.value = localStorage.LongtermDebtToEquityBenchmark_Mining;
		document.BenchmarkOverrideForm.DebtToTangibleNetWorthPolicyBenchmarkValue_.value = localStorage.DebtToTangibleNetWorthBenchmark_Mining;
		document.BenchmarkOverrideForm.EquityToTotalAssetsPolicyBenchmarkValue_.value = localStorage.EquityToTotalAssetsBenchmark_Mining;
	    document.BenchmarkOverrideForm.InterestCoverPolicyBenchmarkValue_.value = localStorage.InterestCoverBenchmark_Mining;
		document.BenchmarkOverrideForm.EBITDAToDebtPolicyBenchmarkValue_.value = localStorage.EBITDAToDebtBenchmark_Mining;
 	    break;
	}	
}
function ISForm_Recalculate()
{
			 
			 // Read input values from form into working placeholder variables
		   //1. Net Sales
	       var NetSales0 = ToNumber(document.forms["ISForm"]["NetSalesYear0"].value);
	       var NetSales1 = ToNumber(document.forms["ISForm"]["NetSalesYear1"].value);
	       var NetSales2 = ToNumber(document.forms["ISForm"]["NetSalesYear2"].value);    
		   var NetSales3 = ToNumber(document.forms["ISForm"]["NetSalesYear3"].value);  
		   
		   //2. Cost of Sales - Depreciation  
		   var CosDep0 = ToNumber(document.forms["ISForm"]["CosDepYear0"].value);
		   var CosDep1 = ToNumber(document.forms["ISForm"]["CosDepYear1"].value);
           var CosDep2 = ToNumber(document.forms["ISForm"]["CosDepYear2"].value);
		   var CosDep3 = ToNumber(document.forms["ISForm"]["CosDepYear3"].value);
		   
		   //3. Cost of Sales - Other
		   var CosOther0 = ToNumber(document.forms["ISForm"]["CosOtherYear0"].value);
		   var CosOther1 = ToNumber(document.forms["ISForm"]["CosOtherYear1"].value);
	       var CosOther2 = ToNumber(document.forms["ISForm"]["CosOtherYear2"].value);
		   var CosOther3 = ToNumber(document.forms["ISForm"]["CosOtherYear3"].value);
		   
		   //4. Other Income Line 1
		   var OtherIncomeLine1_0 = ToNumber(document.forms["ISForm"]["OtherIncomeLine1Year0"].value);
		   var OtherIncomeLine1_1 = ToNumber(document.forms["ISForm"]["OtherIncomeLine1Year1"].value);
	       var OtherIncomeLine1_2 = ToNumber(document.forms["ISForm"]["OtherIncomeLine1Year2"].value);
		   var OtherIncomeLine1_3 = ToNumber(document.forms["ISForm"]["OtherIncomeLine1Year3"].value);
		   
		   //5. Other Income Line 2
		   var OtherIncomeLine2_0 = ToNumber(document.forms["ISForm"]["OtherIncomeLine2Year0"].value);
		   var OtherIncomeLine2_1 = ToNumber(document.forms["ISForm"]["OtherIncomeLine2Year1"].value);
	       var OtherIncomeLine2_2 = ToNumber(document.forms["ISForm"]["OtherIncomeLine2Year2"].value);
		   var OtherIncomeLine2_3 = ToNumber(document.forms["ISForm"]["OtherIncomeLine2Year3"].value);
		   
		   //6. Other Income Line 3
		   var OtherIncomeLine3_0 = ToNumber(document.forms["ISForm"]["OtherIncomeLine3Year0"].value);
 		   var OtherIncomeLine3_1 = ToNumber(document.forms["ISForm"]["OtherIncomeLine3Year1"].value);
           var OtherIncomeLine3_2 = ToNumber(document.forms["ISForm"]["OtherIncomeLine3Year2"].value);
		   var OtherIncomeLine3_3 = ToNumber(document.forms["ISForm"]["OtherIncomeLine3Year3"].value);
		   
		   //7. Other Income Line 4
		   var OtherIncomeLine4_0 = ToNumber(document.forms["ISForm"]["OtherIncomeLine4Year0"].value);
		   var OtherIncomeLine4_1 = ToNumber(document.forms["ISForm"]["OtherIncomeLine4Year1"].value);
		   var OtherIncomeLine4_2 = ToNumber(document.forms["ISForm"]["OtherIncomeLine4Year2"].value);
		   var OtherIncomeLine4_3 = ToNumber(document.forms["ISForm"]["OtherIncomeLine4Year3"].value);
		   
		   //8. Opex Line - Staff Costs
		   var StaffCosts0 = ToNumber(document.forms["ISForm"]["StaffCostsYear0"].value);
		   var StaffCosts1 = ToNumber(document.forms["ISForm"]["StaffCostsYear1"].value);
		   var StaffCosts2 = ToNumber(document.forms["ISForm"]["StaffCostsYear2"].value);
		   var StaffCosts3 = ToNumber(document.forms["ISForm"]["StaffCostsYear3"].value);

		   //9. Opex Line - Directors Fees
		   var DirectorsFees0 = ToNumber(document.forms["ISForm"]["DirectorsFeesYear0"].value);
		   var DirectorsFees1 = ToNumber(document.forms["ISForm"]["DirectorsFeesYear1"].value);
		   var DirectorsFees2 = ToNumber(document.forms["ISForm"]["DirectorsFeesYear2"].value);
		   var DirectorsFees3 = ToNumber(document.forms["ISForm"]["DirectorsFeesYear3"].value);
		   
		   //10. Opex Line - Depreciation
		   var Depreciation0 = ToNumber(document.forms["ISForm"]["DepreciationYear0"].value);
		   var Depreciation1 = ToNumber(document.forms["ISForm"]["DepreciationYear1"].value);
		   var Depreciation2 = ToNumber(document.forms["ISForm"]["DepreciationYear2"].value);
		   var Depreciation3 = ToNumber(document.forms["ISForm"]["DepreciationYear3"].value);
		   
		   //11. Opex Line - Amortisation
		   var Amortisation0 = ToNumber(document.forms["ISForm"]["AmortisationYear0"].value);
		   var Amortisation1 = ToNumber(document.forms["ISForm"]["AmortisationYear1"].value);
		   var Amortisation2 = ToNumber(document.forms["ISForm"]["AmortisationYear2"].value);
		   var Amortisation3 = ToNumber(document.forms["ISForm"]["AmortisationYear3"].value);
		   
		   //12. Opex Line - NoNameOpex Line 1
		   var NoNameOpexLine1_0 = ToNumber(document.forms["ISForm"]["NoNameOpexLine1Year0"].value);
		   var NoNameOpexLine1_1 = ToNumber(document.forms["ISForm"]["NoNameOpexLine1Year1"].value);
		   var NoNameOpexLine1_2 = ToNumber(document.forms["ISForm"]["NoNameOpexLine1Year2"].value);
		   var NoNameOpexLine1_3 = ToNumber(document.forms["ISForm"]["NoNameOpexLine1Year3"].value);

           //13. Opex Line - NoNameOPex Line 2
		   var NoNameOpexLine2_0 = ToNumber(document.forms["ISForm"]["NoNameOpexLine2Year0"].value);
		   var NoNameOpexLine2_1 = ToNumber(document.forms["ISForm"]["NoNameOpexLine2Year1"].value);
	       var NoNameOpexLine2_2 = ToNumber(document.forms["ISForm"]["NoNameOpexLine2Year2"].value);
		   var NoNameOpexLine2_3 = ToNumber(document.forms["ISForm"]["NoNameOpexLine2Year3"].value);
		   
		   //14. Opex Line - Other
		   var OtherOpex0 = ToNumber(document.forms["ISForm"]["OtherOpexYear0"].value);
 		   var OtherOpex1 = ToNumber(document.forms["ISForm"]["OtherOpexYear1"].value);
           var OtherOpex2 = ToNumber(document.forms["ISForm"]["OtherOpexYear2"].value);
           var OtherOpex3 = ToNumber(document.forms["ISForm"]["OtherOpexYear3"].value);
           
		   //15. Net Finance Costs
           var NetFinanceCosts0 = ToNumber(document.forms["ISForm"]["NetFinanceCostsYear0"].value);
           var NetFinanceCosts1 = ToNumber(document.forms["ISForm"]["NetFinanceCostsYear1"].value);
		   var NetFinanceCosts2 = ToNumber(document.forms["ISForm"]["NetFinanceCostsYear2"].value);
		   var NetFinanceCosts3 = ToNumber(document.forms["ISForm"]["NetFinanceCostsYear3"].value);
           
		   //16. Income Tax
           var IncomeTax0 = ToNumber(document.forms["ISForm"]["IncomeTaxYear0"].value);
           var IncomeTax1 = ToNumber(document.forms["ISForm"]["IncomeTaxYear1"].value);
		   var IncomeTax2 = ToNumber(document.forms["ISForm"]["IncomeTaxYear2"].value);
		   var IncomeTax3 = ToNumber(document.forms["ISForm"]["IncomeTaxYear3"].value);
           
		   //16. Deferred Tax
           var DeferredTax0 = ToNumber(document.forms["ISForm"]["DeferredTaxYear0"].value);
           var DeferredTax1 = ToNumber(document.forms["ISForm"]["DeferredTaxYear1"].value);
		   var DeferredTax2 = ToNumber(document.forms["ISForm"]["DeferredTaxYear2"].value);
		   var DeferredTax3 = ToNumber(document.forms["ISForm"]["DeferredTaxYear3"].value);
		   
		   // RECALCULATING CALCULATED FIELDS
			
		   //1. Total Cost of Sales
	       var CosTotal0 = CosDep0 + CosOther0;
	       var CosTotal1 = CosDep1 + CosOther1;
	       var CosTotal2 = CosDep2 + CosOther2;
		   var CosTotal3 = CosDep3 + CosOther3;
		   
		   //2.Gross Profit
		   var GrossProfit0 = NetSales0 - CosTotal0;
		   var GrossProfit1 = NetSales1 - CosTotal1;
	       var GrossProfit2 = NetSales2 - CosTotal2;
		   var GrossProfit3 = NetSales3 - CosTotal3;
		   
		   //3. Total Other Income  
		   var OtherIncomeTotal0 = OtherIncomeLine1_0 + OtherIncomeLine2_0 + OtherIncomeLine3_0 + OtherIncomeLine4_0;
		   var OtherIncomeTotal1 = OtherIncomeLine1_1 + OtherIncomeLine2_1 + OtherIncomeLine3_1 + OtherIncomeLine4_1;
		   var OtherIncomeTotal2 = OtherIncomeLine1_2 + OtherIncomeLine2_2 + OtherIncomeLine3_2 + OtherIncomeLine4_2;
		   var OtherIncomeTotal3 = OtherIncomeLine1_3 + OtherIncomeLine2_3 + OtherIncomeLine3_3 + OtherIncomeLine4_3;
		   
		   //4. Total Opex
		   var OpexTotal0 = StaffCosts0 + DirectorsFees0 + Depreciation0 + Amortisation0 + NoNameOpexLine1_0 + NoNameOpexLine2_0 + OtherOpex0;
 		   var OpexTotal1 = StaffCosts1 + DirectorsFees1 + Depreciation1 + Amortisation1 + NoNameOpexLine1_1 + NoNameOpexLine2_1 + OtherOpex1;
           var OpexTotal2 = StaffCosts2 + DirectorsFees2 + Depreciation2 + Amortisation2 + NoNameOpexLine1_2 + NoNameOpexLine2_2 + OtherOpex2;
		   var OpexTotal3 = StaffCosts3 + DirectorsFees3 + Depreciation3 + Amortisation3 + NoNameOpexLine1_3 + NoNameOpexLine2_3 + OtherOpex3;
		   
		   //5. EBIT (Operating Profit)
		   var EBIT0 = GrossProfit0 + OtherIncomeTotal0 - OpexTotal0;
		   var EBIT1 = GrossProfit1 + OtherIncomeTotal1 - OpexTotal1;
           var EBIT2 = GrossProfit2 + OtherIncomeTotal2 - OpexTotal2; 
           var EBIT3 = GrossProfit3 + OtherIncomeTotal3 - OpexTotal3;

           //6. PBT (Profit Before Tax)
           var PBT0 = EBIT0 - NetFinanceCosts0;
           var PBT1 = EBIT1 - NetFinanceCosts1;
		   var PBT2 = EBIT2 - NetFinanceCosts2;
		   var PBT3 = EBIT3 - NetFinanceCosts3;
          //7. Taxation
           var Taxation0 = IncomeTax0 + DeferredTax0;
           var Taxation1 = IncomeTax1 + DeferredTax1;
		   var Taxation2 = IncomeTax2 + DeferredTax2;
		   var Taxation3 = IncomeTax3 + DeferredTax3;
         //7. Net Profit
           var NetProfit0 = PBT0 - Taxation0;
           var NetProfit1 = PBT1 - Taxation1;
		   var NetProfit2 = PBT2 - Taxation2;
		   var NetProfit3 = PBT3 - Taxation3;
			   
		   // DISPLAY THE CALCULATED FIELDS IN COMMA STYLE
	       
		   //1. Total Cost Of Sales
	       document.forms["ISForm"]["CosTotalYear0"].value = Thousands_Separators(CosTotal0);
	       document.forms["ISForm"]["CosTotalYear1"].value = Thousands_Separators(CosTotal1);
	       document.forms["ISForm"]["CosTotalYear2"].value = Thousands_Separators(CosTotal2);
		   document.forms["ISForm"]["CosTotalYear3"].value = Thousands_Separators(CosTotal3);
		   
		   //2. Gross Profit 
		   document.forms["ISForm"]["GrossProfitYear0"].value = Thousands_Separators(GrossProfit0);
		   document.forms["ISForm"]["GrossProfitYear1"].value = Thousands_Separators(GrossProfit1);
		   document.forms["ISForm"]["GrossProfitYear2"].value = Thousands_Separators(GrossProfit2);
		   document.forms["ISForm"]["GrossProfitYear3"].value = Thousands_Separators(GrossProfit3);
		   
		   //3. Total Other Income
		   document.forms["ISForm"]["OtherIncomeTotalYear0"].value = Thousands_Separators(OtherIncomeTotal0);
		   document.forms["ISForm"]["OtherIncomeTotalYear1"].value = Thousands_Separators(OtherIncomeTotal1);
		   document.forms["ISForm"]["OtherIncomeTotalYear2"].value = Thousands_Separators(OtherIncomeTotal2);
		   document.forms["ISForm"]["OtherIncomeTotalYear3"].value = Thousands_Separators(OtherIncomeTotal3);
		   
		   //4. Total Opex
		   document.forms["ISForm"]["OpexTotalYear0"].value = Thousands_Separators(OpexTotal0);
		   document.forms["ISForm"]["OpexTotalYear1"].value = Thousands_Separators(OpexTotal1);
		   document.forms["ISForm"]["OpexTotalYear2"].value = Thousands_Separators(OpexTotal2);
		   document.forms["ISForm"]["OpexTotalYear3"].value = Thousands_Separators(OpexTotal3);
		   
		   //5. EBIT
		   document.forms["ISForm"]["EBITYear0"].value = Thousands_Separators(EBIT0);
		   document.forms["ISForm"]["EBITYear1"].value = Thousands_Separators(EBIT1);
		   document.forms["ISForm"]["EBITYear2"].value = Thousands_Separators(EBIT2);
		   document.forms["ISForm"]["EBITYear3"].value = Thousands_Separators(EBIT3);
		   
		   //6. PBT
		   document.forms["ISForm"]["PBTYear0"].value = Thousands_Separators(PBT0);
		   document.forms["ISForm"]["PBTYear1"].value = Thousands_Separators(PBT1);
		   document.forms["ISForm"]["PBTYear2"].value = Thousands_Separators(PBT2);
		   document.forms["ISForm"]["PBTYear3"].value = Thousands_Separators(PBT3);
		   //7. Taxation for the Year
		   document.forms["ISForm"]["TaxationYear0"].value = Thousands_Separators(Taxation0);
		   document.forms["ISForm"]["TaxationYear1"].value = Thousands_Separators(Taxation1);
		   document.forms["ISForm"]["TaxationYear2"].value = Thousands_Separators(Taxation2);
		   document.forms["ISForm"]["TaxationYear3"].value = Thousands_Separators(Taxation3);
		   //7. Net Profit
		   document.forms["ISForm"]["NetProfitYear0"].value = Thousands_Separators(NetProfit0);
		   document.forms["ISForm"]["NetProfitYear1"].value = Thousands_Separators(NetProfit1);
		   document.forms["ISForm"]["NetProfitYear2"].value = Thousands_Separators(NetProfit2);
		   document.forms["ISForm"]["NetProfitYear3"].value = Thousands_Separators(NetProfit3);
		   
}
function CurrentAssetsForm_Recalculate()
{
			 
			 // Read input values from form into working placeholder variables
		   //1. Cash and Cash Equivalents
	       var CashBal0 = ToNumber(document.forms["CurrentAssetsForm"]["CashBalYear0"].value);
	       var CashBal1 = ToNumber(document.forms["CurrentAssetsForm"]["CashBalYear1"].value);
	       var CashBal2 = ToNumber(document.forms["CurrentAssetsForm"]["CashBalYear2"].value);    
		   var CashBal3 = ToNumber(document.forms["CurrentAssetsForm"]["CashBalYear3"].value);  
		   
		   //2.  Accounts receivable
		   var AccountsReceivable0 = ToNumber(document.forms["CurrentAssetsForm"]["AccountsReceivableYear0"].value);
           var AccountsReceivable1 = ToNumber(document.forms["CurrentAssetsForm"]["AccountsReceivableYear1"].value);
           var AccountsReceivable2 = ToNumber(document.forms["CurrentAssetsForm"]["AccountsReceivableYear2"].value);
		   var AccountsReceivable3 = ToNumber(document.forms["CurrentAssetsForm"]["AccountsReceivableYear3"].value);
		   
		   //3. PrepaidTax
		   var Prepayments0 = ToNumber(document.forms["CurrentAssetsForm"]["PrepaymentsYear0"].value);
	       var Prepayments1 = ToNumber(document.forms["CurrentAssetsForm"]["PrepaymentsYear1"].value);
	       var Prepayments2 = ToNumber(document.forms["CurrentAssetsForm"]["PrepaymentsYear2"].value);
		   var Prepayments3 = ToNumber(document.forms["CurrentAssetsForm"]["PrepaymentsYear3"].value);
		   
		   //4. Prepaid Tax
		   var PrepaidTax0 = ToNumber(document.forms["CurrentAssetsForm"]["PrepaidTaxYear0"].value);
	       var PrepaidTax1 = ToNumber(document.forms["CurrentAssetsForm"]["PrepaidTaxYear1"].value);
	       var PrepaidTax2 = ToNumber(document.forms["CurrentAssetsForm"]["PrepaidTaxYear2"].value);
		   var PrepaidTax3 = ToNumber(document.forms["CurrentAssetsForm"]["PrepaidTaxYear3"].value);
		  
		   //5. Inventory
		   var Inventory0 = ToNumber(document.forms["CurrentAssetsForm"]["InventoryYear0"].value);
	       var Inventory1 = ToNumber(document.forms["CurrentAssetsForm"]["InventoryYear1"].value);
	       var Inventory2 = ToNumber(document.forms["CurrentAssetsForm"]["InventoryYear2"].value);
		   var Inventory3 = ToNumber(document.forms["CurrentAssetsForm"]["InventoryYear3"].value);
		  
		   //6. Other Current Assets Non Inter Company Line 1
		   var OtherCurrentAssetsNonInterCompanyLine1_0 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year0"].value);
	       var OtherCurrentAssetsNonInterCompanyLine1_1 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year1"].value);
	       var OtherCurrentAssetsNonInterCompanyLine1_2 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year2"].value);
		   var OtherCurrentAssetsNonInterCompanyLine1_3 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year3"].value);
		   
		   //7. Other Current Assets Non Inter Company Line 2
		   var OtherCurrentAssetsNonInterCompanyLine2_0 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year0"].value);
	       var OtherCurrentAssetsNonInterCompanyLine2_1 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year1"].value);
	       var OtherCurrentAssetsNonInterCompanyLine2_2 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year2"].value);
		   var OtherCurrentAssetsNonInterCompanyLine2_3 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year3"].value);
		    
		   //8. Other Current Assets Non Inter Company Line 3
		   var OtherCurrentAssetsNonInterCompanyLine3_0 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year0"].value);
	       var OtherCurrentAssetsNonInterCompanyLine3_1 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year1"].value);
	       var OtherCurrentAssetsNonInterCompanyLine3_2 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year2"].value);
		   var OtherCurrentAssetsNonInterCompanyLine3_3 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year3"].value);
		  
		   //9. Other Current Assets Non Inter Company Line 1
		   var OtherCurrentAssetsInterCompanyLine1_0 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year0"].value);
	       var OtherCurrentAssetsInterCompanyLine1_1 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year1"].value);
	       var OtherCurrentAssetsInterCompanyLine1_2 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year2"].value);
		   var OtherCurrentAssetsInterCompanyLine1_3 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year3"].value);
		   
		   //10. Other Current Assets Non Inter Company Line 2
		   var OtherCurrentAssetsInterCompanyLine2_0 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year0"].value);
	       var OtherCurrentAssetsInterCompanyLine2_1 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year1"].value);
	       var OtherCurrentAssetsInterCompanyLine2_2 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year2"].value);
		   var OtherCurrentAssetsInterCompanyLine2_3 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year3"].value);
		    
		   //11. Other Current Assets Non Inter Company Line 3
		   var OtherCurrentAssetsInterCompanyLine3_0 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year0"].value);
	       var OtherCurrentAssetsInterCompanyLine3_1 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year1"].value);
	       var OtherCurrentAssetsInterCompanyLine3_2 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year2"].value);
		   var OtherCurrentAssetsInterCompanyLine3_3 = ToNumber(document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year3"].value);
		  
		    // RECALCULATING CALCULATED FIELDS
			 
		   //1. Other Current Assets Non Intercompany Total
	       var OtherCurrentAssetsNonInterCompanyTotal0 = OtherCurrentAssetsNonInterCompanyLine1_0 + OtherCurrentAssetsNonInterCompanyLine2_0 + OtherCurrentAssetsNonInterCompanyLine3_0;
	       var OtherCurrentAssetsNonInterCompanyTotal1 = OtherCurrentAssetsNonInterCompanyLine1_1 + OtherCurrentAssetsNonInterCompanyLine2_1 + OtherCurrentAssetsNonInterCompanyLine3_1;
	       var OtherCurrentAssetsNonInterCompanyTotal2 = OtherCurrentAssetsNonInterCompanyLine1_2 + OtherCurrentAssetsNonInterCompanyLine2_2 + OtherCurrentAssetsNonInterCompanyLine3_2;
		   var OtherCurrentAssetsNonInterCompanyTotal3 = OtherCurrentAssetsNonInterCompanyLine1_3 + OtherCurrentAssetsNonInterCompanyLine2_3 + OtherCurrentAssetsNonInterCompanyLine3_3;
		   
	       //2. Other Current Assets Intercompany Total
	       var OtherCurrentAssetsInterCompanyTotal0 = OtherCurrentAssetsInterCompanyLine1_0 + OtherCurrentAssetsInterCompanyLine2_0 + OtherCurrentAssetsInterCompanyLine3_0;
	       var OtherCurrentAssetsInterCompanyTotal1 = OtherCurrentAssetsInterCompanyLine1_1 + OtherCurrentAssetsInterCompanyLine2_1 + OtherCurrentAssetsInterCompanyLine3_1;
	       var OtherCurrentAssetsInterCompanyTotal2 = OtherCurrentAssetsInterCompanyLine1_2 + OtherCurrentAssetsInterCompanyLine2_2 + OtherCurrentAssetsInterCompanyLine3_2;
		   var OtherCurrentAssetsInterCompanyTotal3 = OtherCurrentAssetsInterCompanyLine1_3 + OtherCurrentAssetsInterCompanyLine2_3 + OtherCurrentAssetsInterCompanyLine3_3;
		   
		   //3. Total Current Assets  
		   var TotalCurrentAssets0 = CashBal0 + AccountsReceivable0 + Prepayments0 + PrepaidTax0 + Inventory0 + OtherCurrentAssetsNonInterCompanyTotal0 + OtherCurrentAssetsInterCompanyTotal0;
		   var TotalCurrentAssets1 = CashBal1 + AccountsReceivable1 + Prepayments1 + PrepaidTax1 + Inventory1 + OtherCurrentAssetsNonInterCompanyTotal1 + OtherCurrentAssetsInterCompanyTotal1;
		   var TotalCurrentAssets2 = CashBal2 + AccountsReceivable2 + Prepayments2 + PrepaidTax2 + Inventory2 + OtherCurrentAssetsNonInterCompanyTotal2 + OtherCurrentAssetsInterCompanyTotal2;
		   var TotalCurrentAssets3 = CashBal3 + AccountsReceivable3 + Prepayments3 + PrepaidTax3 + Inventory3 + OtherCurrentAssetsNonInterCompanyTotal3 + OtherCurrentAssetsInterCompanyTotal3;
		   
   
		   // DISPLAY THE CALCULATED FIELDS IN COMMA STYLE
	       
		   //1. Other Current Assets - Non Inter Company
	       document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyTotalYear0"].value = Thousands_Separators(OtherCurrentAssetsNonInterCompanyTotal0);
	       document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyTotalYear1"].value = Thousands_Separators(OtherCurrentAssetsNonInterCompanyTotal1);
	       document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyTotalYear2"].value = Thousands_Separators(OtherCurrentAssetsNonInterCompanyTotal2);
	       document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyTotalYear3"].value = Thousands_Separators(OtherCurrentAssetsNonInterCompanyTotal3);
	       
	       //2. Other Current Assets - Inter Company
	       document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyTotalYear0"].value = Thousands_Separators(OtherCurrentAssetsInterCompanyTotal0);
	       document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyTotalYear1"].value = Thousands_Separators(OtherCurrentAssetsInterCompanyTotal1);
	       document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyTotalYear2"].value = Thousands_Separators(OtherCurrentAssetsInterCompanyTotal2);
	       document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyTotalYear3"].value = Thousands_Separators(OtherCurrentAssetsInterCompanyTotal3);
			    
		   //3. Total Current Assets
		   document.forms["CurrentAssetsForm"]["TotalCurrentAssetsYear0"].value = Thousands_Separators(TotalCurrentAssets0);
		   document.forms["CurrentAssetsForm"]["TotalCurrentAssetsYear1"].value = Thousands_Separators(TotalCurrentAssets1);
		   document.forms["CurrentAssetsForm"]["TotalCurrentAssetsYear2"].value = Thousands_Separators(TotalCurrentAssets2);
		   document.forms["CurrentAssetsForm"]["TotalCurrentAssetsYear3"].value = Thousands_Separators(TotalCurrentAssets3);
		   
		   
}

function CurrentLiabilitiesForm_Recalculate()
{
			 
			 // Read input values from form into working placeholder variables
		   //1. Bank Overdraft
	       var BankOverdraft0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear0"].value);
	       var BankOverdraft1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear1"].value);
	       var BankOverdraft2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear2"].value);    
		   var BankOverdraft3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear3"].value);  
		   
		   //2.  Accounts Payable
		   var AccountsPayable0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear0"].value);
           var AccountsPayable1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear1"].value);
           var AccountsPayable2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear2"].value);
		   var AccountsPayable3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear3"].value);
		   
		   //3. TaxPayable
		   var Accruals0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["AccrualsYear0"].value);
	       var Accruals1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["AccrualsYear1"].value);
	       var Accruals2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["AccrualsYear2"].value);
		   var Accruals3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["AccrualsYear3"].value);
		   
		   //4. Prepaid Tax
		   var TaxPayable0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["TaxPayableYear0"].value);
	       var TaxPayable1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["TaxPayableYear1"].value);
	       var TaxPayable2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["TaxPayableYear2"].value);
		   var TaxPayable3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["TaxPayableYear3"].value);
		  
		   //5. Dividends Payable
		   var DividendsPayable0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear0"].value);
	       var DividendsPayable1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear1"].value);
	       var DividendsPayable2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear2"].value);
		   var DividendsPayable3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear3"].value);
		   
		   //6. Current Portion Of Long term Debt
		   var CurrentPortionLongTermDebt0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear0"].value);
	       var CurrentPortionLongTermDebt1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear1"].value);
	       var CurrentPortionLongTermDebt2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear2"].value);
		   var CurrentPortionLongTermDebt3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear3"].value);
		 
		   //7. Other Current Liabilities Non Inter Company Line 1
		   var OtherCurrentLiabilitiesNonInterCompanyLine1_0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year0"].value);
	       var OtherCurrentLiabilitiesNonInterCompanyLine1_1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year1"].value);
	       var OtherCurrentLiabilitiesNonInterCompanyLine1_2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year2"].value);
		   var OtherCurrentLiabilitiesNonInterCompanyLine1_3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year3"].value);
		   
		   //8. Other Current Liabilities Non Inter Company Line 2
		   var OtherCurrentLiabilitiesNonInterCompanyLine2_0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year0"].value);
	       var OtherCurrentLiabilitiesNonInterCompanyLine2_1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year1"].value);
	       var OtherCurrentLiabilitiesNonInterCompanyLine2_2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year2"].value);
		   var OtherCurrentLiabilitiesNonInterCompanyLine2_3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year3"].value);
		    
		   //9. Other Current Liabilities Non Inter Company Line 3
		   var OtherCurrentLiabilitiesNonInterCompanyLine3_0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year0"].value);
	       var OtherCurrentLiabilitiesNonInterCompanyLine3_1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year1"].value);
	       var OtherCurrentLiabilitiesNonInterCompanyLine3_2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year2"].value);
		   var OtherCurrentLiabilitiesNonInterCompanyLine3_3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year3"].value);
		  
		   //10. Other Current Liabilities Non Inter Company Line 1
		   var OtherCurrentLiabilitiesInterCompanyLine1_0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year0"].value);
	       var OtherCurrentLiabilitiesInterCompanyLine1_1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year1"].value);
	       var OtherCurrentLiabilitiesInterCompanyLine1_2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year2"].value);
		   var OtherCurrentLiabilitiesInterCompanyLine1_3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year3"].value);
		   
		   //11. Other Current Liabilities Non Inter Company Line 2
		   var OtherCurrentLiabilitiesInterCompanyLine2_0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year0"].value);
	       var OtherCurrentLiabilitiesInterCompanyLine2_1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year1"].value);
	       var OtherCurrentLiabilitiesInterCompanyLine2_2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year2"].value);
		   var OtherCurrentLiabilitiesInterCompanyLine2_3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year3"].value);
		    
		   //12. Other Current Liabilities Non Inter Company Line 3
		   var OtherCurrentLiabilitiesInterCompanyLine3_0 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year0"].value);
	       var OtherCurrentLiabilitiesInterCompanyLine3_1 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year1"].value);
	       var OtherCurrentLiabilitiesInterCompanyLine3_2 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year2"].value);
		   var OtherCurrentLiabilitiesInterCompanyLine3_3 = ToNumber(document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year3"].value);
		  
		    // RECALCULATING CALCULATED FIELDS
			 
		   //1. Other Current Liabilities Non Intercompany Total
	       var OtherCurrentLiabilitiesNonInterCompanyTotal0 = OtherCurrentLiabilitiesNonInterCompanyLine1_0 + OtherCurrentLiabilitiesNonInterCompanyLine2_0 + OtherCurrentLiabilitiesNonInterCompanyLine3_0;
	       var OtherCurrentLiabilitiesNonInterCompanyTotal1 = OtherCurrentLiabilitiesNonInterCompanyLine1_1 + OtherCurrentLiabilitiesNonInterCompanyLine2_1 + OtherCurrentLiabilitiesNonInterCompanyLine3_1;
	       var OtherCurrentLiabilitiesNonInterCompanyTotal2 = OtherCurrentLiabilitiesNonInterCompanyLine1_2 + OtherCurrentLiabilitiesNonInterCompanyLine2_2 + OtherCurrentLiabilitiesNonInterCompanyLine3_2;
		   var OtherCurrentLiabilitiesNonInterCompanyTotal3 = OtherCurrentLiabilitiesNonInterCompanyLine1_3 + OtherCurrentLiabilitiesNonInterCompanyLine2_3 + OtherCurrentLiabilitiesNonInterCompanyLine3_3;
		   
	       //2. Other Current Liabilities Intercompany Total
	       var OtherCurrentLiabilitiesInterCompanyTotal0 = OtherCurrentLiabilitiesInterCompanyLine1_0 + OtherCurrentLiabilitiesInterCompanyLine2_0 + OtherCurrentLiabilitiesInterCompanyLine3_0;
	       var OtherCurrentLiabilitiesInterCompanyTotal1 = OtherCurrentLiabilitiesInterCompanyLine1_1 + OtherCurrentLiabilitiesInterCompanyLine2_1 + OtherCurrentLiabilitiesInterCompanyLine3_1;
	       var OtherCurrentLiabilitiesInterCompanyTotal2 = OtherCurrentLiabilitiesInterCompanyLine1_2 + OtherCurrentLiabilitiesInterCompanyLine2_2 + OtherCurrentLiabilitiesInterCompanyLine3_2;
		   var OtherCurrentLiabilitiesInterCompanyTotal3 = OtherCurrentLiabilitiesInterCompanyLine1_3 + OtherCurrentLiabilitiesInterCompanyLine2_3 + OtherCurrentLiabilitiesInterCompanyLine3_3;
		   
		   //3. Total Current Liabilities  
		   var TotalCurrentLiabilities0 = BankOverdraft0 + AccountsPayable0 + Accruals0 + TaxPayable0 + DividendsPayable0 + CurrentPortionLongTermDebt0 + OtherCurrentLiabilitiesNonInterCompanyTotal0 + OtherCurrentLiabilitiesInterCompanyTotal0;
		   var TotalCurrentLiabilities1 = BankOverdraft1 + AccountsPayable1 + Accruals1 + TaxPayable1 + DividendsPayable1 + CurrentPortionLongTermDebt1 + OtherCurrentLiabilitiesNonInterCompanyTotal1 + OtherCurrentLiabilitiesInterCompanyTotal1;
		   var TotalCurrentLiabilities2 = BankOverdraft2 + AccountsPayable2 + Accruals2 + TaxPayable2 + DividendsPayable2 + CurrentPortionLongTermDebt2 + OtherCurrentLiabilitiesNonInterCompanyTotal2 + OtherCurrentLiabilitiesInterCompanyTotal2;
		   var TotalCurrentLiabilities3 = BankOverdraft3 + AccountsPayable3 + Accruals3 + TaxPayable3 + DividendsPayable3 + CurrentPortionLongTermDebt3 + OtherCurrentLiabilitiesNonInterCompanyTotal3 + OtherCurrentLiabilitiesInterCompanyTotal3;
		   
   
		   // DISPLAY THE CALCULATED FIELDS IN COMMA STYLE
	       
		   //1. Other Current Liabilities - Non Inter Company
	       document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyTotalYear0"].value = Thousands_Separators(OtherCurrentLiabilitiesNonInterCompanyTotal0);
	       document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyTotalYear1"].value = Thousands_Separators(OtherCurrentLiabilitiesNonInterCompanyTotal1);
	       document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyTotalYear2"].value = Thousands_Separators(OtherCurrentLiabilitiesNonInterCompanyTotal2);
	       document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyTotalYear3"].value = Thousands_Separators(OtherCurrentLiabilitiesNonInterCompanyTotal3);
	       
	       //2. Other Current Liabilities - Inter Company
	       document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyTotalYear0"].value = Thousands_Separators(OtherCurrentLiabilitiesInterCompanyTotal0);
	       document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyTotalYear1"].value = Thousands_Separators(OtherCurrentLiabilitiesInterCompanyTotal1);
	       document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyTotalYear2"].value = Thousands_Separators(OtherCurrentLiabilitiesInterCompanyTotal2);
	       document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyTotalYear3"].value = Thousands_Separators(OtherCurrentLiabilitiesInterCompanyTotal3);
			    
		   //3. Total Current Liabilities
		   document.forms["CurrentLiabilitiesForm"]["TotalCurrentLiabilitiesYear0"].value = Thousands_Separators(TotalCurrentLiabilities0);
		   document.forms["CurrentLiabilitiesForm"]["TotalCurrentLiabilitiesYear1"].value = Thousands_Separators(TotalCurrentLiabilities1);
		   document.forms["CurrentLiabilitiesForm"]["TotalCurrentLiabilitiesYear2"].value = Thousands_Separators(TotalCurrentLiabilities2);
		   document.forms["CurrentLiabilitiesForm"]["TotalCurrentLiabilitiesYear3"].value = Thousands_Separators(TotalCurrentLiabilities3);
		   
}
function NonCurrentAssets_Recalculate()
{
			 
			 // Read input values from form into working placeholder variables
		   //1. Opening Net Book Value
	       var OpeningNBV0 = ToNumber(document.forms["NonCurrentAssetsForm"]["OpeningNBVYear0"].value);
	       
		   //2.  Additions
		   var Additions0 = ToNumber(document.forms["NonCurrentAssetsForm"]["AdditionsYear0"].value);
           var Additions1 = ToNumber(document.forms["NonCurrentAssetsForm"]["AdditionsYear1"].value);
           var Additions2 = ToNumber(document.forms["NonCurrentAssetsForm"]["AdditionsYear2"].value);
		   var Additions3 = ToNumber(document.forms["NonCurrentAssetsForm"]["AdditionsYear3"].value);
		   
		   //3. Revaluation
		   var Revaluation0 = ToNumber(document.forms["NonCurrentAssetsForm"]["RevaluationYear0"].value);
	       var Revaluation1 = ToNumber(document.forms["NonCurrentAssetsForm"]["RevaluationYear1"].value);
	       var Revaluation2 = ToNumber(document.forms["NonCurrentAssetsForm"]["RevaluationYear2"].value);
		   var Revaluation3 = ToNumber(document.forms["NonCurrentAssetsForm"]["RevaluationYear3"].value);

		   //4. Depreciation CostOf Sales
		   var DepreciationCostOfSales0 = ToNumber(document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear0"].value);
	       var DepreciationCostOfSales1 = ToNumber(document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear1"].value);
	       var DepreciationCostOfSales2 = ToNumber(document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear2"].value);
		   var DepreciationCostOfSales3 = ToNumber(document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear3"].value);
							  	 	  			   

     	   //5. Depreciation Opex
		   var DepreciationOpex0 = ToNumber(document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear0"].value);
	       var DepreciationOpex1 = ToNumber(document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear1"].value);
	       var DepreciationOpex2 = ToNumber(document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear2"].value);
		   var DepreciationOpex3 = ToNumber(document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear3"].value);

	       //6. Other Movements PPE
		   var OtherMovementsPPE0 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear0"].value);
	       var OtherMovementsPPE1 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear1"].value);
	       var OtherMovementsPPE2 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear2"].value);
		   var OtherMovementsPPE3 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear3"].value);
	
		  //7. Land and Buildings NBV
		   var LandBuildingsNBV0 = ToNumber(document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear0"].value);
	       var LandBuildingsNBV1 = ToNumber(document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear1"].value);
	       var LandBuildingsNBV2 = ToNumber(document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear2"].value);
		   var LandBuildingsNBV3 = ToNumber(document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear3"].value);
	 
    
		  //8. Investment Property
		   var InvestmentProperty0 = ToNumber(document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear0"].value);
	       var InvestmentProperty1 = ToNumber(document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear1"].value);
	       var InvestmentProperty2 = ToNumber(document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear2"].value);
		   var InvestmentProperty3 = ToNumber(document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear3"].value);
		  
           //9. Intangible Assets
		   var IntangibleAssets0 = ToNumber(document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear0"].value);
	       var IntangibleAssets1 = ToNumber(document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear1"].value);
	       var IntangibleAssets2 = ToNumber(document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear2"].value);
		   var IntangibleAssets3 = ToNumber(document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear3"].value);
	  
		  //10. Other Non-Current Assets Line 1
		   var OtherNonCurrentAssetsLine1_0 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year0"].value);
	       var OtherNonCurrentAssetsLine1_1 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year1"].value);
	       var OtherNonCurrentAssetsLine1_2 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year2"].value);
		   var OtherNonCurrentAssetsLine1_3 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year3"].value);
		   
		   //11. Other Non-Current Assets Line 2
		   var OtherNonCurrentAssetsLine2_0 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year0"].value);
	       var OtherNonCurrentAssetsLine2_1 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year1"].value);
	       var OtherNonCurrentAssetsLine2_2 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year2"].value);
		   var OtherNonCurrentAssetsLine2_3 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year3"].value);

           //12. Other Non-Current Assets Line 3
		   var OtherNonCurrentAssetsLine3_0 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year0"].value);
	       var OtherNonCurrentAssetsLine3_1 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year1"].value);
	       var OtherNonCurrentAssetsLine3_2 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year2"].value);
		   var OtherNonCurrentAssetsLine3_3 = ToNumber(document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year3"].value);
 
		    // RECALCULATING CALCULATED FIELDS
			 
		  //15. Depreciation Total 
		   var DepreciationTotal0 = DepreciationCostOfSales0 + DepreciationOpex0;
		   var DepreciationTotal1 = DepreciationCostOfSales1 + DepreciationOpex1;
		   var DepreciationTotal2 = DepreciationCostOfSales2 + DepreciationOpex2;
		   var DepreciationTotal3 = DepreciationCostOfSales3 + DepreciationOpex3;

		  //16.Closing Book Value - PPE
	       var ClosingNBV0 = OpeningNBV0 + Additions0 + Revaluation0 + DepreciationTotal0 + OtherMovementsPPE0;
		   var ClosingNBV1 = ClosingNBV0 + Additions1 + Revaluation1 + DepreciationTotal1 + OtherMovementsPPE1;
		   var ClosingNBV2 = ClosingNBV1 + Additions2 + Revaluation2 + DepreciationTotal2 + OtherMovementsPPE2;
		   var ClosingNBV3 = ClosingNBV2 + Additions3 + Revaluation3 + DepreciationTotal3 + OtherMovementsPPE3;;
  
		  //17. Total Other PPE
	       var TotalOtherPPE0 = ClosingNBV0 - LandBuildingsNBV0;
	       var TotalOtherPPE1 = ClosingNBV1 - LandBuildingsNBV1;
	       var TotalOtherPPE2 = ClosingNBV2 - LandBuildingsNBV2;
		   var TotalOtherPPE3 = ClosingNBV3 - LandBuildingsNBV3;
	
	
		  //18. Total Other PPE
	       var OtherNonCurrentAssetsTotal0 = OtherNonCurrentAssetsLine1_0 + OtherNonCurrentAssetsLine2_0 + OtherNonCurrentAssetsLine3_0;
	       var OtherNonCurrentAssetsTotal1 = OtherNonCurrentAssetsLine1_1 + OtherNonCurrentAssetsLine2_1 + OtherNonCurrentAssetsLine3_1;
	       var OtherNonCurrentAssetsTotal2 = OtherNonCurrentAssetsLine1_2 + OtherNonCurrentAssetsLine2_2 + OtherNonCurrentAssetsLine3_2;
		   var OtherNonCurrentAssetsTotal3 = OtherNonCurrentAssetsLine1_3 + OtherNonCurrentAssetsLine2_3 + OtherNonCurrentAssetsLine3_3;
	 	
 
		 //20. Other Non-Current Assets Grand Total
		   var OtherNonCurrentAssetsGrandTotal0 = InvestmentProperty0 + IntangibleAssets0 + OtherNonCurrentAssetsTotal0;
		   
           var OtherNonCurrentAssetsGrandTotal1 = InvestmentProperty1 + IntangibleAssets1 + OtherNonCurrentAssetsTotal1;
 
		   var OtherNonCurrentAssetsGrandTotal2 = InvestmentProperty2 + IntangibleAssets2 + OtherNonCurrentAssetsTotal2;

		   var OtherNonCurrentAssetsGrandTotal3 = InvestmentProperty3 + IntangibleAssets3 + OtherNonCurrentAssetsTotal3;

		  //21. Total Non-Current Assets
		   var TotalNonCurrentAssets0 = ClosingNBV0 + OtherNonCurrentAssetsGrandTotal0;
		   var TotalNonCurrentAssets1 = ClosingNBV1 + OtherNonCurrentAssetsGrandTotal1;
		   var TotalNonCurrentAssets2 = ClosingNBV2 + OtherNonCurrentAssetsGrandTotal2;
		   var TotalNonCurrentAssets3 = ClosingNBV3 + OtherNonCurrentAssetsGrandTotal3;

		   // DISPLAY THE CALCULATED FIELDS IN COMMA STYLE

		   //1. Opening Net Book Values
	       document.forms["NonCurrentAssetsForm"]["OpeningNBVYear1"].value = Thousands_Separators(ClosingNBV0);
	       document.forms["NonCurrentAssetsForm"]["OpeningNBVYear2"].value = Thousands_Separators(ClosingNBV1);
	       document.forms["NonCurrentAssetsForm"]["OpeningNBVYear3"].value = Thousands_Separators(ClosingNBV2);
 
		   //2. Depreciation Total
	       document.forms["NonCurrentAssetsForm"]["DepreciationTotalYear0"].value = Thousands_Separators(DepreciationTotal0);
	       document.forms["NonCurrentAssetsForm"]["DepreciationTotalYear1"].value = Thousands_Separators(DepreciationTotal1);
	       document.forms["NonCurrentAssetsForm"]["DepreciationTotalYear2"].value = Thousands_Separators(DepreciationTotal2);
	       document.forms["NonCurrentAssetsForm"]["DepreciationTotalYear3"].value = Thousands_Separators(DepreciationTotal3);
 
     	   //3. Closing Net Book Values
	       document.forms["NonCurrentAssetsForm"]["ClosingNBVYear0"].value = Thousands_Separators(ClosingNBV0);
	       document.forms["NonCurrentAssetsForm"]["ClosingNBVYear1"].value = Thousands_Separators(ClosingNBV1);
	       document.forms["NonCurrentAssetsForm"]["ClosingNBVYear2"].value = Thousands_Separators(ClosingNBV2);
	       document.forms["NonCurrentAssetsForm"]["ClosingNBVYear3"].value = Thousands_Separators(ClosingNBV3);
 
		
		   //4. Total Other PPE
	       document.forms["NonCurrentAssetsForm"]["TotalOtherPPEYear0"].value = Thousands_Separators(TotalOtherPPE0);
	       document.forms["NonCurrentAssetsForm"]["TotalOtherPPEYear1"].value = Thousands_Separators(TotalOtherPPE1);
	       document.forms["NonCurrentAssetsForm"]["TotalOtherPPEYear2"].value = Thousands_Separators(TotalOtherPPE2);
	       document.forms["NonCurrentAssetsForm"]["TotalOtherPPEYear3"].value = Thousands_Separators(TotalOtherPPE3);
		 
		   //5. Other Non-Current Assets Total
	       document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsTotalYear0"].value = Thousands_Separators(OtherNonCurrentAssetsTotal0);
	       document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsTotalYear1"].value = Thousands_Separators(OtherNonCurrentAssetsTotal1);
	       document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsTotalYear2"].value = Thousands_Separators(OtherNonCurrentAssetsTotal2);
	       document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsTotalYear3"].value = Thousands_Separators(OtherNonCurrentAssetsTotal3);
			    
		   //6. Other Non-Current Liabilities Total
	       document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsGrandTotalYear0"].value = Thousands_Separators(OtherNonCurrentAssetsGrandTotal0);
	       document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsGrandTotalYear1"].value = Thousands_Separators(OtherNonCurrentAssetsGrandTotal1);
	       document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsGrandTotalYear2"].value = Thousands_Separators(OtherNonCurrentAssetsGrandTotal2);
	       document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsGrandTotalYear3"].value = Thousands_Separators(OtherNonCurrentAssetsGrandTotal3);
	
           //7. Total Non Current Assets
		   document.forms["NonCurrentAssetsForm"]["TotalNonCurrentAssetsYear0"].value = Thousands_Separators(TotalNonCurrentAssets0);
		   document.forms["NonCurrentAssetsForm"]["TotalNonCurrentAssetsYear1"].value = Thousands_Separators(TotalNonCurrentAssets1);
		   document.forms["NonCurrentAssetsForm"]["TotalNonCurrentAssetsYear2"].value = Thousands_Separators(TotalNonCurrentAssets2);
		   document.forms["NonCurrentAssetsForm"]["TotalNonCurrentAssetsYear3"].value = Thousands_Separators(TotalNonCurrentAssets3);
		 
}
        function NonCurrentLiabilitiesForm_Recalculate()
		{
			 
			 // Read input values from form into working placeholder variables
		   //1. Mortgage Loans
	       var MortgageLoans0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear0"].value);
	       var MortgageLoans1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear1"].value);
	       var MortgageLoans2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear2"].value);    
		   var MortgageLoans3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear3"].value);  
		   
		   //2.  Term Loans
		   var TermLoans0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear0"].value);
           var TermLoans1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear1"].value);
           var TermLoans2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear2"].value);
		   var TermLoans3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear3"].value);
		   
		   //3. Bonds
		   var Bonds0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["BondsYear0"].value);
	       var Bonds1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["BondsYear1"].value);
	       var Bonds2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["BondsYear2"].value);
		   var Bonds3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["BondsYear3"].value);

		   //4. Long-term Finance Leases and Instalment Sales
		   var FinanceLeases0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear0"].value);
	       var FinanceLeases1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear1"].value);
	       var FinanceLeases2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear2"].value);
		   var FinanceLeases3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear3"].value);
		   
     	   //5. Other Long-Term Borrowings
		   var OtherLongTermBorrowings0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear0"].value);
	       var OtherLongTermBorrowings1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear1"].value);
	       var OtherLongTermBorrowings2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear2"].value);
		   var OtherLongTermBorrowings3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear3"].value);
	 
           //6. Shareholder And Directors Loans
		   var ShareholdersLoans0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear0"].value);
	       var ShareholdersLoans1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear1"].value);
	       var ShareholdersLoans2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear2"].value);
		   var ShareholdersLoans3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear3"].value);
		 
		  //7. Inter-Company Loans Line 1
		   var InterCompanyLoansLine1_0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year0"].value);
	       var InterCompanyLoansLine1_1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year1"].value);
	       var InterCompanyLoansLine1_2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year2"].value);
		   var InterCompanyLoansLine1_3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year3"].value);
		   
		  //8. Inter-Company Loans Line 2
		   var InterCompanyLoansLine2_0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year0"].value);
	       var InterCompanyLoansLine2_1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year1"].value);
	       var InterCompanyLoansLine2_2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year2"].value);
		   var InterCompanyLoansLine2_3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year3"].value);

          //9. Inter-Company Loans Line 3
		   var InterCompanyLoansLine3_0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year0"].value);
	       var InterCompanyLoansLine3_1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year1"].value);
	       var InterCompanyLoansLine3_2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year2"].value);
		   var InterCompanyLoansLine3_3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year3"].value);
		
		
	      //10. Deferred Tax Balance
		   var DeferredTaxBalance0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear0"].value);
	       var DeferredTaxBalance1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear1"].value);
	       var DeferredTaxBalance2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear2"].value);
		   var DeferredTaxBalance3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear3"].value);
		
		  //11. Provisions
		   var Provisions0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear0"].value);
	       var Provisions1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear1"].value);
	       var Provisions2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear2"].value);
		   var Provisions3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear3"].value);

		  //12. Other Non-Current Liabilities
		   var OtherNonCurrentLiabilitiesLine1_0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year0"].value);
	       var OtherNonCurrentLiabilitiesLine1_1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year1"].value);
	       var OtherNonCurrentLiabilitiesLine1_2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year2"].value);
		   var OtherNonCurrentLiabilitiesLine1_3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year3"].value);
		   
		  //13. Other Non-Current Liabilities
		   var OtherNonCurrentLiabilitiesLine2_0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year0"].value);
	       var OtherNonCurrentLiabilitiesLine2_1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year1"].value);
	       var OtherNonCurrentLiabilitiesLine2_2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year2"].value);
		   var OtherNonCurrentLiabilitiesLine2_3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year3"].value);

          //14. Other Non-Current Liabilities
		   var OtherNonCurrentLiabilitiesLine3_0 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year0"].value);
	       var OtherNonCurrentLiabilitiesLine3_1 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year1"].value);
	       var OtherNonCurrentLiabilitiesLine3_2 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year2"].value);
		   var OtherNonCurrentLiabilitiesLine3_3 = ToNumber(document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year3"].value);
		  

		    // RECALCULATING CALCULATED FIELDS
			 
		  //15. Long-Term Borrowings -: Non-Inter Company Total 
		   var LongTermBorrowingsNonInterCompanyTotal0 = MortgageLoans0 + TermLoans0 + FinanceLeases0 + Bonds0 + OtherLongTermBorrowings0;
		   var LongTermBorrowingsNonInterCompanyTotal1 = MortgageLoans1 + TermLoans1 + FinanceLeases1 + Bonds1 + OtherLongTermBorrowings1;
		   var LongTermBorrowingsNonInterCompanyTotal2 = MortgageLoans2 + TermLoans2 + FinanceLeases2 + Bonds2 + OtherLongTermBorrowings2;
		   var LongTermBorrowingsNonInterCompanyTotal3 = MortgageLoans3 + TermLoans3 + FinanceLeases3 + Bonds3 + OtherLongTermBorrowings3;
	 
		  //16.Inter-Company Loans
	       var InterCompanyLoansTotal0 = InterCompanyLoansLine1_0 + InterCompanyLoansLine2_0 + InterCompanyLoansLine3_0;
	       var InterCompanyLoansTotal1 = InterCompanyLoansLine1_1 + InterCompanyLoansLine2_1 + InterCompanyLoansLine3_1;
	       var InterCompanyLoansTotal2 = InterCompanyLoansLine1_2 + InterCompanyLoansLine2_2 + InterCompanyLoansLine3_2;
		   var InterCompanyLoansTotal3 = InterCompanyLoansLine1_3 + InterCompanyLoansLine2_3 + InterCompanyLoansLine3_3;
	 
		  //17. Long-Term Borrowings -: Inter-Company
	       var LongTermBorrowingsInterCompanyTotal0 = ShareholdersLoans0 + InterCompanyLoansTotal0;
	       var LongTermBorrowingsInterCompanyTotal1 = ShareholdersLoans1 + InterCompanyLoansTotal1;
	       var LongTermBorrowingsInterCompanyTotal2 = ShareholdersLoans2 + InterCompanyLoansTotal2;
		   var LongTermBorrowingsInterCompanyTotal3 = ShareholdersLoans3 + InterCompanyLoansTotal3;
 																
	
          //18. Total Long-Term Borrowings
           var TotalLongTermBorrowings0 = LongTermBorrowingsNonInterCompanyTotal0 + LongTermBorrowingsInterCompanyTotal0;
		   var TotalLongTermBorrowings1 = LongTermBorrowingsNonInterCompanyTotal1 + LongTermBorrowingsInterCompanyTotal1;
		   var TotalLongTermBorrowings2 = LongTermBorrowingsNonInterCompanyTotal2 + LongTermBorrowingsInterCompanyTotal2;
		   var TotalLongTermBorrowings3 = LongTermBorrowingsNonInterCompanyTotal3 + LongTermBorrowingsInterCompanyTotal3;
 		
		  //19. Other Non-Current Liabilities Total
	       var OtherNonCurrentLiabilitiesTotal0 = OtherNonCurrentLiabilitiesLine1_0 + OtherNonCurrentLiabilitiesLine2_0 + OtherNonCurrentLiabilitiesLine3_0;
	       var OtherNonCurrentLiabilitiesTotal1 = OtherNonCurrentLiabilitiesLine1_1 + OtherNonCurrentLiabilitiesLine2_1 + OtherNonCurrentLiabilitiesLine3_1;
	       var OtherNonCurrentLiabilitiesTotal2 = OtherNonCurrentLiabilitiesLine1_2 + OtherNonCurrentLiabilitiesLine2_2 + OtherNonCurrentLiabilitiesLine3_2;
		   var OtherNonCurrentLiabilitiesTotal3 = OtherNonCurrentLiabilitiesLine1_3 + OtherNonCurrentLiabilitiesLine2_3 + OtherNonCurrentLiabilitiesLine3_3;
	 
		 //20. Other Non-Current Liabilities Grand Total
		   var OtherNonCurrentLiabilitiesGrandTotal0 = DeferredTaxBalance0 + Provisions0 + OtherNonCurrentLiabilitiesTotal0;
           var OtherNonCurrentLiabilitiesGrandTotal1 = DeferredTaxBalance1 + Provisions1 + OtherNonCurrentLiabilitiesTotal1;
           var OtherNonCurrentLiabilitiesGrandTotal2 = DeferredTaxBalance2 + Provisions2 + OtherNonCurrentLiabilitiesTotal2;
		   var OtherNonCurrentLiabilitiesGrandTotal3 = DeferredTaxBalance3 + Provisions3 + OtherNonCurrentLiabilitiesTotal3;
	    
		  //21. Total Non-Current Liabilities
		   var TotalNonCurrentLiabilities0 = TotalLongTermBorrowings0 + OtherNonCurrentLiabilitiesGrandTotal0;
		   var TotalNonCurrentLiabilities1 = TotalLongTermBorrowings1 + OtherNonCurrentLiabilitiesGrandTotal1;
		   var TotalNonCurrentLiabilities2 = TotalLongTermBorrowings2 + OtherNonCurrentLiabilitiesGrandTotal2;
		   var TotalNonCurrentLiabilities3 = TotalLongTermBorrowings3 + OtherNonCurrentLiabilitiesGrandTotal3;
		   
  
		   // DISPLAY THE CALCULATED FIELDS IN COMMA STYLE
	       
		   //1. Long-Term Borrowings - Inter Company Loans Total
	       document.forms["NonCurrentLiabilitiesForm"]["LongTermBorrowingsNonInterCompanyTotalYear0"].value = Thousands_Separators(LongTermBorrowingsNonInterCompanyTotal0);
	       document.forms["NonCurrentLiabilitiesForm"]["LongTermBorrowingsNonInterCompanyTotalYear1"].value = Thousands_Separators(LongTermBorrowingsNonInterCompanyTotal1);
	       document.forms["NonCurrentLiabilitiesForm"]["LongTermBorrowingsNonInterCompanyTotalYear2"].value = Thousands_Separators(LongTermBorrowingsNonInterCompanyTotal2);
	       document.forms["NonCurrentLiabilitiesForm"]["LongTermBorrowingsNonInterCompanyTotalYear3"].value = Thousands_Separators(LongTermBorrowingsNonInterCompanyTotal3);
	       
		   //2. Inter-Company Loans Total
	       document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansTotalYear0"].value = Thousands_Separators(InterCompanyLoansTotal0);
	       document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansTotalYear1"].value = Thousands_Separators(InterCompanyLoansTotal1);
	       document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansTotalYear2"].value = Thousands_Separators(InterCompanyLoansTotal2);
	       document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansTotalYear3"].value = Thousands_Separators(InterCompanyLoansTotal3);
	  
     	   //3. Long-Term Borrowings - Inter Company Loans Total
	       document.forms["NonCurrentLiabilitiesForm"]["LongTermBorrowingsInterCompanyTotalYear0"].value = Thousands_Separators(LongTermBorrowingsInterCompanyTotal0);
	       document.forms["NonCurrentLiabilitiesForm"]["LongTermBorrowingsInterCompanyTotalYear1"].value = Thousands_Separators(LongTermBorrowingsInterCompanyTotal1);
	       document.forms["NonCurrentLiabilitiesForm"]["LongTermBorrowingsInterCompanyTotalYear2"].value = Thousands_Separators(LongTermBorrowingsInterCompanyTotal2);
	       document.forms["NonCurrentLiabilitiesForm"]["LongTermBorrowingsInterCompanyTotalYear3"].value = Thousands_Separators(LongTermBorrowingsInterCompanyTotal3);
	  	   
		
		   //4. Total Long-Term Borrowings 
	       document.forms["NonCurrentLiabilitiesForm"]["TotalLongTermBorrowingsYear0"].value = Thousands_Separators(TotalLongTermBorrowings0);
	       document.forms["NonCurrentLiabilitiesForm"]["TotalLongTermBorrowingsYear1"].value = Thousands_Separators(TotalLongTermBorrowings1);
	       document.forms["NonCurrentLiabilitiesForm"]["TotalLongTermBorrowingsYear2"].value = Thousands_Separators(TotalLongTermBorrowings2);
	       document.forms["NonCurrentLiabilitiesForm"]["TotalLongTermBorrowingsYear3"].value = Thousands_Separators(TotalLongTermBorrowings3);
		 
		   //5. Other Non-Current Liabilities GrandTotal
	       document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesGrandTotalYear0"].value = Thousands_Separators(OtherNonCurrentLiabilitiesGrandTotal0);
	       document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesGrandTotalYear1"].value = Thousands_Separators(OtherNonCurrentLiabilitiesGrandTotal1);
	       document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesGrandTotalYear2"].value = Thousands_Separators(OtherNonCurrentLiabilitiesGrandTotal2);
	       document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesGrandTotalYear3"].value = Thousands_Separators(OtherNonCurrentLiabilitiesGrandTotal3);
			    
		   //6. Other Non-Current Liabilities Total
	       document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesTotalYear0"].value = Thousands_Separators(OtherNonCurrentLiabilitiesTotal0);
	       document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesTotalYear1"].value = Thousands_Separators(OtherNonCurrentLiabilitiesTotal1);
	       document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesTotalYear2"].value = Thousands_Separators(OtherNonCurrentLiabilitiesTotal2);
	       document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesTotalYear3"].value = Thousands_Separators(OtherNonCurrentLiabilitiesTotal3);
	
           //7. Total Non Current Liabilities
		   document.forms["NonCurrentLiabilitiesForm"]["TotalNonCurrentLiabilitiesYear0"].value = Thousands_Separators(TotalNonCurrentLiabilities0);
		   document.forms["NonCurrentLiabilitiesForm"]["TotalNonCurrentLiabilitiesYear1"].value = Thousands_Separators(TotalNonCurrentLiabilities1);
		   document.forms["NonCurrentLiabilitiesForm"]["TotalNonCurrentLiabilitiesYear2"].value = Thousands_Separators(TotalNonCurrentLiabilities2);
		   document.forms["NonCurrentLiabilitiesForm"]["TotalNonCurrentLiabilitiesYear3"].value = Thousands_Separators(TotalNonCurrentLiabilities3);
		   
}
function EquityForm_Recalculate()
{
			 
			 // Read input values from form into working placeholder variables
		   //1. Share Capital
	       var ShareCapital0 = ToNumber(document.forms["EquityForm"]["ShareCapitalYear0"].value);
	       var ShareCapital1 = ToNumber(document.forms["EquityForm"]["ShareCapitalYear1"].value);
	       var ShareCapital2 = ToNumber(document.forms["EquityForm"]["ShareCapitalYear2"].value);    
		   var ShareCapital3 = ToNumber(document.forms["EquityForm"]["ShareCapitalYear3"].value);  
		   
		   //2.  Share Premium
		   var SharePremium0 = ToNumber(document.forms["EquityForm"]["SharePremiumYear0"].value);
           var SharePremium1 = ToNumber(document.forms["EquityForm"]["SharePremiumYear1"].value);
           var SharePremium2 = ToNumber(document.forms["EquityForm"]["SharePremiumYear2"].value);
		   var SharePremium3 = ToNumber(document.forms["EquityForm"]["SharePremiumYear3"].value);
		   
		   //3. Revaluation Reserve
		   var RevaluationReserve0 = ToNumber(document.forms["EquityForm"]["RevaluationReserveYear0"].value);
	       var RevaluationReserve1 = ToNumber(document.forms["EquityForm"]["RevaluationReserveYear1"].value);
	       var RevaluationReserve2 = ToNumber(document.forms["EquityForm"]["RevaluationReserveYear2"].value);
		   var RevaluationReserve3 = ToNumber(document.forms["EquityForm"]["RevaluationReserveYear3"].value);
		   
		 
		   //6. Other Non Distributable Reserves Line 1
		   var OtherNonDistributableReservesLine1_0 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year0"].value);
	       var OtherNonDistributableReservesLine1_1 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year1"].value);
	       var OtherNonDistributableReservesLine1_2 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year2"].value);
		   var OtherNonDistributableReservesLine1_3 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year3"].value);
		   
		   //7. Other Non Distributable Reserves Line 2
		   var OtherNonDistributableReservesLine2_0 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year0"].value);
	       var OtherNonDistributableReservesLine2_1 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year1"].value);
	       var OtherNonDistributableReservesLine2_2 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year2"].value);
		   var OtherNonDistributableReservesLine2_3 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year3"].value);
		    
		   //8. Other Non Distributable Reserves Line 3
		   var OtherNonDistributableReservesLine3_0 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year0"].value);
	       var OtherNonDistributableReservesLine3_1 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year1"].value);
	       var OtherNonDistributableReservesLine3_2 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year2"].value);
		   var OtherNonDistributableReservesLine3_3 = ToNumber(document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year3"].value);
		  
		   //9. Opening Retained Profits - Get for one year only
		   var OpeningRetainedProfits0 = ToNumber(document.forms["EquityForm"]["OpeningRetainedProfitsYear0"].value);

           //4. Net Profit
		   var NetProfit0 = ToNumber(document.forms["EquityForm"]["NetProfitYear0"].value);
	       var NetProfit1 = ToNumber(document.forms["EquityForm"]["NetProfitYear1"].value);
	       var NetProfit2 = ToNumber(document.forms["EquityForm"]["NetProfitYear2"].value);
		   var NetProfit3 = ToNumber(document.forms["EquityForm"]["NetProfitYear3"].value);
		  
		   //5. Dividends
		   var Dividends0 = ToNumber(document.forms["EquityForm"]["DividendsYear0"].value);
	       var Dividends1 = ToNumber(document.forms["EquityForm"]["DividendsYear1"].value);
	       var Dividends2 = ToNumber(document.forms["EquityForm"]["DividendsYear2"].value);
		   var Dividends3 = ToNumber(document.forms["EquityForm"]["DividendsYear3"].value);
	 
           //5. Retained Profits Adjustment
		   var RetainedProfitsAdjustments0 = ToNumber(document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear0"].value);
	       var RetainedProfitsAdjustments1 = ToNumber(document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear1"].value);
	       var RetainedProfitsAdjustments2 = ToNumber(document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear2"].value);
		   var RetainedProfitsAdjustments3 = ToNumber(document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear3"].value);
		 
        
		 //9. Other Distributable Reserves Line 1
		   var OtherDistributableReservesLine1_0 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine1Year0"].value);
	       var OtherDistributableReservesLine1_1 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine1Year1"].value);
	       var OtherDistributableReservesLine1_2 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine1Year2"].value);
		   var OtherDistributableReservesLine1_3 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine1Year3"].value);
		   
		   //10. Other Distributable Reserves Line 2
		   var OtherDistributableReservesLine2_0 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine2Year0"].value);
	       var OtherDistributableReservesLine2_1 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine2Year1"].value);
	       var OtherDistributableReservesLine2_2 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine2Year2"].value);
		   var OtherDistributableReservesLine2_3 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine2Year3"].value);
		    
		   //11. Other Distributable Reserves Line 3
		   var OtherDistributableReservesLine3_0 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine3Year0"].value);
	       var OtherDistributableReservesLine3_1 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine3Year1"].value);
	       var OtherDistributableReservesLine3_2 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine3Year2"].value);
		   var OtherDistributableReservesLine3_3 = ToNumber(document.forms["EquityForm"]["OtherDistributableReservesLine3Year3"].value);
		  
		    // RECALCULATING CALCULATED FIELDS
			 
		   //1. Other Non Distributable Reserves
	       var OtherNonDistributableReservesTotal0 = OtherNonDistributableReservesLine1_0 + OtherNonDistributableReservesLine2_0 + OtherNonDistributableReservesLine3_0;
	       var OtherNonDistributableReservesTotal1 = OtherNonDistributableReservesLine1_1 + OtherNonDistributableReservesLine2_1 + OtherNonDistributableReservesLine3_1;
	       var OtherNonDistributableReservesTotal2 = OtherNonDistributableReservesLine1_2 + OtherNonDistributableReservesLine2_2 + OtherNonDistributableReservesLine3_2;
		   var OtherNonDistributableReservesTotal3 = OtherNonDistributableReservesLine1_3 + OtherNonDistributableReservesLine2_3 + OtherNonDistributableReservesLine3_3;
		  
		   //  Roll-forward the Retained Profits
           var ClosingRetainedProfits0 = OpeningRetainedProfits0 + NetProfit0 + Dividends0 + RetainedProfitsAdjustments0;
           var OpeningRetainedProfits1 = ClosingRetainedProfits0;
		   var ClosingRetainedProfits1 = OpeningRetainedProfits1 + NetProfit1 + Dividends1 + RetainedProfitsAdjustments1;
           var OpeningRetainedProfits2 = ClosingRetainedProfits1;
		   var ClosingRetainedProfits2 = OpeningRetainedProfits2 + NetProfit2 + Dividends2 + RetainedProfitsAdjustments2;
           var OpeningRetainedProfits3 = ClosingRetainedProfits2;
		   var ClosingRetainedProfits3 = OpeningRetainedProfits3 + NetProfit3 + Dividends3 + RetainedProfitsAdjustments3;
  

	       //2. Other Distributable Reserves Total
	       var OtherDistributableReservesTotal0 = OtherDistributableReservesLine1_0 + OtherDistributableReservesLine2_0 + OtherDistributableReservesLine3_0;
	       var OtherDistributableReservesTotal1 = OtherDistributableReservesLine1_1 + OtherDistributableReservesLine2_1 + OtherDistributableReservesLine3_1;
	       var OtherDistributableReservesTotal2 = OtherDistributableReservesLine1_2 + OtherDistributableReservesLine2_2 + OtherDistributableReservesLine3_2;
		   var OtherDistributableReservesTotal3 = OtherDistributableReservesLine1_3 + OtherDistributableReservesLine2_3 + OtherDistributableReservesLine3_3;
		   
		   //3. Total Equity  
		   var TotalEquity0 = ShareCapital0 + SharePremium0 + RevaluationReserve0 + ClosingRetainedProfits0 + OtherNonDistributableReservesTotal0 + OtherDistributableReservesTotal0;
		   var TotalEquity1 = ShareCapital1 + SharePremium1 + RevaluationReserve1 + ClosingRetainedProfits1 + OtherNonDistributableReservesTotal1 + OtherDistributableReservesTotal1;
		   var TotalEquity2 = ShareCapital2 + SharePremium2 + RevaluationReserve2 + ClosingRetainedProfits2 + OtherNonDistributableReservesTotal2 + OtherDistributableReservesTotal2;
		   var TotalEquity3 = ShareCapital3 + SharePremium3 + RevaluationReserve3 + ClosingRetainedProfits3 + OtherNonDistributableReservesTotal3 + OtherDistributableReservesTotal3;
		   
   
		   // DISPLAY THE CALCULATED FIELDS IN COMMA STYLE
	       
		   //1. Non-Distributable Reserves Total
	       document.forms["EquityForm"]["OtherNonDistributableReservesTotalYear0"].value = Thousands_Separators(OtherNonDistributableReservesTotal0);
	       document.forms["EquityForm"]["OtherNonDistributableReservesTotalYear1"].value = Thousands_Separators(OtherNonDistributableReservesTotal1);
	       document.forms["EquityForm"]["OtherNonDistributableReservesTotalYear2"].value = Thousands_Separators(OtherNonDistributableReservesTotal2);
	       document.forms["EquityForm"]["OtherNonDistributableReservesTotalYear3"].value = Thousands_Separators(OtherNonDistributableReservesTotal3);
	       
	       //2. Closing Retained Profits
	       document.forms["EquityForm"]["ClosingRetainedProfitsYear0"].value = Thousands_Separators(ClosingRetainedProfits0);
	       document.forms["EquityForm"]["ClosingRetainedProfitsYear1"].value = Thousands_Separators(ClosingRetainedProfits1);
	       document.forms["EquityForm"]["ClosingRetainedProfitsYear2"].value = Thousands_Separators(ClosingRetainedProfits2);
	       document.forms["EquityForm"]["ClosingRetainedProfitsYear3"].value = Thousands_Separators(ClosingRetainedProfits3);
			
		   //2. Opening Retained Profits
	       document.forms["EquityForm"]["OpeningRetainedProfitsYear0"].value = Thousands_Separators(OpeningRetainedProfits0);
	       document.forms["EquityForm"]["OpeningRetainedProfitsYear1"].value = Thousands_Separators(OpeningRetainedProfits1);
	       document.forms["EquityForm"]["OpeningRetainedProfitsYear2"].value = Thousands_Separators(OpeningRetainedProfits2);
	       document.forms["EquityForm"]["OpeningRetainedProfitsYear3"].value = Thousands_Separators(OpeningRetainedProfits3);
		 
		   
		   //2. Distributable Reserves Total
	       document.forms["EquityForm"]["OtherDistributableReservesTotalYear0"].value = Thousands_Separators(OtherDistributableReservesTotal0);
	       document.forms["EquityForm"]["OtherDistributableReservesTotalYear1"].value = Thousands_Separators(OtherDistributableReservesTotal1);
	       document.forms["EquityForm"]["OtherDistributableReservesTotalYear2"].value = Thousands_Separators(OtherDistributableReservesTotal2);
	       document.forms["EquityForm"]["OtherDistributableReservesTotalYear3"].value = Thousands_Separators(OtherDistributableReservesTotal3);
			    
		   //3. Total Current Assets
		   document.forms["EquityForm"]["TotalEquityYear0"].value = Thousands_Separators(TotalEquity0);
		   document.forms["EquityForm"]["TotalEquityYear1"].value = Thousands_Separators(TotalEquity1);
		   document.forms["EquityForm"]["TotalEquityYear2"].value = Thousands_Separators(TotalEquity2);
		   document.forms["EquityForm"]["TotalEquityYear3"].value = Thousands_Separators(TotalEquity3);
		   
}
//=========================================================================================================================
function RecalculateManagementAnalysisForm()
{
		   var elem = document.getElementById('ManagementAnalysisForm').elements;
          // var x = 1;
		   
		   // 
		   //var GrandTotal = 0;
		   for(var i = 0; i < elem.length; i++)
           {
			   /** if the element type = select-one then perform conditional formatting
				**/
			   if (elem[i].type == 'select-one') 
			      {
			   	     switch (elem[i].value) 
				       {
			             case "Excellent":
			               elem[i].style.backgroundColor = "green";
			               break;
			             case "Good":
			               elem[i].style.backgroundColor = "lightgreen";
					       break;  
			             case "Sufficient":
			               elem[i].style.backgroundColor = "orange";
						   break;
						 case "Insufficient":
						   elem[i].style.backgroundColor = "yellow";
						   break;
				         case "Deficient":
			               elem[i].style.backgroundColor = "red";
		
			               break;  
		                  // default:
		               }
		    	  }
		    }    		
}
//===========================================================================================================================
function ValidateShareholderForm()
/** Purpose of Function : return boolean value to allow or bar form submission depending on input elements validation

**/
  
{
	
  return true;

	
}
//=============================================================================================================================
/**
Purpose of Function :- Save ManagementAnalysisForm input element values to local storage so that they can be recalled on refresh across pages
Variables Use       :- The localStorage variables are identical to the input ManagementAnalysisForm elements names apart from the local STorage prefix
**/       
function SaveManagementAnalysisForm()
{
		 // Save Date and Username into Income Statement Tracker======================================
		   
		  var today = new Date();
          var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		  var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
	      localStorage.ManagementAnalysisTrackerDateSaved = date;
		  localStorage.ManagementAnalysisTrackerSavedBy = localStorage.username;
 
          //Saving Assessment Ratings to localStorage
		  localStorage.Commitment =document.ManagementAnalysisForm.Commitment.options[document.ManagementAnalysisForm.Commitment.selectedIndex].value;
		  localStorage.Integrity =document.ManagementAnalysisForm.Integrity.options[document.ManagementAnalysisForm.Integrity.selectedIndex].value;
		  localStorage.InformationQuality =document.ManagementAnalysisForm.InformationQuality.options[document.ManagementAnalysisForm.InformationQuality.selectedIndex].value;
		  localStorage.Leadership =document.ManagementAnalysisForm.Leadership.options[document.ManagementAnalysisForm.Leadership.selectedIndex].value;
		  localStorage.Strategy =document.ManagementAnalysisForm.Strategy.options[document.ManagementAnalysisForm.Strategy.selectedIndex].value;
		  localStorage.Structure =document.ManagementAnalysisForm.Structure.options[document.ManagementAnalysisForm.Structure.selectedIndex].value;
		  localStorage.Management =document.ManagementAnalysisForm.Management.options[document.ManagementAnalysisForm.Management.selectedIndex].value;
		  localStorage.SuccessionPlanning =document.ManagementAnalysisForm.SuccessionPlanning.options[document.ManagementAnalysisForm.SuccessionPlanning.selectedIndex].value;
		  localStorage.OrganisationalPlanning =document.ManagementAnalysisForm.OrganisationalPlanning.options[document.ManagementAnalysisForm.OrganisationalPlanning.selectedIndex].value;
	      //Saving Assessment Rating Justifications to localStorage
		  localStorage.CommitmentComment =document.ManagementAnalysisForm.CommitmentComment.value;
		  localStorage.IntegrityComment =document.ManagementAnalysisForm.IntegrityComment.value;
		  localStorage.InformationQualityComment =document.ManagementAnalysisForm.InformationQualityComment.value;
		  localStorage.LeadershipComment =document.ManagementAnalysisForm.LeadershipComment.value;
		  localStorage.StrategyComment =document.ManagementAnalysisForm.StrategyComment.value;
		  localStorage.StructureComment =document.ManagementAnalysisForm.StructureComment.value;
		  localStorage.ManagementComment =document.ManagementAnalysisForm.ManagementComment.value;
		  localStorage.SuccessionPlanningComment =document.ManagementAnalysisForm.SuccessionPlanningComment.value;
		  localStorage.OrganisationalPlanningComment =document.ManagementAnalysisForm.OrganisationalPlanningComment.value;
	      //Saving Assessment Rating Review Comments to localStorage
		  localStorage.CommitmentReviewComment =document.ManagementAnalysisForm.CommitmentReviewComment.value;
		  localStorage.IntegrityReviewComment =document.ManagementAnalysisForm.IntegrityReviewComment.value;
		  localStorage.InformationQualityReviewComment =document.ManagementAnalysisForm.InformationQualityReviewComment.value;
		  localStorage.LeadershipReviewComment =document.ManagementAnalysisForm.LeadershipReviewComment.value;
		  localStorage.StrategyReviewComment =document.ManagementAnalysisForm.StrategyReviewComment.value;
		  localStorage.StructureReviewComment =document.ManagementAnalysisForm.StructureReviewComment.value;
		  localStorage.ManagementReviewComment =document.ManagementAnalysisForm.ManagementReviewComment.value;
		  localStorage.SuccessionPlanningReviewComment =document.ManagementAnalysisForm.SuccessionPlanningReviewComment.value;
		  localStorage.OrganisationalPlanningReviewComment =document.ManagementAnalysisForm.OrganisationalPlanningReviewComment.value;	  
		  //Alerting user on successful save 
		  alert("Management Assessment Successfully Saved");
}

/**
Purpose of Function :- Save ShareholderForm input element values to local storage so that they can be recalled on refresh across pages
Variables Use       :- The localStorage variables are identical to the input ShareholderForm elements names apart from the local STorage prefix
**/

function SaveIndustryAnalysis()


{
       
	   localStorage.IndustryCyclicality            =  document.PortersForm.IndustryCyclicality.value;
       localStorage.IndustryPerformance            =  document.PortersForm.IndustryPerformance.value;
 	   localStorage.ThreatsOfNewEntryRating        =  document.PortersForm.ThreatsOfNewEntryRating.value;
       localStorage.ThreatsOfNewEntryScore         =  document.PortersForm.ThreatsOfNewEntryScore.value;
       localStorage.EntryCostsRating               =  document.PortersForm.EntryCostsRating.value;
       localStorage.EntryCostsScore                =  document.PortersForm.EntryCostsScore.value;
       localStorage.EntryCostsComment              =  document.PortersForm.EntryCostsComment.value;
       localStorage.SpecialistKnowledgeRating      =  document.PortersForm.SpecialistKnowledgeRating.value;
       localStorage.SpecialKnowledgeScore          =  document.PortersForm.SpecialKnowledgeScore.value;
       localStorage.SpecialistKnowledgeComment     =  document.PortersForm.SpecialistKnowledgeComment.value;
       localStorage.EconomiesOfScaleRating         =  document.PortersForm.EconomiesOfScaleRating.value;
       localStorage.EconomiesOfScaleScore          =  document.PortersForm.EconomiesOfScaleScore.value;
       localStorage.EconomiesOfScaleComment        =  document.PortersForm.EconomiesOfScaleComment.value;
       localStorage.CostAdvantagesRating           =  document.PortersForm.CostAdvantagesRating.value;
       localStorage.CostAdvantagesScore            =  document.PortersForm.CostAdvantagesScore.value;
       localStorage.CostAdvantagesComment          =  document.PortersForm.CostAdvantagesComment.value;
       localStorage.TechnologyProtectionRating     =  document.PortersForm.TechnologyProtectionRating.value;
       localStorage.TechnologyProtectionScore      =  document.PortersForm.TechnologyProtectionScore.value;
       localStorage.TechnologyProtectionComment    =  document.PortersForm.TechnologyProtectionComment.value;
       localStorage.BarriersToEntryRating          =  document.PortersForm.BarriersToEntryRating.value;
       localStorage.BarriersToEntryScore           =  document.PortersForm.BarriersToEntryScore.value;
       localStorage.BarriersToEntryComment         =  document.PortersForm.BarriersToEntryComment.value;
       localStorage.CompetitiveRivalryRating       =  document.PortersForm.CompetitiveRivalryRating.value;
       localStorage.CompetitiveRivalryScore        =  document.PortersForm.CompetitiveRivalryScore.value;
       localStorage.NumberOfCompetitorsRating      =  document.PortersForm.NumberOfCompetitorsRating.value;
       localStorage.NumberOfCompetitorsScore       =  document.PortersForm.NumberOfCompetitorsScore.value;
       localStorage.NumberOfCompetitorsComment     =  document.PortersForm.NumberOfCompetitorsComment.value;
       localStorage.QualityDifferencesRating       =  document.PortersForm.QualityDifferencesRating.value;
       localStorage.QualityDifferencesScore        =  document.PortersForm.QualityDifferencesScore.value;
       localStorage.QualityDifferencesComment      =  document.PortersForm.QualityDifferencesComment.value;
       localStorage.OtherDifferencesRating         =  document.PortersForm.OtherDifferencesRating.value;
       localStorage.OtherDifferencesScore          =  document.PortersForm.OtherDifferencesScore.value;
       localStorage.OtherDifferencesComment        =  document.PortersForm.OtherDifferencesComment.value;
       localStorage.SwitchingCostsRating           =  document.PortersForm.SwitchingCostsRating.value;
       localStorage.SwitchingCostsScore            =  document.PortersForm.SwitchingCostsScore.value;
       localStorage.SwitchingCostsComment          =  document.PortersForm.SwitchingCostsComment.value;
       localStorage.CustomerLoyaltyRating          =  document.PortersForm.CustomerLoyaltyRating.value;
       localStorage.CustomerLoyaktyScore           =  document.PortersForm.CustomerLoyaktyScore.value;
       localStorage.CustomerLoyaktyComment         =  document.PortersForm.CustomerLoyaktyComment.value;
       localStorage.SupplierPowerRating            =  document.PortersForm.SupplierPowerRating.value;
       localStorage.SupplierPowerScore             =  document.PortersForm.SupplierPowerScore.value;
       localStorage.NumberOfSuppliersrsRating      =  document.PortersForm.NumberOfSuppliersrsRating.value;
       localStorage.NumberOfSuppliersOverallScore  =  document.PortersForm.NumberOfSuppliersOverallScore.value;
       localStorage.NumberOfSuppliersComment       =  document.PortersForm.NumberOfSuppliersComment.value;
       localStorage.SizeOfSuppliersRating          =  document.PortersForm.SizeOfSuppliersRating.value;
       localStorage.SizeOfSuppliersOverallScore    =  document.PortersForm.SizeOfSuppliersOverallScore.value;
       localStorage.SizeOfSuppliersComment         =  document.PortersForm.SizeOfSuppliersComment.value;
       localStorage.UniquenessOfServiceRating      =  document.PortersForm.UniquenessOfServiceRating.value;
       localStorage.UniquenessOfServiceScore       =  document.PortersForm.UniquenessOfServiceScore.value;
       localStorage.UniquenessOfServiceComment     =  document.PortersForm.UniquenessOfServiceComment.value;
       localStorage.CostsOfSupplierChangeRating    =  document.PortersForm.CostsOfSupplierChangeRating.value;
       localStorage.CostsOfSupplierChangeScore     =  document.PortersForm.CostsOfSupplierChangeScore.value;
       localStorage.CostsOfSupplierChangeComment   =  document.PortersForm.CostsOfSupplierChangeComment.value;
       localStorage.SupplierSwitchingCostsRating   =  document.PortersForm.SupplierSwitchingCostsRating.value;
       localStorage.SupplierSwitchingCostsScore    =  document.PortersForm.SupplierSwitchingCostsScore.value;
       localStorage.SupplierSwitchingCostsComment  =  document.PortersForm.SupplierSwitchingCostsComment.value;
       localStorage.ThreatsOfSubstitutionRating    =  document.PortersForm.ThreatsOfSubstitutionRating.value;
       localStorage.ThreatsOfSubstitutionScore     =  document.PortersForm.ThreatsOfSubstitutionScore.value;
       localStorage.SubstitutePerfomanceRating     =  document.PortersForm.SubstitutePerfomanceRating.value;
       localStorage.SubstitutePerformanceScore     =  document.PortersForm.SubstitutePerformanceScore.value;
       localStorage.SubstitutePerfomanceComment    =  document.PortersForm.SubstitutePerfomanceComment.value;
       localStorage.CostsOfSubstitutionRating      =  document.PortersForm.CostsOfSubstitutionRating.value;
       localStorage.CostsOfSubstitutionScore       =  document.PortersForm.CostsOfSubstitutionScore.value;
       localStorage.CostsOfSubstitutionComment     =  document.PortersForm.CostsOfSubstitutionComment.value;
       localStorage.BuyerPowerRating               =  document.PortersForm.BuyerPowerRating.value;
       localStorage.BuyerPowerScore                =  document.PortersForm.BuyerPowerScore.value;
       localStorage.NumberOfCustomersRating        =  document.PortersForm.NumberOfCustomersRating.value;
       localStorage.NumberOfCCustomersScore        =  document.PortersForm.NumberOfCCustomersScore.value;
       localStorage.NumberOfCustomersComment       =  document.PortersForm.NumberOfCustomersComment.value;
       localStorage.SingleOrderSizeRating          =  document.PortersForm.SingleOrderSizeRating.value;
       localStorage.SingleOrderSizeScore           =  document.PortersForm.SingleOrderSizeScore.value;
       localStorage.SingleOrderSizeComment         =  document.PortersForm.SingleOrderSizeComment.value;
       localStorage.CompetitorDifferencesRating    =  document.PortersForm.CompetitorDifferencesRating.value;
       localStorage.CompetitorDifferencesScore     =  document.PortersForm.CompetitorDifferencesScore.value;
       localStorage.CompetitorDifferencesComment   =  document.PortersForm.CompetitorDifferencesComment.value;
       localStorage.PriceSensitivityRating         =  document.PortersForm.PriceSensitivityRating.value;
       localStorage.PriceSensitivityScore          =  document.PortersForm.PriceSensitivityScore.value;
       localStorage.PriceSensitivityComment        =  document.PortersForm.PriceSensitivityComment.value;
       localStorage.AbilityToSubstituteRating      =  document.PortersForm.AbilityToSubstituteRating.value;
       localStorage.AbilityToSubstituteScore       =  document.PortersForm.AbilityToSubstituteScore.value;
       localStorage.AbilityToSubstituteComment     =  document.PortersForm.AbilityToSubstituteComment.value;
       localStorage.CustomersSwitchingCostsRating  =  document.PortersForm.CustomersSwitchingCostsRating.value;
       localStorage.CustomerSwitchingCostsScore    =  document.PortersForm.CustomerSwitchingCostsScore.value;
       localStorage.CustomersSwitchingCostsComment =  document.PortersForm.CustomersSwitchingCostsComment.value;
       localStorage.SummaryRating                  =  document.PortersForm.SummaryRating.value;
       localStorage.SummaryScore                   =  document.PortersForm.SummaryScore.value;
	   
	   alert ("Industry Analysis Settings successfully saved to local storage");
	
}
function Ratio_Analysis_CALCULATE()
		
{
   // CALCULATING EDWARD Total Assets
   localStorage.WCToTotalAssets0 = round(ToNumber(localStorage.WorkingCapital0)/ToNumber(localStorage.SummaryTotalAssets0),2).toFixed(2);
   localStorage.WCToTotalAssets1 = round(ToNumber(localStorage.WorkingCapital1)/ToNumber(localStorage.SummaryTotalAssets1),2).toFixed(2);
   localStorage.WCToTotalAssets2 = round(ToNumber(localStorage.WorkingCapital2)/ToNumber(localStorage.SummaryTotalAssets2),2).toFixed(2);
   localStorage.WCToTotalAssets3 = round(ToNumber(localStorage.WorkingCapital3)/ToNumber(localStorage.SummaryTotalAssets3),2).toFixed(2);
   localStorage.WCToTotalAssetsWeighted = round(localStorage.WCToTotalAssets1*localStorage.RatioWeightYear1/100+
		                                        localStorage.WCToTotalAssets2*localStorage.RatioWeightYear2/100+
												localStorage.WCToTotalAssets3*localStorage.RatioWeightYear3/100,2); 
   // X2. Retained Earnings/Total Assets Ratio
   localStorage.REToTotalAssets0 = round(ToNumber(localStorage.ClosingRetainedProfits0)/ToNumber(localStorage.SummaryTotalAssets0),2);
   localStorage.REToTotalAssets1 = round(ToNumber(localStorage.ClosingRetainedProfits1)/ToNumber(localStorage.SummaryTotalAssets1),2);
   localStorage.REToTotalAssets2 = round(ToNumber(localStorage.ClosingRetainedProfits2)/ToNumber(localStorage.SummaryTotalAssets2),2);
   localStorage.REToTotalAssets3 = round(ToNumber(localStorage.ClosingRetainedProfits3)/ToNumber(localStorage.SummaryTotalAssets3),2);
   localStorage.REToTotalAssetsWeighted = round(localStorage.REToTotalAssets1*localStorage.RatioWeightYear1/100+
                                                localStorage.REToTotalAssets2*localStorage.RatioWeightYear2/100+
										        localStorage.REToTotalAssets3*localStorage.RatioWeightYear3/100,2); 
   // X3. EBIT/Total Assets Ratio
   localStorage.EBITToTotalAssets0 = round(ToNumber(localStorage.EBIT0)/ToNumber(localStorage.SummaryTotalAssets0),2);
   localStorage.EBITToTotalAssets1 = round(ToNumber(localStorage.EBIT1)/ToNumber(localStorage.SummaryTotalAssets1),2);
   localStorage.EBITToTotalAssets2 = round(ToNumber(localStorage.EBIT2)/ToNumber(localStorage.SummaryTotalAssets2),2);
   localStorage.EBITToTotalAssets3 = round(ToNumber(localStorage.EBIT3)/ToNumber(localStorage.SummaryTotalAssets3),2);
   localStorage.EBITToTotalAssetsWeighted = round(localStorage.EBITToTotalAssets1*localStorage.RatioWeightYear1/100+
                                                  localStorage.EBITToTotalAssets2*localStorage.RatioWeightYear2/100+
										          localStorage.EBITToTotalAssets3*localStorage.RatioWeightYear3/100,2); 
   // X4. Equity/Total Liabilities Ratio
   localStorage.EquityToTotalLiabilities0 = round(ToNumber(localStorage.TotalEquity0)/ToNumber(localStorage.SummaryTotalLiabilities0),2);
   localStorage.EquityToTotalLiabilities1 = round(ToNumber(localStorage.TotalEquity1)/ToNumber(localStorage.SummaryTotalLiabilities1),2);
   localStorage.EquityToTotalLiabilities2 = round(ToNumber(localStorage.TotalEquity2)/ToNumber(localStorage.SummaryTotalLiabilities2),2);
   localStorage.EquityToTotalLiabilities3 = round(ToNumber(localStorage.TotalEquity3)/ToNumber(localStorage.SummaryTotalLiabilities3),2);
   localStorage.EquityToTotalLiabilitiesWeighted = round(localStorage.EquityToTotalLiabilities1*localStorage.RatioWeightYear1/100+
                                                         localStorage.EquityToTotalLiabilities2*localStorage.RatioWeightYear2/100+
										                 localStorage.EquityToTotalLiabilities3*localStorage.RatioWeightYear3/100,2); 
   // X5. Sales/Total Assets Ratio
   localStorage.SalesToTotalAssets0 = round(ToNumber(localStorage.NetSales1)/ToNumber(localStorage.SummaryTotalAssets0),2);
   localStorage.SalesToTotalAssets1 = round(ToNumber(localStorage.NetSales1)/ToNumber(localStorage.SummaryTotalAssets1),2);
   localStorage.SalesToTotalAssets2 = round(ToNumber(localStorage.NetSales2)/ToNumber(localStorage.SummaryTotalAssets2),2);
   localStorage.SalesToTotalAssets3 = round(ToNumber(localStorage.NetSales3)/ToNumber(localStorage.SummaryTotalAssets3),2);
   localStorage.SalesToTotalAssetsWeighted = round(localStorage.SalesToTotalAssets1*localStorage.RatioWeightYear1/100+
                                                   localStorage.SalesToTotalAssets2*localStorage.RatioWeightYear2/100+
   										           localStorage.SalesToTotalAssets3*localStorage.RatioWeightYear3/100,2); 
  
  // Calculating the Z Score - Multiply each ratio by the co-efficient then add the step calculations to get the  Score
  //1. X1 * Factor
  var X1_0 = localStorage.WCToTotalAssets0 * 1.2;                var X1Prime_0 = localStorage.WCToTotalAssets0 * 6.56;
  var X1_1 = localStorage.WCToTotalAssets1 * 1.2;                var X1Prime_1 = localStorage.WCToTotalAssets1 * 6.56;
  var X1_2 = localStorage.WCToTotalAssets2 * 1.2;                var X1Prime_2 = localStorage.WCToTotalAssets2 * 6.56;
  var X1_3 = localStorage.WCToTotalAssets3 * 1.2;                var X1Prime_3 = localStorage.WCToTotalAssets3 * 6.56;
  var X1_Weighted = localStorage.WCToTotalAssetsWeighted * 1.2;  var X1Prime_Weighted = localStorage.WCToTotalAssetsWeighted * 6.56;
	
  console.log ("X1_0 = "+X1_0+"X1Prime_0 = "+X1Prime_0);
  console.log ("X2_0 = "+X2_0+"X2Prime_0 = "+X2Prime_0);
  console.log ("X3_0 = "+X3_0+"X3Prime_0 = "+X3Prime_0);
  console.log ("X4_0 = "+X4_0+"X4Prime_0 = "+X4Prime_0);
  console.log ("X5_0 = "+X5_0+"X5Prime_0 = "+X5Prime_0);
  console.log ("X1_Weighted = "+X1_Weighted+"X1Prime_Weighted = "+X1Prime_Weighted);
	
  //2. X2 * Factor
  var X2_0 = localStorage.REToTotalAssets0 * 1.4;          var X2Prime_0 = localStorage.REToTotalAssets0 * 3.26;
  var X2_1 = localStorage.REToTotalAssets1 * 1.4;          var X2Prime_1 = localStorage.REToTotalAssets1 * 3.26;
  var X2_2 = localStorage.REToTotalAssets2 * 1.4;          var X2Prime_2 = localStorage.REToTotalAssets2 * 3.26;
  var X2_3 = localStorage.REToTotalAssets3 * 1.4;          var X2Prime_3 = localStorage.REToTotalAssets3 * 3.26;
  var X2_Weighted = localStorage.REToTotalAssetsWeighted * 1.4;  var X2Prime_Weighted = localStorage.REToTotalAssetsWeighted * 3.26;
  //3. X3 * Factor
  var X3_0 = localStorage.EBITToTotalAssets0 * 3.3;          var X3Prime_0 = localStorage.EBITToTotalAssets0 * 6.72;
  var X3_1 = localStorage.EBITToTotalAssets1 * 3.3;          var X3Prime_1 = localStorage.EBITToTotalAssets1 * 6.72;
  var X3_2 = localStorage.EBITToTotalAssets2 * 3.3;          var X3Prime_2 = localStorage.EBITToTotalAssets2 * 6.72;
  var X3_3 = localStorage.EBITToTotalAssets3 * 3.3;          var X3Prime_3 = localStorage.EBITToTotalAssets3 * 6.72;
  var X3_Weighted = localStorage.EBITToTotalAssetsWeighted * 3.3;  var X3Prime_Weighted = localStorage.EBITToTotalAssetsWeighted * 6.72;
  //4. X4 * Factor
  var X4_0 = localStorage.EquityToTotalLiabilities0 * 0.6; var X4Prime_0 = localStorage.EquityToTotalLiabilities0 * 1.05;
  var X4_1 = localStorage.EquityToTotalLiabilities1 * 0.6; var X4Prime_1 = localStorage.EquityToTotalLiabilities1 * 1.05;
  var X4_2 = localStorage.EquityToTotalLiabilities2 * 0.6; var X4Prime_2 = localStorage.EquityToTotalLiabilities2 * 1.05;
  var X4_3 = localStorage.EquityToTotalLiabilities3 * 0.6; var X4Prime_3 = localStorage.EquityToTotalLiabilities3 * 1.05;
  var X4_Weighted = localStorage.EquityToTotalLiabilitiesWeighted * 0.6;  var X4Prime_Weighted = localStorage.EquityToTotalLiabilitiesWeighted * 1.05;
  //5. X5 * Factor
  var X5_0 = localStorage.SalesToTotalAssets0 * 1;         var X5Prime_0 = localStorage.SalesToTotalAssets0 * 0;
  var X5_1 = localStorage.SalesToTotalAssets1 * 1;         var X5Prime_1 = localStorage.SalesToTotalAssets1 * 0;
  var X5_2 = localStorage.SalesToTotalAssets2 * 1;         var X5Prime_2 = localStorage.SalesToTotalAssets2 * 0;
  var X5_3 = localStorage.SalesToTotalAssets3 * 1;         var X5Prime_3 = localStorage.SalesToTotalAssets3 * 0;
  var X5_Weighted = localStorage.SalesToTotalAssetsWeighted * 1;  var X5Prime_Weighted = localStorage.SalesToTotalAssetsWeighted * 0;

  // Hence Z Score 
  localStorage.ZScore0 = round(X1_0 + X2_0 + X3_0 + X4_0 + X5_0,2);
  localStorage.ZScore1 = round(X1_1 + X2_1 + X3_1 + X4_1 + X5_1,2);
  localStorage.ZScore2 = round(X1_2 + X2_2 + X3_2 + X4_2 + X5_2,2);
  localStorage.ZScore3 = round(X1_3 + X2_3 + X3_3 + X4_3 + X5_3,2);
  localStorage.ZScoreWeighted = round(X1_Weighted + X2_Weighted + X3_Weighted 
                                + X4_Weighted + X5_Weighted,2);
  // Hence Z Score Prime
  localStorage.ZScorePrime0 = round(X1Prime_0 + X2Prime_0 + X3Prime_0 + X4Prime_0 + X5Prime_0,2);
  localStorage.ZScorePrime1 = round(X1Prime_1 + X2Prime_1 + X3Prime_1 + X4Prime_1 + X5Prime_1,2);
  localStorage.ZScorePrime2 = round(X1Prime_2 + X2Prime_2 + X3Prime_2 + X4Prime_2 + X5Prime_2,2);
  localStorage.ZScorePrime3 = round(X1Prime_3 + X2Prime_3 + X3Prime_3 + X4Prime_3 + X5Prime_3,2);
  localStorage.ZScorePrimeWeighted = round(X1Prime_Weighted + X2Prime_Weighted 
                                + X3Prime_Weighted + X4Prime_Weighted + X5Prime_Weighted,2);
		   
  //CALCULATING LIQUIDITY RATIOS===========================================================================================
		   
  //Current Ratio
  localStorage.CurrentRatio0 = round(ToNumber(localStorage.CurrentAssets0)/ToNumber(localStorage.CurrentLiabilities0),2);
  localStorage.CurrentRatio1 = round(ToNumber(localStorage.CurrentAssets1)/ToNumber(localStorage.CurrentLiabilities1),2);
  localStorage.CurrentRatio2 = round(ToNumber(localStorage.CurrentAssets2)/ToNumber(localStorage.CurrentLiabilities2),2);
  localStorage.CurrentRatio3 = round(ToNumber(localStorage.CurrentAssets3)/ToNumber(localStorage.CurrentLiabilities3),2);
  
  // Set CurrentRatio = 2 if there are no current liabilities ie Current Ratio = Infinity
  if (localStorage.CurrentRatio0== "Infinity") {localStorage.CurrentRatio0=2;};
  if (localStorage.CurrentRatio1== "Infinity") {localStorage.CurrentRatio1=2;};
  if (localStorage.CurrentRatio2== "Infinity") {localStorage.CurrentRatio2=2;};
  if (localStorage.CurrentRatio3== "Infinity") {localStorage.CurrentRatio3=2;};
  
  localStorage.CurrentRatioWeighted = round(localStorage.CurrentRatio1*localStorage.RatioWeightYear1/100+
   	                                        localStorage.CurrentRatio2*localStorage.RatioWeightYear2/100+
											localStorage.CurrentRatio3*localStorage.RatioWeightYear3/100,2);
  //QUICK RATIO = QUICK ASSETS/CURRENT LIABILITIES 
  //Step 1:  Where Quick Assets(Numerator) = Current Assets - Inventory
  var QuickAssets0 = ToNumber(localStorage.CurrentAssets0)-ToNumber(localStorage.Inventory0); 
  var QuickAssets1 = ToNumber(localStorage.CurrentAssets1)-ToNumber(localStorage.Inventory1); 
  var QuickAssets2 = ToNumber(localStorage.CurrentAssets2)-ToNumber(localStorage.Inventory2); 
  var QuickAssets3 = ToNumber(localStorage.CurrentAssets3)-ToNumber(localStorage.Inventory3); 
 
  
  //Step 2:  Quick Ratio - Full Calculation 
  localStorage.QuickRatio0 = round(QuickAssets0/ToNumber(localStorage.CurrentLiabilities0),2);
  localStorage.QuickRatio1 = round(QuickAssets1/ToNumber(localStorage.CurrentLiabilities1),2);
  localStorage.QuickRatio2 = round(QuickAssets2/ToNumber(localStorage.CurrentLiabilities2),2);
  localStorage.QuickRatio3 = round(QuickAssets3/ToNumber(localStorage.CurrentLiabilities3),2);

// Set QuickRatio = 2 if there are no current liabilities ie Quick Ratio = Infinity
  if (localStorage.QuickRatio0== "Infinity") {localStorage.QuickRatio0=2;};
  if (localStorage.QuickRatio1== "Infinity") {localStorage.QuickRatio1=2;};
  if (localStorage.QuickRatio2== "Infinity") {localStorage.QuickRatio2=2;};
  if (localStorage.QuickRatio3== "Infinity") {localStorage.QuickRatio3=2;};
  
  
  localStorage.QuickRatioWeighted = round(localStorage.QuickRatio1*localStorage.RatioWeightYear1/100+
		                                  localStorage.QuickRatio2*localStorage.RatioWeightYear2/100+
									      localStorage.QuickRatio3*localStorage.RatioWeightYear3/100,2);
  		   
   // Debtor Days
   localStorage.DebtorDays0 = round(ToNumber(localStorage.AccountsReceivable0)/ToNumber(localStorage.NetSales0)*365,2);
   localStorage.DebtorDays1 = round(ToNumber(localStorage.AccountsReceivable1)/ToNumber(localStorage.NetSales1)*365,2);
   localStorage.DebtorDays2 = round(ToNumber(localStorage.AccountsReceivable2)/ToNumber(localStorage.NetSales2)*365,2);
   localStorage.DebtorDays3 = round(ToNumber(localStorage.AccountsReceivable3)/ToNumber(localStorage.NetSales3)*365,2); 
   localStorage.DebtorDaysWeighted = round(localStorage.DebtorDays1*localStorage.RatioWeightYear1/100+
		                                   localStorage.DebtorDays2*localStorage.RatioWeightYear2/100+
										   localStorage.DebtorDays3*localStorage.RatioWeightYear3/100,2);
   //Creditor Days
   localStorage.CreditorDays0 = round(ToNumber(localStorage.AccountsPayable0)/ToNumber(localStorage.CosTotal0)*365,2);
   localStorage.CreditorDays1 = round(ToNumber(localStorage.AccountsPayable1)/ToNumber(localStorage.CosTotal1)*365,2);
   localStorage.CreditorDays2 = round(ToNumber(localStorage.AccountsPayable2)/ToNumber(localStorage.CosTotal2)*365,2);
   localStorage.CreditorDays3 = round(ToNumber(localStorage.AccountsPayable3)/ToNumber(localStorage.CosTotal3)*365,2); 
   localStorage.CreditorDaysWeighted = round(localStorage.CreditorDays1*localStorage.RatioWeightYear1/100+
		                                     localStorage.CreditorDays2*localStorage.RatioWeightYear2/100+
											 localStorage.CreditorDays3*localStorage.RatioWeightYear3/100,2);
  //Turnover/ Working Capital = Inverse of the Sales/Working Capital Ratio on the Z Score
  localStorage.TurnoverToWC0 = round(ToNumber(localStorage.NetSales0)/ToNumber(localStorage.WorkingCapital0),2);
  localStorage.TurnoverToWC1 = round(ToNumber(localStorage.NetSales1)/ToNumber(localStorage.WorkingCapitaL1),2);
  localStorage.TurnoverToWC2 = round(ToNumber(localStorage.NetSales2)/ToNumber(localStorage.WorkingCapital2),2);
  localStorage.TurnoverToWC3 = round(ToNumber(localStorage.NetSales3)/ToNumber(localStorage.WorkingCapital3),2);

  localStorage.TurnoverToWCWeighted = round(localStorage.TurnoverToWC1*localStorage.RatioWeightYear1/100+
		                                    localStorage.TurnoverToWC2*localStorage.RatioWeightYear2/100+
											localStorage.TurnoverToWC3*localStorage.RatioWeightYear3/100,2);
		   
  //Trapping Infinity errors
  if (localStorage.TurnoverToWC0 == "Infinity") {localStorage.TurnoverToWC0 = "n/a"};
  if (localStorage.TurnoverToWC1 == "Infinity") {localStorage.TurnoverToWC1 = "n/a"};
  if (localStorage.TurnoverToWC2 == "Infinity") {localStorage.TurnoverToWC2 = "n/a"};
  if (localStorage.TurnoverToWC3 == "Infinity") {localStorage.TurnoverToWC3 = "n/a"};
  if (localStorage.TurnoverToWCWeighted == "Infinity") {localStorage.TurnoverToWCWeighted = "n/a"};
				   
  // CALCULATING PROFITABILITY RATIOS================================================================================================
		   
  // Turnover Growth for last three years only
  localStorage.TurnoverGrowth1 = round((ToNumber(localStorage.NetSales1)/ToNumber(localStorage.NetSales0)-1)*100,2);
  localStorage.TurnoverGrowth2 = round((ToNumber(localStorage.NetSales2)/ToNumber(localStorage.NetSales1)-1)*100,2);
  localStorage.TurnoverGrowth3 = round((ToNumber(localStorage.NetSales3)/ToNumber(localStorage.NetSales2)-1)*100,2);
  localStorage.TurnoverGrowthWeighted = round(localStorage.TurnoverGrowth1*localStorage.RatioWeightYear1/100+
		                                      localStorage.TurnoverGrowth2*localStorage.RatioWeightYear2/100+
											  localStorage.TurnoverGrowth3*localStorage.RatioWeightYear3/100,2);
  //Gross Profit
  localStorage.GrossProfitMargin0 = round(ToNumber(localStorage.GrossProfit0)/ToNumber(localStorage.NetSales0),2)*100;
  localStorage.GrossProfitMargin1 = round(ToNumber(localStorage.GrossProfit1)/ToNumber(localStorage.NetSales1),2)*100;
  localStorage.GrossProfitMargin2 = round(ToNumber(localStorage.GrossProfit2)/ToNumber(localStorage.NetSales2),2)*100;
  localStorage.GrossProfitMargin3 = round(ToNumber(localStorage.GrossProfit3)/ToNumber(localStorage.NetSales3),2)*100;
  localStorage.GrossProfitMarginWeighted = localStorage.GrossProfitMargin1*localStorage.RatioWeightYear1/100+
		                                   localStorage.GrossProfitMargin2*localStorage.RatioWeightYear2/100+
										   localStorage.GrossProfitMargin3*localStorage.RatioWeightYear3/100;
  //Operating Profit
  localStorage.OperatingProfitMargin0 = round(ToNumber(localStorage.EBIT0)/ToNumber(localStorage.NetSales0),2)*100;
  localStorage.OperatingProfitMargin1 = round(ToNumber(localStorage.EBIT1)/ToNumber(localStorage.NetSales1),2)*100;
  localStorage.OperatingProfitMargin2 = round(ToNumber(localStorage.EBIT2)/ToNumber(localStorage.NetSales2),2)*100;
  localStorage.OperatingProfitMargin3 = round(ToNumber(localStorage.EBIT3)/ToNumber(localStorage.NetSales3),2)*100;
  localStorage.OperatingProfitMarginWeighted = round(localStorage.OperatingProfitMargin1*localStorage.RatioWeightYear1/100+
		                                             localStorage.OperatingProfitMargin2*localStorage.RatioWeightYear2/100+
											         localStorage.OperatingProfitMargin3*localStorage.RatioWeightYear3/100,2);
  //Net Profit
  localStorage.NetProfitMargin0 = round(ToNumber(localStorage.NetProfit0)/ToNumber(localStorage.NetSales0),2)*100;
  localStorage.NetProfitMargin1 = round(ToNumber(localStorage.NetProfit1)/ToNumber(localStorage.NetSales1),2)*100;
  localStorage.NetProfitMargin2 = round(ToNumber(localStorage.NetProfit2)/ToNumber(localStorage.NetSales2),2)*100;
  localStorage.NetProfitMargin3 = round(ToNumber(localStorage.NetProfit3)/ToNumber(localStorage.NetSales3),2)*100;
  localStorage.NetProfitMarginWeighted = round(localStorage.NetProfitMargin1*localStorage.RatioWeightYear1/100+
		                                       localStorage.NetProfitMargin2*localStorage.RatioWeightYear2/100+
											   localStorage.NetProfitMargin3*localStorage.RatioWeightYear3/100,2);
  //ROE
  localStorage.ROE0 = round(ToNumber(localStorage.NetProfit0)/ToNumber(localStorage.TotalEquity0),2)*100;
  localStorage.ROE1 = round(ToNumber(localStorage.NetProfit1)/ToNumber(localStorage.TotalEquity1),2)*100;
  localStorage.ROE2 = round(ToNumber(localStorage.NetProfit2)/ToNumber(localStorage.TotalEquity2),2)*100;
  localStorage.ROE3 = round(ToNumber(localStorage.NetProfit3)/ToNumber(localStorage.TotalEquity3),2)*100;
  localStorage.ROEWeighted = localStorage.ROE1*localStorage.RatioWeightYear1/100+
		                     localStorage.ROE2*localStorage.RatioWeightYear2/100+
						     localStorage.ROE3*localStorage.RatioWeightYear3/100;
  //ROE
  localStorage.ROA0 = round(ToNumber(localStorage.NetProfit0)/ToNumber(localStorage.SummaryTotalAssets0),2);
  localStorage.ROA1 = round(ToNumber(localStorage.NetProfit1)/ToNumber(localStorage.SummaryTotalAssets1),2);
  localStorage.ROA2 = round(ToNumber(localStorage.NetProfit2)/ToNumber(localStorage.SummaryTotalAssets2),2);
  localStorage.ROA3 = round(ToNumber(localStorage.NetProfit3)/ToNumber(localStorage.SummaryTotalAssets3),2);
  localStorage.ROAWeighted = localStorage.ROA1*localStorage.RatioWeightYear1/100+
		                     localStorage.ROA2*localStorage.RatioWeightYear2/100+
						     localStorage.ROA3*localStorage.RatioWeightYear3/100;
		   
  //ROI = EBIT / Total Long-term Funding = (Equity + Non-current Liabilities)
		   
  // Step 1 : Calculate Total Long-term Funding = Total Equity + Total Non-current Liabilities
  var LTFunding0 = ToNumber(localStorage.SummaryTotalAssets0) + ToNumber(localStorage.NonCurrentLiabilities0);
  var LTFunding1 = ToNumber(localStorage.SummaryTotalAssets1) + ToNumber(localStorage.NonCurrentLiabilities1);
  var LTFunding2 = ToNumber(localStorage.SummaryTotalAssets2) + ToNumber(localStorage.NonCurrentLiabilities2);
  var LTFunding3 = ToNumber(localStorage.SummaryTotalAssets3) + ToNumber(localStorage.NonCurrentLiabilities3);
		   
  // Step 2 : Full Calculation = EBIT/LT Funding(Step 1)
  localStorage.ROI0 = round(ToNumber(localStorage.EBIT0)/LTFunding0,2)*100;
  localStorage.ROI1 = round(ToNumber(localStorage.EBIT1)/LTFunding1,2)*100;
  localStorage.ROI2 = round(ToNumber(localStorage.EBIT2)/LTFunding2,2)*100;
  localStorage.ROI3 = round(ToNumber(localStorage.EBIT3)/LTFunding3,2)*100;
  localStorage.ROIWeighted = round(localStorage.ROI1*localStorage.RatioWeightYear1/100+
		                           localStorage.ROI2*localStorage.RatioWeightYear2/100+
								   localStorage.ROI3*localStorage.RatioWeightYear3/100,2);
		   
  // CALCULATING CAPITAL STRUCTURE RATIOS===============================================================================================
		   
  // Gearing Ratio = Total Liabilities / Total Equity
  localStorage.GearingRatio0 = round(ToNumber(localStorage.SummaryTotalLiabilities0)/ToNumber(localStorage.TotalEquity0),2)*100;
  localStorage.GearingRatio1 = round(ToNumber(localStorage.SummaryTotalLiabilities1)/ToNumber(localStorage.TotalEquity1),2)*100;
  localStorage.GearingRatio2 = round(ToNumber(localStorage.SummaryTotalLiabilities2)/ToNumber(localStorage.TotalEquity2),2)*100;
  localStorage.GearingRatio3 = round(ToNumber(localStorage.SummaryTotalLiabilities3)/ToNumber(localStorage.TotalEquity3),2)*100;
  localStorage.GearingRatioWeighted = localStorage.GearingRatio1*localStorage.RatioWeightYear1/100+
                                      localStorage.GearingRatio2*localStorage.RatioWeightYear2/100+
    					              localStorage.GearingRatio3*localStorage.RatioWeightYear3/100;
	   
  //Long-term Debt /Total Equity
  localStorage.LongtermDebtToEquity0 = round(ToNumber(localStorage.NonCurrentLiabilities0)/ToNumber(localStorage.TotalEquity0),0)*100;
  localStorage.LongtermDebtToEquity1 = round(ToNumber(localStorage.NonCurrentLiabilities1)/ToNumber(localStorage.TotalEquity1),0)*100;
  localStorage.LongtermDebtToEquity2 = round(ToNumber(localStorage.NonCurrentLiabilities2)/ToNumber(localStorage.TotalEquity2),0)*100;
  localStorage.LongtermDebtToEquity3 = round(ToNumber(localStorage.NonCurrentLiabilities3)/ToNumber(localStorage.TotalEquity3),0)*100;
  localStorage.LongtermDebtToEquityWeighted = localStorage.LongtermDebtToEquity1*localStorage.RatioWeightYear1/100+
                                              localStorage.LongtermDebtToEquity2*localStorage.RatioWeightYear2/100+
   					                          localStorage.LongtermDebtToEquity3*localStorage.RatioWeightYear3/100;
	
  // Debt/Tangible Net Worth = Total Liabilities / Tangibele Net Worth
  localStorage.DebtToTangibleNetWorth0 = round(ToNumber(localStorage.SummaryTotalLiabilities0)/ToNumber(localStorage.TangibleNetWorth0),2);
  localStorage.DebtToTangibleNetWorth1 = round(ToNumber(localStorage.SummaryTotalLiabilities1)/ToNumber(localStorage.TangibleNetWorth1),2);
  localStorage.DebtToTangibleNetWorth2 = round(ToNumber(localStorage.SummaryTotalLiabilities2)/ToNumber(localStorage.TangibleNetWorth2),2);
  localStorage.DebtToTangibleNetWorth3 = round(ToNumber(localStorage.SummaryTotalLiabilities3)/ToNumber(localStorage.TangibleNetWorth3),2);
  localStorage.DebtToTangibleNetWorthWeighted = localStorage.DebtToTangibleNetWorth1*localStorage.RatioWeightYear1/100+
                                                localStorage.DebtToTangibleNetWorth2*localStorage.RatioWeightYear2/100+
  					                            localStorage.DebtToTangibleNetWorth3*localStorage.RatioWeightYear3/100;
  // Equity/Total Assets
  localStorage.EquityToTotalAssets0 = round(ToNumber(localStorage.TotalEquity0)/ToNumber(localStorage.SummaryTotalAssets0),2);
  localStorage.EquityToTotalAssets1 = round(ToNumber(localStorage.TotalEquity1)/ToNumber(localStorage.SummaryTotalAssets1),2);
  localStorage.EquityToTotalAssets2 = round(ToNumber(localStorage.TotalEquity2)/ToNumber(localStorage.SummaryTotalAssets2),2);
  localStorage.EquityToTotalAssets3 = round(ToNumber(localStorage.TotalEquity3)/ToNumber(localStorage.SummaryTotalAssets3),2);
  localStorage.EquityToTotalAssetsWeighted = localStorage.EquityToTotalAssets1*localStorage.RatioWeightYear1/100+
                                             localStorage.EquityToTotalAssets2*localStorage.RatioWeightYear2/100+
					                         localStorage.EquityToTotalAssets3*localStorage.RatioWeightYear3/100;
  // Solvency = Total Assets / Total Liabilities
  localStorage.Solvency0 = round(ToNumber(localStorage.SummaryTotalAssets0)/ToNumber(localStorage.SummaryTotalLiabilities0),2)*100;
  localStorage.Solvency1 = round(ToNumber(localStorage.SummaryTotalAssets1)/ToNumber(localStorage.SummaryTotalLiabilities1),2)*100;
  localStorage.Solvency2 = round(ToNumber(localStorage.SummaryTotalAssets2)/ToNumber(localStorage.SummaryTotalLiabilities2),2)*100;
  localStorage.Solvency3 = round(ToNumber(localStorage.SummaryTotalAssets3)/ToNumber(localStorage.SummaryTotalLiabilities3),2)*100;
  localStorage.SolvencyWeighted = localStorage.Solvency1*localStorage.RatioWeightYear1/100+
		                          localStorage.Solvency2*localStorage.RatioWeightYear2/100+
								  localStorage.Solvency3*localStorage.RatioWeightYear3/100;
  if (localStorage.Solvency0 = "Infinity") {localStorage.Solvency0 = "n/a";}
  if (localStorage.Solvency1 = "Infinity") {localStorage.Solvency1 = "n/a";}
  if (localStorage.Solvency2 = "Infinity") {localStorage.Solvency2 = "n/a";}
  if (localStorage.Solvency3 = "Infinity") {localStorage.Solvency3 = "n/a";}
  if (localStorage.SolvencyWeighted = "Infinity") {localStorage.SolvencyWeighted = "n/a";}
		  
  // CALCULATING DEBT SERVICE RATIOS ====================================================================================================
		   
  //Interest Cover
  localStorage.InterestCover0 = round(ToNumber(localStorage.EBIT0)/ToNumber(localStorage.NetFinanceCosts0),2);
  localStorage.InterestCover1 = round(ToNumber(localStorage.EBIT1)/ToNumber(localStorage.NetFinanceCosts1),2);
  localStorage.InterestCover2 = round(ToNumber(localStorage.EBIT2)/ToNumber(localStorage.NetFinanceCosts2),2);
  localStorage.InterestCover3 = round(ToNumber(localStorage.EBIT3)/ToNumber(localStorage.NetFinanceCosts3),2);
  localStorage.InterestCoverWeighted = localStorage.InterestCover1*localStorage.RatioWeightYear1/100+
		                               localStorage.InterestCover2*localStorage.RatioWeightYear2/100+
								       localStorage.InterestCover3*localStorage.RatioWeightYear3/100;
  if (localStorage.InterestCover0 = "Infinity") {localStorage.InterestCover0 = "n/a";}
  if (localStorage.InterestCover1 = "Infinity") {localStorage.InterestCover1 = "n/a";}
  if (localStorage.InterestCover2 = "Infinity") {localStorage.InterestCover2 = "n/a";}
  if (localStorage.InterestCover3 = "Infinity") {localStorage.InterestCover3 = "n/a";}
  if (localStorage.InterestCoverWeighted = "Infinity") {localStorage.InterestCoverWeighted = "n/a";}

		   
  //EBITDAToDebt = EBITDA/Long-term Debt
  //Step 1: Numerator (EBITDA) = EBIT + Deprecition <= From Non-Current Assets
  var EBITDA0 = ToNumber(localStorage.DepreciationCostOfSales0) + ToNumber(localStorage.DepreciationOpex0) + ToNumber(localStorage.Amortisation0);
  var EBITDA1 = ToNumber(localStorage.DepreciationCostOfSales1) + ToNumber(localStorage.DepreciationOpex1) + ToNumber(localStorage.Amortisation1);
  var EBITDA2 = ToNumber(localStorage.DepreciationCostOfSales2) + ToNumber(localStorage.DepreciationOpex2) + ToNumber(localStorage.Amortisation2);
  var EBITDA3 = ToNumber(localStorage.DepreciationCostOfSales3) + ToNumber(localStorage.DepreciationOpex3) + ToNumber(localStorage.Amortisation3);
  //Step 2: Full Calculation
  localStorage.EBITDAToDebt0 = round(EBITDA0/ToNumber(localStorage.NonCurrentLiabilities0),2)*100;
  localStorage.EBITDAToDebt1 = round(EBITDA0/ToNumber(localStorage.NonCurrentLiabilities1),2)*100;
  localStorage.EBITDAToDebt2 = round(EBITDA0/ToNumber(localStorage.NonCurrentLiabilities2),2)*100;
  localStorage.EBITDAToDebt3 = round(EBITDA0/ToNumber(localStorage.NonCurrentLiabilities3),2)*100;
  localStorage.EBITDAToDebtWeighted =  round(localStorage.EBITDAToDebt1*localStorage.RatioWeightYear1/100+
                                             localStorage.EBITDAToDebt2*localStorage.RatioWeightYear2/100+
	  						                 localStorage.EBITDAToDebt3*localStorage.RatioWeightYear3/100,2);
 //Error trapping
  if  (ToNumber(localStorage.NonCurrentLiabilities0) == 0) {localStorage.EBITDAToDebt0 = "n/a"};
  if  (ToNumber(localStorage.NonCurrentLiabilities1) == 0) {localStorage.EBITDAToDebt1 = "n/a"};
  if  (ToNumber(localStorage.NonCurrentLiabilities2) == 0) {localStorage.EBITDAToDebt2 = "n/a"};
  if  (ToNumber(localStorage.NonCurrentLiabilities3) == 0) {localStorage.EBITDAToDebt3 = "n/a"};
  if  (isNaN(localStorage.EBITDAToDebtWeighted)) {localStorage.EBITDAToDebtWeighted = "n/a"};

		   
		   
  // CALCULATING ACTIVITY RATIOS ===========================================================================================================
		   
  // 1. Total Assets Turnover = Sales/Total Assets. No need to recalculate ratio in the Z score
  localStorage.TotalAssetsTurnover0 = localStorage.SalesToTotalAssets0;
  localStorage.TotalAssetsTurnover1 = localStorage.SalesToTotalAssets1;
  localStorage.TotalAssetsTurnover2 = localStorage.SalesToTotalAssets2;
  localStorage.TotalAssetsTurnover3 = localStorage.SalesToTotalAssets3;
  localStorage.TotalAssetsTurnoverWeighted =  localStorage.TotalAssetsTurnover1*localStorage.RatioWeightYear1/100+
                                             localStorage.TotalAssetsTurnover2*localStorage.RatioWeightYear2/100+
     					                     localStorage.TotalAssetsTurnover3*localStorage.RatioWeightYear3/100;
		   
  // Fixed Assets Turnover = Sales/Fixed Assets
  localStorage.FixedAssetsTurnover0 = round(ToNumber(localStorage.NetSales0)/ToNumber(localStorage.NonCurrentAssets0),2);		   
  localStorage.FixedAssetsTurnover1 = round(ToNumber(localStorage.NetSales0)/ToNumber(localStorage.NonCurrentAssets1),2);		   
  localStorage.FixedAssetsTurnover2 = round(ToNumber(localStorage.NetSales0)/ToNumber(localStorage.NonCurrentAssets2),2);		   
  localStorage.FixedAssetsTurnover3 = round(ToNumber(localStorage.NetSales0)/ToNumber(localStorage.NonCurrentAssets3),2);		   
  localStorage.FixedAssetsTurnoverWeighted =  round(localStorage.FixedAssetsTurnover1*localStorage.RatioWeightYear1/100+
                                                    localStorage.FixedAssetsTurnover2*localStorage.RatioWeightYear2/100+
 	  						                        localStorage.FixedAssetsTurnover3*localStorage.RatioWeightYear3/100,2);
			
  //error trapping
  if (ToNumber(localStorage.NonCurrentAssets0) == 0)   {localStorage.FixedAssetsTurnover0 = "n/a"};
  if (ToNumber(localStorage.NonCurrentAssets1) == 0)   {localStorage.FixedAssetsTurnover1 = "n/a"};
  if (ToNumber(localStorage.NonCurrentAssets2) == 0)   {localStorage.FixedAssetsTurnover2 = "n/a"};
  if (ToNumber(localStorage.NonCurrentAssets3) == 0)   {localStorage.FixedAssetsTurnover3 = "n/a"};
	//if (isNaN(localStorage.FixedAssetsTurnoverWeighted)) {localStorage.FixedAssetsTurnoverWeighted = "n/a"};
			
			
}

function LoadShareholderAnalysisForm()
{
  	     //Company Identification Data and Username HEADER
		 document.getElementById("legal_name").innerHTML = localStorage.legal_name + " " + localStorage.customer_type;
		 document.ShareholderForm.application_ref.value = localStorage.application_ref;
		 document.ShareholderForm.company_reg_no.value = localStorage.company_reg_no;
		 document.ShareholderForm.username.value = localStorage.username;
		 document.ShareholderForm.loan_number.value = localStorage.loan_number;
         //ShareholderForm Data
		 document.ShareholderForm.ShareholderName1.value =  localStorage.ShareholderName1;
         document.ShareholderForm.ShareholderDate1.value =  localStorage.ShareholderDate1;
         document.ShareholderForm.ShareholderGender1.value =  localStorage.ShareholderGender1;
         document.ShareholderForm.ShareholderAge1.value =  localStorage.ShareholderAge1;
         document.ShareholderForm.ShareholderPercentageShares1.value =  localStorage.ShareholderPercentageShares1;
         document.ShareholderForm.ShareholderITCRef1.value =  localStorage.ShareholderITCRef1;
         document.ShareholderForm.ShareholderITCDate1.value =  localStorage.ShareholderITCDate1;
         document.ShareholderForm.ShareholderPaidDebts1.value =  localStorage.ShareholderPaidDebts1;
         document.ShareholderForm.ShareholderDefaults1.value =  localStorage.ShareholderDefaults1;
         document.ShareholderForm.ShareholderJudgements1.value =  localStorage.ShareholderJudgements1;
         document.ShareholderForm.ShareholderTraceAlerts1.value =  localStorage.ShareholderTraceAlerts1;
         document.ShareholderForm.ShareholderBlacklisted1.value =  localStorage.ShareholderBlacklisted1;
         document.ShareholderForm.ShareholderFraudAlert1.value =  localStorage.ShareholderFraudAlert1;
         //document.ShareholderForm.ShareholderTotalScore1.value =  localStorage.ShareholderTotalScore1;
         document.ShareholderForm.ShareholderName2.value =  localStorage.ShareholderName2;
         document.ShareholderForm.ShareholderDate2.value =  localStorage.ShareholderDate2;
         document.ShareholderForm.ShareholderGender2.value =  localStorage.ShareholderGender2;
         document.ShareholderForm.ShareholderAge2.value =  localStorage.ShareholderAge2;
         document.ShareholderForm.ShareholderPercentageShares2.value =  localStorage.ShareholderPercentageShares2;
         document.ShareholderForm.ShareholderITCRef2.value =  localStorage.ShareholderITCRef2;
         document.ShareholderForm.ShareholderITCDate2.value =  localStorage.ShareholderITCDate2;
         document.ShareholderForm.ShareholderPaidDebts2.value =  localStorage.ShareholderPaidDebts2;
         document.ShareholderForm.ShareholderDefaults2.value =  localStorage.ShareholderDefaults2;
         document.ShareholderForm.ShareholderJudgements2.value =  localStorage.ShareholderJudgements2;
         document.ShareholderForm.ShareholderTraceAlerts2.value =  localStorage.ShareholderTraceAlerts2;
         document.ShareholderForm.ShareholderBlacklisted2.value =  localStorage.ShareholderBlacklisted2;
         document.ShareholderForm.ShareholderFraudAlert2.value =  localStorage.ShareholderFraudAlert2;
         //document.ShareholderForm.ShareholderTotalScore2.value =  localStorage.ShareholderTotalScore2;
         document.ShareholderForm.ShareholderName3.value =  localStorage.ShareholderName3;
         document.ShareholderForm.ShareholderDate3.value =  localStorage.ShareholderDate3;
         document.ShareholderForm.ShareholderGender3.value =  localStorage.ShareholderGender3;
         document.ShareholderForm.ShareholderAge3.value =  localStorage.ShareholderAge3;
         document.ShareholderForm.ShareholderPercentageShares3.value =  localStorage.ShareholderPercentageShares3;
         document.ShareholderForm.ShareholderITCRef3.value =  localStorage.ShareholderITCRef3;
         document.ShareholderForm.ShareholderITCDate3.value =  localStorage.ShareholderITCDate3;
         document.ShareholderForm.ShareholderPaidDebts3.value =  localStorage.ShareholderPaidDebts3;
         document.ShareholderForm.ShareholderDefaults3.value =  localStorage.ShareholderDefaults3;
         document.ShareholderForm.ShareholderJudgements3.value =  localStorage.ShareholderJudgements3;
         document.ShareholderForm.ShareholderTraceAlerts3.value =  localStorage.ShareholderTraceAlerts3;
         document.ShareholderForm.ShareholderBlacklisted3.value =  localStorage.ShareholderBlacklisted3;
         document.ShareholderForm.ShareholderFraudAlert3.value =  localStorage.ShareholderFraudAlert3;
         //document.ShareholderForm.ShareholderTotalScore3.value =  localStorage.ShareholderTotalScore3;
         document.ShareholderForm.ShareholderName4.value =  localStorage.ShareholderName4;
         document.ShareholderForm.ShareholderDate4.value =  localStorage.ShareholderDate4;
         document.ShareholderForm.ShareholderGender4.value =  localStorage.ShareholderGender4;
         document.ShareholderForm.ShareholderAge4.value =  localStorage.ShareholderAge4;
         document.ShareholderForm.ShareholderPercentageShares4.value =  localStorage.ShareholderPercentageShares4;
         document.ShareholderForm.ShareholderITCRef4.value =  localStorage.ShareholderITCRef4;
         document.ShareholderForm.ShareholderITCDate4.value =  localStorage.ShareholderITCDate4;
         document.ShareholderForm.ShareholderPaidDebts4.value =  localStorage.ShareholderPaidDebts4;
         document.ShareholderForm.ShareholderDefaults4.value =  localStorage.ShareholderDefaults4;
         document.ShareholderForm.ShareholderJudgements4.value =  localStorage.ShareholderJudgements4;
         document.ShareholderForm.ShareholderTraceAlerts4.value =  localStorage.ShareholderTraceAlerts4;
         document.ShareholderForm.ShareholderBlacklisted4.value =  localStorage.ShareholderBlacklisted4;
         document.ShareholderForm.ShareholderFraudAlert4.value =  localStorage.ShareholderFraudAlert4;
         //document.ShareholderForm.ShareholderTotalScore4.value =  localStorage.ShareholderTotalScore4;
         document.ShareholderForm.ShareholderName5.value =  localStorage.ShareholderName5;
         document.ShareholderForm.ShareholderDate5.value =  localStorage.ShareholderDate5;
         document.ShareholderForm.ShareholderGender5.value =  localStorage.ShareholderGender5;
         document.ShareholderForm.ShareholderAge5.value =  localStorage.ShareholderAge5;
         document.ShareholderForm.ShareholderPercentageShares5.value =  localStorage.ShareholderPercentageShares5;
         document.ShareholderForm.ShareholderITCRef5.value =  localStorage.ShareholderITCRef5;
         document.ShareholderForm.ShareholderITCDate5.value =  localStorage.ShareholderITCDate5;
         document.ShareholderForm.ShareholderPaidDebts5.value =  localStorage.ShareholderPaidDebts5;
         document.ShareholderForm.ShareholderDefaults5.value =  localStorage.ShareholderDefaults5;
         document.ShareholderForm.ShareholderJudgements5.value =  localStorage.ShareholderJudgements5;
         document.ShareholderForm.ShareholderTraceAlerts5.value =  localStorage.ShareholderTraceAlerts5;
         document.ShareholderForm.ShareholderBlacklisted5.value =  localStorage.ShareholderBlacklisted5;
         document.ShareholderForm.ShareholderFraudAlert5.value =  localStorage.ShareholderFraudAlert5;
         //document.ShareholderForm.ShareholderTotalScore5.value =  localStorage.ShareholderTotalScore5;
         document.ShareholderForm.ShareholderComment.value =  localStorage.ShareholderComment;
	
}

function CompanyData_Validate()
{
  var ErrorText = "";
  
  if (localStorage.registration_year == "")   {ErrorText = "Registration Year cannot be empty";}
  if (localStorage.customer_type=="")         {ErrorText = "Customer Type cannot be empty";}  
  if (localStorage.legal_name=="")            {ErrorText = "Legal Name cannot be empty";}
  
  //if (localStorage.trading_name=="")         {ErrorText = "Trading Name cannot be empty";}
  if (localStorage.registration_country=="")  {ErrorText  = "Country of Registration cannot be empty";}
  if (localStorage.financial_year0=="")       {ErrorText  = "Financial Year 0 cannot be empty";}
  if (localStorage.financial_year1=="")       {ErrorText  = "Financial Year 1 cannot be empty";}
  if (localStorage.financial_year2=="")       {ErrorText  = "Financial Year 2 cannot be empty";}
  if (localStorage.financial_year3=="")       {ErrorText  = "Financial Year 3 cannot be empty";}
  if (localStorage.reporting_month_year0=="") {ErrorText  = "Reporting Month Year 0 cannot be empty";}
  
  if (localStorage.reporting_month_year1=="") {ErrorText  = "Reporting Month Year 1 cannot be empty";}
  if (localStorage.reporting_month_year2=="") {ErrorText  = "Reporting Month Year 2 cannot be empty";}
  if (localStorage.reporting_month_year3=="") {ErrorText  = "Reporting Month Year 3 cannot be empty";}
  if (localStorage.audit_status_year0=="")    {ErrorText  = "Audit Status Year 0 cannot be empty";}
  if (localStorage.audit_status_year1=="")    {ErrorText  = "Audit Status Year 1 cannot be empty";}
  if (localStorage.audit_status_year2=="")    {ErrorText  = "Audit Status Year 2 cannot be empty";}
  if (localStorage.audit_status_year3=="")    {ErrorText  = "Audit Status Year 3 cannot be empty";}
  
  if (localStorage.industrial_sector=="")               {ErrorText = "Industrial Sector cannot be empty";}
  if (localStorage.borrower_present_address=="")        {ErrorText = "Present Address cannot be empty";}
  if (localStorage.street_name_and_number=="")          {ErrorText = "Street Name and Nuber cannot be empty";}
  if (localStorage.years_at_present_address=="")        {ErrorText = "Years At Present Address cannot be empty";}
  if (localStorage.e_mail == "")                        {ErrorText = "Email cannot be empty";}
  
  if (localStorage.bond_plot == "")                     {ErrorText = "The Bonded Plot Number cannot be empty";}
  if (localStorage.location_of_acquired_real_estate==""){ErrorText = "Location Of Acquired Real Estate cannot be empty";}
  
  if   (ErrorText == "") {return true;}
  else 
  {
	   alert(ErrorText);
	   return false;
  }
  
}
function CompanyDataForm_SaveData()
{
 		   // Save Date and Username into Income Statement Tracker======================================
		   
		   var today = new Date();
           var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		   var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		   localStorage.CompanyDataTrackerDateSaved = date;
		   localStorage.CompanyDataTrackerSavedBy = localStorage.username;
           //============================================================================================
		 
		 localStorage.application_ref                   = document.CompanyDataForm.application_ref.value;
	     localStorage.company_reg_no                    = document.CompanyDataForm.company_reg_no.value;
	     localStorage.CIF                               = document.CompanyDataForm.CIF.value;
		 localStorage.loan_number                       = document.CompanyDataForm.loan_number.value;
		 localStorage.username                          = document.CompanyDataForm.username.value;
		 localStorage.registration_year                 = document.CompanyDataForm.registration_year.value;
         localStorage.vat_reg_no                        = document.CompanyDataForm.vat_reg_no.value;
		 localStorage.customer_type                     = document.CompanyDataForm.customer_type.value;  
         localStorage.legal_name                        = document.CompanyDataForm.legal_name.value;
         localStorage.trading_name                      = document.CompanyDataForm.trading_name.value;
         localStorage.registration_country              = document.CompanyDataForm.registration_country.value;
         localStorage.financial_year0                   = document.CompanyDataForm.financial_year0.value;
         localStorage.financial_year1                   = document.CompanyDataForm.financial_year1.value;
         localStorage.financial_year2                   = document.CompanyDataForm.financial_year2.value;
         localStorage.financial_year3                   = document.CompanyDataForm.financial_year3.value;
         localStorage.reporting_month_year0             = document.CompanyDataForm.reporting_month_year0.value;
         localStorage.reporting_month_year1             = document.CompanyDataForm.reporting_month_year1.value;
		 localStorage.reporting_month_year2             = document.CompanyDataForm.reporting_month_year2.value;
         localStorage.reporting_month_year3             = document.CompanyDataForm.reporting_month_year3.value;
         localStorage.audit_status_year0                = document.CompanyDataForm.audit_status_year0.value;
         localStorage.audit_status_year1                = document.CompanyDataForm.audit_status_year1.value;
		 localStorage.audit_status_year2                = document.CompanyDataForm.audit_status_year2.value;
		 localStorage.audit_status_year3                = document.CompanyDataForm.audit_status_year3.value;
		 localStorage.real_inflation_year0              = document.CompanyDataForm.real_inflation_year0.value;
 		 localStorage.real_inflation_year1              = document.CompanyDataForm.real_inflation_year1.value;
         localStorage.real_inflation_year2              = document.CompanyDataForm.real_inflation_year2.value;
         localStorage.real_inflation_year3              = document.CompanyDataForm.real_inflation_year3.value;
         localStorage.nominal_inflation_year0           = document.CompanyDataForm.nominal_inflation_year0.value;
         localStorage.nominal_inflation_year1           = document.CompanyDataForm.nominal_inflation_year1.value;
         localStorage.nominal_inflation_year2           = document.CompanyDataForm.nominal_inflation_year2.value;
         localStorage.nominal_inflation_year3           = document.CompanyDataForm.nominal_inflation_year3.value;
         localStorage.industrial_sector                 = document.CompanyDataForm.industrial_sector.value;
         localStorage.borrower_present_address          = document.CompanyDataForm.borrower_present_address.value;
         localStorage.street_name_and_number            = document.CompanyDataForm.street_name_and_number.value;
         localStorage.years_at_present_address          = document.CompanyDataForm.years_at_present_address.value;
         localStorage.e_mail                            = document.CompanyDataForm.e_mail.value;
         localStorage.bond_plot                         = document.CompanyDataForm.bond_plot.value;
	     localStorage.location_of_acquired_real_estate  = document.CompanyDataForm.location_of_acquired_real_estate.value;
         localStorage.main_bank                         = document.CompanyDataForm.main_bank.value;
         localStorage.second_bank                       = document.CompanyDataForm.second_bank .value;
         localStorage.third_bank                        = document.CompanyDataForm.third_bank.value;
          
		 localStorage.username                          = document.CompanyDataForm.username.value;
   
         if (CompanyData_Validate()){
		    alert ("Company Data temporarilly saved(overwritten) to Local Machine");
		 }
}    

function ISForm_SaveData()
{
		   //Save Log into the local Storage Tracker DashBoard
		   
		   var today = new Date();
           var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		   var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		   localStorage.IncomeStatementTrackerDateSaved = date;
		   localStorage.IncomeStatementTrackerSavedBy = localStorage.username;
		  
		  //1. Net Sales
	       localStorage.NetSales0 = ToNumber(document.forms["ISForm"]["NetSalesYear0"].value);
	       localStorage.NetSales1 = ToNumber(document.forms["ISForm"]["NetSalesYear1"].value);
	       localStorage.NetSales2 = ToNumber(document.forms["ISForm"]["NetSalesYear2"].value);    
		   localStorage.NetSales3 = ToNumber(document.forms["ISForm"]["NetSalesYear3"].value);  
		   
		   //2. Cost of Sales - Depreciation  
		   localStorage.CosDep0 = ToNumber(document.forms["ISForm"]["CosDepYear0"].value);
 		   localStorage.CosDep1 = ToNumber(document.forms["ISForm"]["CosDepYear1"].value);
           localStorage.CosDep2 = ToNumber(document.forms["ISForm"]["CosDepYear2"].value);
		   localStorage.CosDep3 = ToNumber(document.forms["ISForm"]["CosDepYear3"].value);
		   
		   //3. Cost of Sales - Other
		   localStorage.CosOther0 = ToNumber(document.forms["ISForm"]["CosOtherYear0"].value);
		   localStorage.CosOther1 = ToNumber(document.forms["ISForm"]["CosOtherYear1"].value);
	       localStorage.CosOther2 = ToNumber(document.forms["ISForm"]["CosOtherYear2"].value);
		   localStorage.CosOther3 = ToNumber(document.forms["ISForm"]["CosOtherYear3"].value);
		   
		   //4. Other Income Line 1
		   localStorage.OtherIncomeLine1_0 = ToNumber(document.forms["ISForm"]["OtherIncomeLine1Year0"].value);
		   localStorage.OtherIncomeLine1_1 = ToNumber(document.forms["ISForm"]["OtherIncomeLine1Year1"].value);
	       localStorage.OtherIncomeLine1_2 = ToNumber(document.forms["ISForm"]["OtherIncomeLine1Year2"].value);
		   localStorage.OtherIncomeLine1_3 = ToNumber(document.forms["ISForm"]["OtherIncomeLine1Year3"].value);
		   
		   //5. Other Income Line 2
		   localStorage.OtherIncomeLine2_0 = ToNumber(document.forms["ISForm"]["OtherIncomeLine2Year0"].value);
		   localStorage.OtherIncomeLine2_1 = ToNumber(document.forms["ISForm"]["OtherIncomeLine2Year1"].value);
	       localStorage.OtherIncomeLine2_2 = ToNumber(document.forms["ISForm"]["OtherIncomeLine2Year2"].value);
		   localStorage.OtherIncomeLine2_3 = ToNumber(document.forms["ISForm"]["OtherIncomeLine2Year3"].value);
		   
		   //6. Other Income Line 3
		   localStorage.OtherIncomeLine3_0 = ToNumber(document.forms["ISForm"]["OtherIncomeLine3Year0"].value);
 		   localStorage.OtherIncomeLine3_1 = ToNumber(document.forms["ISForm"]["OtherIncomeLine3Year1"].value);
           localStorage.OtherIncomeLine3_2 = ToNumber(document.forms["ISForm"]["OtherIncomeLine3Year2"].value);
		   localStorage.OtherIncomeLine3_3 = ToNumber(document.forms["ISForm"]["OtherIncomeLine3Year3"].value);
		   
		   //7. Other Income Line 4
		   localStorage.OtherIncomeLine4_0 = ToNumber(document.forms["ISForm"]["OtherIncomeLine4Year0"].value);
		   localStorage.OtherIncomeLine4_1 = ToNumber(document.forms["ISForm"]["OtherIncomeLine4Year1"].value);
		   localStorage.OtherIncomeLine4_2 = ToNumber(document.forms["ISForm"]["OtherIncomeLine4Year2"].value);
		   localStorage.OtherIncomeLine4_3 = ToNumber(document.forms["ISForm"]["OtherIncomeLine4Year3"].value);
		   
		   //8. Opex Line - Staff Costs
		   localStorage.StaffCosts0 = ToNumber(document.forms["ISForm"]["StaffCostsYear0"].value);
		   localStorage.StaffCosts1 = ToNumber(document.forms["ISForm"]["StaffCostsYear1"].value);
		   localStorage.StaffCosts2 = ToNumber(document.forms["ISForm"]["StaffCostsYear2"].value);
		   localStorage.StaffCosts3 = ToNumber(document.forms["ISForm"]["StaffCostsYear3"].value);

		   //9. Opex Line - Directors Fees
		   localStorage.DirectorsFees0 = ToNumber(document.forms["ISForm"]["DirectorsFeesYear0"].value);
		   localStorage.DirectorsFees1 = ToNumber(document.forms["ISForm"]["DirectorsFeesYear1"].value);
		   localStorage.DirectorsFees2 = ToNumber(document.forms["ISForm"]["DirectorsFeesYear2"].value);
		   localStorage.DirectorsFees3 = ToNumber(document.forms["ISForm"]["DirectorsFeesYear3"].value);
		   
		   //10. Opex Line - Depreciation
		   localStorage.Depreciation0 = ToNumber(document.forms["ISForm"]["DepreciationYear0"].value);
		   localStorage.Depreciation1 = ToNumber(document.forms["ISForm"]["DepreciationYear1"].value);
		   localStorage.Depreciation2 = ToNumber(document.forms["ISForm"]["DepreciationYear2"].value);
		   localStorage.Depreciation3 = ToNumber(document.forms["ISForm"]["DepreciationYear3"].value);
		   
		   //11. Opex Line - Amortisation
		   localStorage.Amortisation0 = ToNumber(document.forms["ISForm"]["AmortisationYear0"].value);
		   localStorage.Amortisation1 = ToNumber(document.forms["ISForm"]["AmortisationYear1"].value);
		   localStorage.Amortisation2 = ToNumber(document.forms["ISForm"]["AmortisationYear2"].value);
		   localStorage.Amortisation3 = ToNumber(document.forms["ISForm"]["AmortisationYear3"].value);
		   
		   //12. Opex Line - NoNameOpex Line 1
		   localStorage.NoNameOpexLine1_0 = ToNumber(document.forms["ISForm"]["NoNameOpexLine1Year0"].value);
		   localStorage.NoNameOpexLine1_1 = ToNumber(document.forms["ISForm"]["NoNameOpexLine1Year1"].value);
		   localStorage.NoNameOpexLine1_2 = ToNumber(document.forms["ISForm"]["NoNameOpexLine1Year2"].value);
		   localStorage.NoNameOpexLine1_3 = ToNumber(document.forms["ISForm"]["NoNameOpexLine1Year3"].value);

           //13. Opex Line - NoNameOPex Line 2
		   localStorage.NoNameOpexLine2_0 = ToNumber(document.forms["ISForm"]["NoNameOpexLine2Year0"].value);
		   localStorage.NoNameOpexLine2_1 = ToNumber(document.forms["ISForm"]["NoNameOpexLine2Year1"].value);
	       localStorage.NoNameOpexLine2_2 = ToNumber(document.forms["ISForm"]["NoNameOpexLine2Year2"].value);
		   localStorage.NoNameOpexLine2_3 = ToNumber(document.forms["ISForm"]["NoNameOpexLine2Year3"].value);
		   
		   //14. Opex Line - Other
		   localStorage.OtherOpex0 = ToNumber(document.forms["ISForm"]["OtherOpexYear0"].value);
		   localStorage.OtherOpex1 = ToNumber(document.forms["ISForm"]["OtherOpexYear1"].value);
           localStorage.OtherOpex2 = ToNumber(document.forms["ISForm"]["OtherOpexYear2"].value);
           localStorage.OtherOpex3 = ToNumber(document.forms["ISForm"]["OtherOpexYear3"].value);
           
		   //15. Net Finance Costs
           localStorage.NetFinanceCosts0 = ToNumber(document.forms["ISForm"]["NetFinanceCostsYear0"].value);
           localStorage.NetFinanceCosts1 = ToNumber(document.forms["ISForm"]["NetFinanceCostsYear1"].value);
		   localStorage.NetFinanceCosts2 = ToNumber(document.forms["ISForm"]["NetFinanceCostsYear2"].value);
		   localStorage.NetFinanceCosts3 = ToNumber(document.forms["ISForm"]["NetFinanceCostsYear3"].value);
           
		   //16. Income Tax
           localStorage.IncomeTax0 = ToNumber(document.forms["ISForm"]["IncomeTaxYear0"].value);
           localStorage.IncomeTax1 = ToNumber(document.forms["ISForm"]["IncomeTaxYear1"].value);
		   localStorage.IncomeTax2 = ToNumber(document.forms["ISForm"]["IncomeTaxYear2"].value);
		   localStorage.IncomeTax3 = ToNumber(document.forms["ISForm"]["IncomeTaxYear3"].value);
           
		   //16. Deferred Tax
           localStorage.DeferredTax0 = ToNumber(document.forms["ISForm"]["DeferredTaxYear0"].value);
           localStorage.DeferredTax1 = ToNumber(document.forms["ISForm"]["DeferredTaxYear1"].value);
		   localStorage.DeferredTax2 = ToNumber(document.forms["ISForm"]["DeferredTaxYear2"].value);
		   localStorage.DeferredTax3 = ToNumber(document.forms["ISForm"]["DeferredTaxYear3"].value);
				   
           //17. Other Income Line Descriptions
		   localStorage.OtherIncomeDescLine1 = document.forms["ISForm"]["OtherIncomeDescLine1"].value;
           localStorage.OtherIncomeDescLine2 = document.forms["ISForm"]["OtherIncomeDescLine2"].value;
           localStorage.OtherIncomeDescLine3 = document.forms["ISForm"]["OtherIncomeDescLine3"].value;
           localStorage.OtherIncomeDescLine4 = document.forms["ISForm"]["OtherIncomeDescLine4"].value;
           //18. Other Opex Line Descriptions
           localStorage.NoNameOpexDescLine1 = document.forms["ISForm"]["NoNameOpexDescLine1"].value;
           localStorage.NoNameOpexDescLine2 = document.forms["ISForm"]["NoNameOpexDescLine2"].value;
          //19. Saving the Calculated Items
 		   localStorage.CosTotal0 = ToNumber(document.forms["ISForm"]["CosTotalYear0"].value);
		   localStorage.CosTotal1 = ToNumber(document.forms["ISForm"]["CosTotalYear1"].value);
		   localStorage.CosTotal2 = ToNumber(document.forms["ISForm"]["CosTotalYear2"].value);
		   localStorage.CosTotal3 = ToNumber(document.forms["ISForm"]["CosTotalYear3"].value);
		   
		   //2. Gross Profit 
		   localStorage.GrossProfit0 = ToNumber(document.forms["ISForm"]["GrossProfitYear0"].value);
		   localStorage.GrossProfit1 = ToNumber(document.forms["ISForm"]["GrossProfitYear1"].value);
		   localStorage.GrossProfit2 = ToNumber(document.forms["ISForm"]["GrossProfitYear2"].value);
		   localStorage.GrossProfit3 = ToNumber(document.forms["ISForm"]["GrossProfitYear3"].value);
		   
		   //3. Total Other Income
		   localStorage.OtherIncomeTotal0 = ToNumber(document.forms["ISForm"]["OtherIncomeTotalYear0"].value);
		   localStorage.OtherIncomeTotal1 = ToNumber(document.forms["ISForm"]["OtherIncomeTotalYear1"].value);
		   localStorage.OtherIncomeTotal2 = ToNumber(document.forms["ISForm"]["OtherIncomeTotalYear2"].value);
		   localStorage.OtherIncomeTotal3 = ToNumber(document.forms["ISForm"]["OtherIncomeTotalYear3"].value);
		   
		   //4. Total Opex
		   localStorage.OpexTotal0 = ToNumber(document.forms["ISForm"]["OpexTotalYear0"].value);
		   localStorage.OpexTotal1 = ToNumber(document.forms["ISForm"]["OpexTotalYear1"].value);
		   localStorage.OpexTotal2 = ToNumber(document.forms["ISForm"]["OpexTotalYear2"].value);
		   localStorage.OpexTotal3 = ToNumber(document.forms["ISForm"]["OpexTotalYear3"].value);
		   
		   //5. EBIT
	       localStorage.EBIT0 = ToNumber(document.forms["ISForm"]["EBITYear0"].value);
           localStorage.EBIT1 = ToNumber(document.forms["ISForm"]["EBITYear1"].value);
		   localStorage.EBIT2 = ToNumber(document.forms["ISForm"]["EBITYear2"].value);
		   localStorage.EBIT3 = ToNumber(document.forms["ISForm"]["EBITYear3"].value);
		   
		   //6. PBT
	       localStorage.PBT0 = ToNumber(document.forms["ISForm"]["PBTYear0"].value);
	       localStorage.PBT1 = ToNumber(document.forms["ISForm"]["PBTYear1"].value);
		   localStorage.PBT2 = ToNumber(document.forms["ISForm"]["PBTYear2"].value);
		   localStorage.PBT3 = ToNumber(document.forms["ISForm"]["PBTYear3"].value);
		   //7. Taxation for the Year
	       localStorage.Taxation0 = ToNumber(document.forms["ISForm"]["TaxationYear0"].value);
	       localStorage.Taxation1 = ToNumber(document.forms["ISForm"]["TaxationYear1"].value);
		   localStorage.Taxation2 = ToNumber(document.forms["ISForm"]["TaxationYear2"].value);
		   localStorage.Taxation3 = ToNumber(document.forms["ISForm"]["TaxationYear3"].value);
		   //8. Net Profit
	       localStorage.NetProfit0 = ToNumber(document.forms["ISForm"]["TaxationYear0"].value);
	       localStorage.NetProfit1 = ToNumber(document.forms["ISForm"]["TaxationYear1"].value);
		   localStorage.NetProfit2 = ToNumber(document.forms["ISForm"]["TaxationYear2"].value);
		   localStorage.NetProfit3 = ToNumber(document.forms["ISForm"]["TaxationYear3"].value);
 	      
  		   alert ("Income Statement Successfully Saved to Local Storage. Press OK to save to database");
}

function CurrentAssetsForm_SaveData()
		{
		
		   // Save Date and Username into Income Statement Tracker======================================
		   
		   var today = new Date();
           var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		   var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		   localStorage.CurrentAssetsTrackerDateSaved = date;
		   localStorage.CurrentAssetsTrackerSavedBy = localStorage.username;
           //============================================================================================
		//Cash Balances
		 localStorage.CashBal0=document.forms["CurrentAssetsForm"]["CashBalYear0"].value;
		 localStorage.CashBal1=document.forms["CurrentAssetsForm"]["CashBalYear1"].value;
		 localStorage.CashBal2=document.forms["CurrentAssetsForm"]["CashBalYear2"].value;
		 localStorage.CashBal3=document.forms["CurrentAssetsForm"]["CashBalYear3"].value;
		
		//Saving Debtors
		localStorage.AccountsReceivable0=document.forms["CurrentAssetsForm"]["AccountsReceivableYear0"].value;
		localStorage.AccountsReceivable1=document.forms["CurrentAssetsForm"]["AccountsReceivableYear1"].value;
		localStorage.AccountsReceivable2=document.forms["CurrentAssetsForm"]["AccountsReceivableYear2"].value;
		localStorage.AccountsReceivable3=document.forms["CurrentAssetsForm"]["AccountsReceivableYear3"].value;
		//Saving Prepayments
		localStorage.Prepayments0=document.forms["CurrentAssetsForm"]["PrepaymentsYear0"].value;
		localStorage.Prepayments1=document.forms["CurrentAssetsForm"]["PrepaymentsYear1"].value;
		localStorage.Prepayments2=document.forms["CurrentAssetsForm"]["PrepaymentsYear2"].value;
		localStorage.Prepayments3=document.forms["CurrentAssetsForm"]["PrepaymentsYear3"].value;
		//Saving Prepaid Tax
		localStorage.PrepaidTax0=document.forms["CurrentAssetsForm"]["PrepaidTaxYear0"].value;
		localStorage.PrepaidTax1=document.forms["CurrentAssetsForm"]["PrepaidTaxYear1"].value;
		localStorage.PrepaidTax2=document.forms["CurrentAssetsForm"]["PrepaidTaxYear2"].value;
		localStorage.PrepaidTax3=document.forms["CurrentAssetsForm"]["PrepaidTaxYear3"].value;
		//Saving Inventory
		localStorage.Inventory0=document.forms["CurrentAssetsForm"]["InventoryYear0"].value;
		localStorage.Inventory1=document.forms["CurrentAssetsForm"]["InventoryYear1"].value;
		localStorage.Inventory2=document.forms["CurrentAssetsForm"]["InventoryYear2"].value;
		localStorage.Inventory3=document.forms["CurrentAssetsForm"]["InventoryYear3"].value;
		//Saving Other Current Assets NonInter Company Line 1
		localStorage.OtherCurrentAssetsNonInterCompanyLine1_0=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year0"].value;
		localStorage.OtherCurrentAssetsNonInterCompanyLine1_1=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year1"].value;
		localStorage.OtherCurrentAssetsNonInterCompanyLine1_2=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year2"].value;
	  	localStorage.OtherCurrentAssetsNonInterCompanyLine1_3=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine1Year3"].value;
		//Saving Other Current Assets NonInter Company Line 2
		localStorage.OtherCurrentAssetsNonInterCompanyLine2_0=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year0"].value;
		localStorage.OtherCurrentAssetsNonInterCompanyLine2_1=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year1"].value;
		localStorage.OtherCurrentAssetsNonInterCompanyLine2_2=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year2"].value;
	  	localStorage.OtherCurrentAssetsNonInterCompanyLine2_3=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine2Year3"].value;
		//Saving Other Current Assets NonInter Company Line 3
		localStorage.OtherCurrentAssetsNonInterCompanyLine3_0=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year0"].value;
		localStorage.OtherCurrentAssetsNonInterCompanyLine3_1=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year1"].value;
		localStorage.OtherCurrentAssetsNonInterCompanyLine3_2=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year2"].value;
	  	localStorage.OtherCurrentAssetsNonInterCompanyLine3_3=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyLine3Year3"].value;
	    //Saving Other Current Assets Inter Company Line 1
		localStorage.OtherCurrentAssetsInterCompanyLine1_0=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year0"].value;
		localStorage.OtherCurrentAssetsInterCompanyLine1_1=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year1"].value;
		localStorage.OtherCurrentAssetsInterCompanyLine1_2=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year2"].value;
	  	localStorage.OtherCurrentAssetsInterCompanyLine1_3=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine1Year3"].value;
		//Saving Other Current Assets Inter Company Line 2
		localStorage.OtherCurrentAssetsInterCompanyLine2_0=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year0"].value;
		localStorage.OtherCurrentAssetsInterCompanyLine2_1=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year1"].value;
		localStorage.OtherCurrentAssetsInterCompanyLine2_2=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year2"].value;
	  	localStorage.OtherCurrentAssetsInterCompanyLine2_3=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine2Year3"].value;
		//Saving Other Current Assets Inter Company Line 3
		localStorage.OtherCurrentAssetsInterCompanyLine3_0=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year0"].value;
		localStorage.OtherCurrentAssetsInterCompanyLine3_1=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year1"].value;
		localStorage.OtherCurrentAssetsInterCompanyLine3_2=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year2"].value;
	  	localStorage.OtherCurrentAssetsInterCompanyLine3_3=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyLine3Year3"].value;
	    // Saving Additional line descriptions entered by the user
	    //Loading Other Current Assets Non Inter Company Descriptions
		localStorage.OtherCurrentAssetsNonInterCompanyDescLine1=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyDescLine1"].value;
		localStorage.OtherCurrentAssetsNonInterCompanyDescLine2=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyDescLine2"].value;
	  	localStorage.OtherCurrentAssetsNonInterCompanyDescLine3=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsNonInterCompanyDescLine3"].value;
        //Loading Other Current Assets Inter Company Descriptions
	    localStorage.OtherCurrentAssetsInterCompanyDescLine1=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyDescLine1"].value;
		localStorage.OtherCurrentAssetsInterCompanyDescLine2=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyDescLine2"].value;
	  	localStorage.OtherCurrentAssetsInterCompanyDescLine3=document.forms["CurrentAssetsForm"]["OtherCurrentAssetsInterCompanyDescLine3"].value;
  	
	
		
		//Saving a Total of Current Assets for export to the Summary Balance Sheet 
		
		 localStorage.CurrentAssets0 = document.forms["CurrentAssetsForm"]["TotalCurrentAssetsYear0"].value;
		 localStorage.CurrentAssets1 = document.forms["CurrentAssetsForm"]["TotalCurrentAssetsYear1"].value;
		 localStorage.CurrentAssets2 = document.forms["CurrentAssetsForm"]["TotalCurrentAssetsYear2"].value;
		 localStorage.CurrentAssets3 = document.forms["CurrentAssetsForm"]["TotalCurrentAssetsYear3"].value;
         alert("Current assets saved to temporary local storage. Press OK to save to database");
}
		
		
function CurrentLiabilitiesForm_SaveData()
{
		   // Save Date and Username into Income Statement Tracker======================================
		   
		var today = new Date();
        var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		localStorage.CurrentLiabilitiesTrackerDateSaved = date;
		localStorage.CurrentLiabilitiesTrackerSavedBy = localStorage.username;
         //============================================================================================
		
		//Bank Overdraft
		 localStorage.BankOverdraft0=document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear0"].value;
		 localStorage.BankOverdraft1=document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear1"].value;
		 localStorage.BankOverdraft2=document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear2"].value;
		 localStorage.BankOverdraft3=document.forms["CurrentLiabilitiesForm"]["BankOverdraftYear3"].value;
		
		//Saving Debtors
		localStorage.AccountsPayable0=document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear0"].value;
		localStorage.AccountsPayable1=document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear1"].value;
		localStorage.AccountsPayable2=document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear2"].value;
		localStorage.AccountsPayable3=document.forms["CurrentLiabilitiesForm"]["AccountsPayableYear3"].value;
		//Saving Accruals
		localStorage.Accruals0=document.forms["CurrentLiabilitiesForm"]["AccrualsYear0"].value;
		localStorage.Accruals1=document.forms["CurrentLiabilitiesForm"]["AccrualsYear1"].value;
		localStorage.Accruals2=document.forms["CurrentLiabilitiesForm"]["AccrualsYear2"].value;
		localStorage.Accruals3=document.forms["CurrentLiabilitiesForm"]["AccrualsYear3"].value;
		//Saving Prepaid Tax
		localStorage.TaxPayable0=document.forms["CurrentLiabilitiesForm"]["TaxPayableYear0"].value;
		localStorage.TaxPayable1=document.forms["CurrentLiabilitiesForm"]["TaxPayableYear1"].value;
		localStorage.TaxPayable2=document.forms["CurrentLiabilitiesForm"]["TaxPayableYear2"].value;
		localStorage.TaxPayable3=document.forms["CurrentLiabilitiesForm"]["TaxPayableYear3"].value;
		//Saving DividendsPayable
		localStorage.DividendsPayable0=document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear0"].value;
		localStorage.DividendsPayable1=document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear1"].value;
		localStorage.DividendsPayable2=document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear2"].value;
		localStorage.DividendsPayable3=document.forms["CurrentLiabilitiesForm"]["DividendsPayableYear3"].value;
		//Saving Current Portion Long Term Debt
		localStorage.CurrentPortionLongTermDebt0=document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear0"].value;
		localStorage.CurrentPortionLongTermDebt1=document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear1"].value;
		localStorage.CurrentPortionLongTermDebt2=document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear2"].value;
		localStorage.CurrentPortionLongTermDebt3=document.forms["CurrentLiabilitiesForm"]["CurrentPortionLongTermDebtYear3"].value;
		//Saving Other Current Liabilities NonInter Company Line 1
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_0=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year0"].value;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_1=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year1"].value;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_2=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year2"].value;
	  	localStorage.OtherCurrentLiabilitiesNonInterCompanyLine1_3=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine1Year3"].value;
		//Saving Other Current Liabilities NonInter Company Line 2
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_0=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year0"].value;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_1=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year1"].value;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_2=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year2"].value;
	  	localStorage.OtherCurrentLiabilitiesNonInterCompanyLine2_3=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine2Year3"].value;
		//Saving Other Current Liabilities NonInter Company Line 3
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_0=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year0"].value;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_1=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year1"].value;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_2=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year2"].value;
	  	localStorage.OtherCurrentLiabilitiesNonInterCompanyLine3_3=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyLine3Year3"].value;
	    //Saving Other Current Liabilities Inter Company Line 1
		localStorage.OtherCurrentLiabilitiesInterCompanyLine1_0=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year0"].value;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine1_1=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year1"].value;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine1_2=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year2"].value;
	  	localStorage.OtherCurrentLiabilitiesInterCompanyLine1_3=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine1Year3"].value;
		//Saving Other Current Liabilities Inter Company Line 2
		localStorage.OtherCurrentLiabilitiesInterCompanyLine2_0=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year0"].value;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine2_1=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year1"].value;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine2_2=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year2"].value;
	  	localStorage.OtherCurrentLiabilitiesInterCompanyLine2_3=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine2Year3"].value;
		//Saving Other Current Liabilities Inter Company Line 3
		localStorage.OtherCurrentLiabilitiesInterCompanyLine3_0=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year0"].value;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine3_1=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year1"].value;
		localStorage.OtherCurrentLiabilitiesInterCompanyLine3_2=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year2"].value;
	  	localStorage.OtherCurrentLiabilitiesInterCompanyLine3_3=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyLine3Year3"].value;
	    // Saving Additional line descriptions entered by the user
	    //Loading Other Current Liabilities Non Inter Company Descriptions
		localStorage.OtherCurrentLiabilitiesNonInterCompanyDescLine1=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyDescLine1"].value;
		localStorage.OtherCurrentLiabilitiesNonInterCompanyDescLine2=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyDescLine2"].value;
	  	localStorage.OtherCurrentLiabilitiesNonInterCompanyDescLine3=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesNonInterCompanyDescLine3"].value;
        //Loading Other Current Liabilities Inter Company Descriptions
	    localStorage.OtherCurrentLiabilitiesInterCompanyDescLine1=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyDescLine1"].value;
		localStorage.OtherCurrentLiabilitiesInterCompanyDescLine2=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyDescLine2"].value;
	  	localStorage.OtherCurrentLiabilitiesInterCompanyDescLine3=document.forms["CurrentLiabilitiesForm"]["OtherCurrentLiabilitiesInterCompanyDescLine3"].value;
  	
	
		
		//Saving a Total of Current Liabilities for export to the Summary Balance Sheet 
		
		 localStorage.CurrentLiabilities0 = document.forms["CurrentLiabilitiesForm"]["TotalCurrentLiabilitiesYear0"].value;
		 localStorage.CurrentLiabilities1 = document.forms["CurrentLiabilitiesForm"]["TotalCurrentLiabilitiesYear1"].value;
		 localStorage.CurrentLiabilities2 = document.forms["CurrentLiabilitiesForm"]["TotalCurrentLiabilitiesYear2"].value;
		 localStorage.CurrentLiabilities3 = document.forms["CurrentLiabilitiesForm"]["TotalCurrentLiabilitiesYear3"].value;
}

function NonCurrentAssetsForm_SaveData()
{
		   // Save Date and Username into Income Statement Tracker======================================
		   
		   var today = new Date();
           var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		   var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		   localStorage.NonCurrentAssetsTrackerDateSaved = date;
		   localStorage.NonCurrentAssetsTrackerSavedBy = localStorage.username;
           //============================================================================================
		
		//Saving Opening NBV
		 localStorage.OpeningNBV0=document.forms["NonCurrentAssetsForm"]["OpeningNBVYear0"].value;
		 localStorage.OpeningNBV1=document.forms["NonCurrentAssetsForm"]["OpeningNBVYear1"].value;
		 localStorage.OpeningNBV2=document.forms["NonCurrentAssetsForm"]["OpeningNBVYear2"].value;
		 localStorage.OpeningNBV3=document.forms["NonCurrentAssetsForm"]["OpeningNBVYear3"].value;
		
		//Additions
		localStorage.Additions0=document.forms["NonCurrentAssetsForm"]["AdditionsYear0"].value;
		localStorage.Additions1=document.forms["NonCurrentAssetsForm"]["AdditionsYear1"].value;
		localStorage.Additions2=document.forms["NonCurrentAssetsForm"]["AdditionsYear2"].value;
		localStorage.Additions3=document.forms["NonCurrentAssetsForm"]["AdditionsYear3"].value;
		//Saving Revaluation
		localStorage.Revaluation0=document.forms["NonCurrentAssetsForm"]["RevaluationYear0"].value;
		localStorage.Revaluation1=document.forms["NonCurrentAssetsForm"]["RevaluationYear1"].value;
		localStorage.Revaluation2=document.forms["NonCurrentAssetsForm"]["RevaluationYear2"].value;
		localStorage.Revaluation3=document.forms["NonCurrentAssetsForm"]["RevaluationYear3"].value;
		//Saving Depreciations - Costs Of Sales
		localStorage.DepreciationCostOfSales0=document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear0"].value;
		localStorage.DepreciationCostOfSales1=document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear1"].value;
		localStorage.DepreciationCostOfSales2=document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear2"].value;
		localStorage.DepreciationCostOfSales3=document.forms["NonCurrentAssetsForm"]["DepreciationCostOfSalesYear3"].value;
		//Saving Depreciation - Opex
		localStorage.DepreciationOpex0=document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear0"].value;
		localStorage.DepreciationOpex1=document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear1"].value;
		localStorage.DepreciationOpex2=document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear2"].value;
		localStorage.DepreciationOpex3=document.forms["NonCurrentAssetsForm"]["DepreciationOpexYear3"].value;
		//Saving Other Movements PPE
		localStorage.OtherMovementsPPE0=document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear0"].value;
		localStorage.OtherMovementsPPE1=document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear1"].value;
		localStorage.OtherMovementsPPE2=document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear2"].value;
		localStorage.OtherMovementsPPE3=document.forms["NonCurrentAssetsForm"]["OtherMovementsPPEYear3"].value;
	
		//Saving Other Non Current Assets Line 1
		localStorage.OtherNonCurrentAssetsLine1_0=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year0"].value;
		localStorage.OtherNonCurrentAssetsLine1_1=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year1"].value;
		localStorage.OtherNonCurrentAssetsLine1_2=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year2"].value;
	  	localStorage.OtherNonCurrentAssetsLine1_3=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year3"].value;
		//Saving Other Non Current Assets Line 2
		localStorage.OtherNonCurrentAssetsLine2_0=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year0"].value;
		localStorage.OtherNonCurrentAssetsLine2_1=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year1"].value;
		localStorage.OtherNonCurrentAssetsLine2_2=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year2"].value;
	  	localStorage.OtherNonCurrentAssetsLine2_3=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year3"].value;
		//Saving Other Non Current Assets Line 3
		localStorage.OtherNonCurrentAssetsLine3_0=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year0"].value;
		localStorage.OtherNonCurrentAssetsLine3_1=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year1"].value;
		localStorage.OtherNonCurrentAssetsLine3_2=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year2"].value;
	  	localStorage.OtherNonCurrentAssetsLine3_3=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year3"].value;
    
	        //Saving Land and Buildings NBV
		localStorage.LandBuildingsNBV0=document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear0"].value;
		localStorage.LandBuildingsNBV1=document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear1"].value;
		localStorage.LandBuildingsNBV2=document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear2"].value;
		localStorage.LandBuildingsNBV3=document.forms["NonCurrentAssetsForm"]["LandBuildingsNBVYear3"].value;
	
		//Saving Investment Property
		localStorage.InvestmentProperty0=document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear0"].value;
		localStorage.InvestmentProperty1=document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear1"].value;
		localStorage.InvestmentProperty2=document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear2"].value;
		localStorage.InvestmentProperty3=document.forms["NonCurrentAssetsForm"]["InvestmentPropertyYear3"].value;
	     	//Saving Intangible Assets
		localStorage.IntangibleAssets0=document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear0"].value;
		localStorage.IntangibleAssets1=document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear1"].value;
		localStorage.IntangibleAssets2=document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear2"].value;
		localStorage.IntangibleAssets3=document.forms["NonCurrentAssetsForm"]["IntangibleAssetsYear3"].value;
                
					//Saving Other Non Current Assets Line 1
		localStorage.OtherNonCurrentAssetsLine1_0=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year0"].value;
		localStorage.OtherNonCurrentAssetsLine1_1=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year1"].value;
		localStorage.OtherNonCurrentAssetsLine1_2=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year2"].value;
	  	localStorage.OtherNonCurrentAssetsLine1_3=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine1Year3"].value;
                //Saving Other Non Current Assets Line 2
		localStorage.OtherNonCurrentAssetsLine2_0=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year0"].value;
		localStorage.OtherNonCurrentAssetsLine2_1=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year1"].value;
		localStorage.OtherNonCurrentAssetsLine2_2=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year2"].value;
	  	localStorage.OtherNonCurrentAssetsLine2_3=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine2Year3"].value;
		//Saving Other Non Current Assets Line 3
		localStorage.OtherNonCurrentAssetsLine3_0=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year0"].value;
		localStorage.OtherNonCurrentAssetsLine3_1=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year1"].value;
		localStorage.OtherNonCurrentAssetsLine3_2=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year2"].value;
	  	localStorage.OtherNonCurrentAssetsLine3_3=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsLine3Year3"].value;
	 		
         // Saving Additional line descriptions entered by the user
	    //Loading Other Non Current Assets Descriptions
		localStorage.OtherNonCurrentAssetsDescLine1=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsDescLine1"].value;
		localStorage.OtherNonCurrentAssetsDescLine2=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsDescLine2"].value;
	  	localStorage.OtherNonCurrentAssetsDescLine3=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsDescLine3"].value;
        //Loading Other Non Current Assets Comments
	    localStorage.PPEComments=document.forms["NonCurrentAssetsForm"]["PPEComments"].value;
		localStorage.OtherNonCurrentAssetsComments=document.forms["NonCurrentAssetsForm"]["OtherNonCurrentAssetsComments"].value;
	  	
  	
	
		
		//Saving a Total of Non Current Assets for export to the Summary Balance Sheet 
		
		 localStorage.NonCurrentAssets0 = document.forms["NonCurrentAssetsForm"]["TotalNonCurrentAssetsYear0"].value;
		 localStorage.NonCurrentAssets1 = document.forms["NonCurrentAssetsForm"]["TotalNonCurrentAssetsYear1"].value;
		 localStorage.NonCurrentAssets2 = document.forms["NonCurrentAssetsForm"]["TotalNonCurrentAssetsYear2"].value;
		 localStorage.NonCurrentAssets3 = document.forms["NonCurrentAssetsForm"]["TotalNonCurrentAssetsYear3"].value;
		 
}
function NonCurrentLiabilitiesForm_SaveData()
{
		   // Save Date and Username into Income Statement Tracker======================================
		   
		   var today = new Date();
           var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		   var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		   localStorage.CurrentLiabilitiesTrackerDateSaved = date;
		   localStorage.CurrentLiabilitiesTrackerSavedBy = localStorage.username;
           //============================================================================================
		
		//Mortgage Loans
		 localStorage.MortgageLoans0=document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear0"].value;
		 localStorage.MortgageLoans1=document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear1"].value;
		 localStorage.MortgageLoans2=document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear2"].value;
		 localStorage.MortgageLoans3=document.forms["NonCurrentLiabilitiesForm"]["MortgageLoansYear3"].value;
		
		//Term Loans
		localStorage.TermLoans0=document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear0"].value;
		localStorage.TermLoans1=document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear1"].value;
		localStorage.TermLoans2=document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear2"].value;
		localStorage.TermLoans3=document.forms["NonCurrentLiabilitiesForm"]["TermLoansYear3"].value;
		//Saving Bonds
		localStorage.Bonds0=document.forms["NonCurrentLiabilitiesForm"]["BondsYear0"].value;
		localStorage.Bonds1=document.forms["NonCurrentLiabilitiesForm"]["BondsYear1"].value;
		localStorage.Bonds2=document.forms["NonCurrentLiabilitiesForm"]["BondsYear2"].value;
		localStorage.Bonds3=document.forms["NonCurrentLiabilitiesForm"]["BondsYear3"].value;
		//Saving Finance Leases
		localStorage.FinanceLeases0=document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear0"].value;
		localStorage.FinanceLeases1=document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear1"].value;
		localStorage.FinanceLeases2=document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear2"].value;
		localStorage.FinanceLeases3=document.forms["NonCurrentLiabilitiesForm"]["FinanceLeasesYear3"].value;
		//Saving OtherLongTermBorrowings
		localStorage.OtherLongTermBorrowings0=document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear0"].value;
		localStorage.OtherLongTermBorrowings1=document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear1"].value;
		localStorage.OtherLongTermBorrowings2=document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear2"].value;
		localStorage.OtherLongTermBorrowings3=document.forms["NonCurrentLiabilitiesForm"]["OtherLongTermBorrowingsYear3"].value;
		//Saving Shareholders Loans
		localStorage.ShareholdersLoans0=document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear0"].value;
		localStorage.ShareholdersLoans1=document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear1"].value;
		localStorage.ShareholdersLoans2=document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear2"].value;
		localStorage.ShareholdersLoans3=document.forms["NonCurrentLiabilitiesForm"]["ShareholdersLoansYear3"].value;
	//Saving Inter Companyy Loans Line 1
		localStorage.InterCompanyLoansLine1_0=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year0"].value;
		localStorage.InterCompanyLoansLine1_1=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year1"].value;
		localStorage.InterCompanyLoansLine1_2=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year2"].value;
	  	localStorage.InterCompanyLoansLine1_3=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine1Year3"].value;
		//Saving Inter Companyy Loans Line 2
		localStorage.InterCompanyLoansLine2_0=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year0"].value;
		localStorage.InterCompanyLoansLine2_1=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year1"].value;
		localStorage.InterCompanyLoansLine2_2=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year2"].value;
	  	localStorage.InterCompanyLoansLine2_3=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine2Year3"].value;
		//Saving Inter Companyy Loans Line 3
		localStorage.InterCompanyLoansLine3_0=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year0"].value;
		localStorage.InterCompanyLoansLine3_1=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year1"].value;
		localStorage.InterCompanyLoansLine3_2=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year2"].value;
	  	localStorage.InterCompanyLoansLine3_3=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansLine3Year3"].value;
	    //Saving Deferred Tax Balance
		localStorage.DeferredTaxBalance0=document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear0"].value;
		localStorage.DeferredTaxBalance1=document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear1"].value;
		localStorage.DeferredTaxBalance2=document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear2"].value;
		localStorage.DeferredTaxBalance3=document.forms["NonCurrentLiabilitiesForm"]["DeferredTaxBalanceYear3"].value;
		//Saving Provisions
		localStorage.Provisions0=document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear0"].value;
		localStorage.Provisions1=document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear1"].value;
		localStorage.Provisions2=document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear2"].value;
		localStorage.Provisions3=document.forms["NonCurrentLiabilitiesForm"]["ProvisionsYear3"].value;
	    //Saving Other Non Current Liabilities Line 1
		localStorage.OtherNonCurrentLiabilitiesLine1_0=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year0"].value;
		localStorage.OtherNonCurrentLiabilitiesLine1_1=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year1"].value;
		localStorage.OtherNonCurrentLiabilitiesLine1_2=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year2"].value;
	  	localStorage.OtherNonCurrentLiabilitiesLine1_3=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine1Year3"].value;
		//Saving Other Non Current Liabilities Line 2
		localStorage.OtherNonCurrentLiabilitiesLine2_0=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year0"].value;
		localStorage.OtherNonCurrentLiabilitiesLine2_1=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year1"].value;
		localStorage.OtherNonCurrentLiabilitiesLine2_2=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year2"].value;
	  	localStorage.OtherNonCurrentLiabilitiesLine2_3=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine2Year3"].value;
		//Saving Other Non Current Liabilities Line 3
		localStorage.OtherNonCurrentLiabilitiesLine3_0=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year0"].value;
		localStorage.OtherNonCurrentLiabilitiesLine3_1=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year1"].value;
		localStorage.OtherNonCurrentLiabilitiesLine3_2=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year2"].value;
	  	localStorage.OtherNonCurrentLiabilitiesLine3_3=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesLine3Year3"].value;
	    // Saving Additional line descriptions entered by the user
	    //Loading Other Current Assets Non Inter Company Descriptions
		localStorage.InterCompanyLoansDescLine1=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansDescLine1"].value;
		localStorage.InterCompanyLoansDescLine2=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansDescLine2"].value;
	  	localStorage.InterCompanyLoansDescLine3=document.forms["NonCurrentLiabilitiesForm"]["InterCompanyLoansDescLine3"].value;
        //Loading Other Current Assets Inter Company Descriptions
	    localStorage.OtherNonCurrentLiabilitiesDescLine1=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesDescLine1"].value;
		localStorage.OtherNonCurrentLiabilitiesDescLine2=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesDescLine2"].value;
	  	localStorage.OtherNonCurrentLiabilitiesDescLine3=document.forms["NonCurrentLiabilitiesForm"]["OtherNonCurrentLiabilitiesDescLine3"].value;
  	
	
		
		//Saving a Total of Current Assets for export to the Summary Balance Sheet 
		
		 localStorage.NonCurrentLiabilities0 = document.forms["NonCurrentLiabilitiesForm"]["TotalNonCurrentLiabilitiesYear0"].value;
		 localStorage.NonCurrentLiabilities1 = document.forms["NonCurrentLiabilitiesForm"]["TotalNonCurrentLiabilitiesYear1"].value;
		 localStorage.NonCurrentLiabilities2 = document.forms["NonCurrentLiabilitiesForm"]["TotalNonCurrentLiabilitiesYear2"].value;
		 localStorage.NonCurrentLiabilities3 = document.forms["NonCurrentLiabilitiesForm"]["TotalNonCurrentLiabilitiesYear3"].value;
}				
function EquityForm_SaveData()
{
		   // Save Date and Username into Income Statement Tracker======================================
		   
		   var today = new Date();
           var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		   var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		   localStorage.EquityTrackerDateSaved = date;
		   localStorage.EquityTrackerSavedBy = localStorage.username;
           //============================================================================================

		//Saving Opening Retained Profits
		 localStorage.OpeningRetainedProfits0=document.forms["EquityForm"]["OpeningRetainedProfitsYear0"].value;
		 localStorage.OpeningRetainedProfits1=document.forms["EquityForm"]["OpeningRetainedProfitsYear1"].value;
		 localStorage.OpeningRetainedProfits2=document.forms["EquityForm"]["OpeningRetainedProfitsYear2"].value;
		 localStorage.OpeningRetainedProfits3=document.forms["EquityForm"]["OpeningRetainedProfitsYear3"].value;
		//Saving Closing Retained Profits
		 localStorage.ClosingRetainedProfits0=document.forms["EquityForm"]["ClosingRetainedProfitsYear0"].value;
		 localStorage.ClosingRetainedProfits1=document.forms["EquityForm"]["ClosingRetainedProfitsYear1"].value;
		 localStorage.ClosingRetainedProfits2=document.forms["EquityForm"]["ClosingRetainedProfitsYear2"].value;
		 localStorage.ClosingRetainedProfits3=document.forms["EquityForm"]["ClosingRetainedProfitsYear3"].value;
		
		//Share Capital
		localStorage.ShareCapital0=document.forms["EquityForm"]["ShareCapitalYear0"].value;
		localStorage.ShareCapital1=document.forms["EquityForm"]["ShareCapitalYear1"].value;
		localStorage.ShareCapital2=document.forms["EquityForm"]["ShareCapitalYear2"].value;
		localStorage.ShareCapital3=document.forms["EquityForm"]["ShareCapitalYear3"].value;
		//Saving Share Premium
		localStorage.SharePremium0=document.forms["EquityForm"]["SharePremiumYear0"].value;
		localStorage.SharePremium1=document.forms["EquityForm"]["SharePremiumYear1"].value;
		localStorage.SharePremium2=document.forms["EquityForm"]["SharePremiumYear2"].value;
		localStorage.SharePremium3=document.forms["EquityForm"]["SharePremiumYear3"].value;
		//Saving Revaluation Reserve
		localStorage.RevaluationReserve0=document.forms["EquityForm"]["RevaluationReserveYear0"].value;
		localStorage.RevaluationReserve1=document.forms["EquityForm"]["RevaluationReserveYear1"].value;
		localStorage.RevaluationReserve2=document.forms["EquityForm"]["RevaluationReserveYear2"].value;
		localStorage.RevaluationReserve3=document.forms["EquityForm"]["RevaluationReserveYear3"].value;
		//Saving Net Profit
		localStorage.NetProfit0=document.forms["EquityForm"]["NetProfitYear1"].value;
		localStorage.NetProfit1=document.forms["EquityForm"]["NetProfitYear1"].value;
		localStorage.NetProfit2=document.forms["EquityForm"]["NetProfitYear2"].value;
		localStorage.NetProfit3=document.forms["EquityForm"]["NetProfitYear3"].value;
		//Saving Dividends
		localStorage.Dividends0=document.forms["EquityForm"]["DividendsYear1"].value;
		localStorage.Dividends1=document.forms["EquityForm"]["DividendsYear1"].value;
		localStorage.Dividends2=document.forms["EquityForm"]["DividendsYear2"].value;
		localStorage.Dividends3=document.forms["EquityForm"]["DividendsYear3"].value;
	
		//Saving Other Non Distributable Reserves Line 1
		localStorage.OtherNonDistributableReservesLine1_0=document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year0"].value;
		localStorage.OtherNonDistributableReservesLine1_1=document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year1"].value;
		localStorage.OtherNonDistributableReservesLine1_2=document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year2"].value;
	  	localStorage.OtherNonDistributableReservesLine1_3=document.forms["EquityForm"]["OtherNonDistributableReservesLine1Year3"].value;
		//Saving Other Non Distributable Reserves Line 2
		localStorage.OtherNonDistributableReservesLine2_0=document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year0"].value;
		localStorage.OtherNonDistributableReservesLine2_1=document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year1"].value;
		localStorage.OtherNonDistributableReservesLine2_2=document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year2"].value;
	  	localStorage.OtherNonDistributableReservesLine2_3=document.forms["EquityForm"]["OtherNonDistributableReservesLine2Year3"].value;
		//Saving Other Non Distributable Reserves Line 3
		localStorage.OtherNonDistributableReservesLine3_0=document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year0"].value;
		localStorage.OtherNonDistributableReservesLine3_1=document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year1"].value;
		localStorage.OtherNonDistributableReservesLine3_2=document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year2"].value;
	  	localStorage.OtherNonDistributableReservesLine3_3=document.forms["EquityForm"]["OtherNonDistributableReservesLine3Year3"].value;
    
	        //Saving Retained Profits Adjustment
		localStorage.RetainedProfitsAdjustments0=document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear0"].value;
		localStorage.RetainedProfitsAdjustments1=document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear1"].value;
		localStorage.RetainedProfitsAdjustments2=document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear2"].value;
		localStorage.RetainedProfitsAdjustments3=document.forms["EquityForm"]["RetainedProfitsAdjustmentsYear3"].value;
	
	     
		//Saving Other Distributable Reserves Line 1
		localStorage.OtherDistributableReservesLine1_0=document.forms["EquityForm"]["OtherDistributableReservesLine1Year0"].value;
		localStorage.OtherDistributableReservesLine1_1=document.forms["EquityForm"]["OtherDistributableReservesLine1Year1"].value;
		localStorage.OtherDistributableReservesLine1_2=document.forms["EquityForm"]["OtherDistributableReservesLine1Year2"].value;
	  	localStorage.OtherDistributableReservesLine1_3=document.forms["EquityForm"]["OtherDistributableReservesLine1Year3"].value;
                //Saving Other Distributable Reserves Line 2
		localStorage.OtherDistributableReservesLine2_0=document.forms["EquityForm"]["OtherDistributableReservesLine2Year0"].value;
		localStorage.OtherDistributableReservesLine2_1=document.forms["EquityForm"]["OtherDistributableReservesLine2Year1"].value;
		localStorage.OtherDistributableReservesLine2_2=document.forms["EquityForm"]["OtherDistributableReservesLine2Year2"].value;
	  	localStorage.OtherDistributableReservesLine2_3=document.forms["EquityForm"]["OtherDistributableReservesLine2Year3"].value;
		//Saving Other Distributable Reserves Line 3
		localStorage.OtherDistributableReservesLine3_0=document.forms["EquityForm"]["OtherDistributableReservesLine3Year0"].value;
		localStorage.OtherDistributableReservesLine3_1=document.forms["EquityForm"]["OtherDistributableReservesLine3Year1"].value;
		localStorage.OtherDistributableReservesLine3_2=document.forms["EquityForm"]["OtherDistributableReservesLine3Year2"].value;
	  	localStorage.OtherDistributableReservesLine3_3=document.forms["EquityForm"]["OtherDistributableReservesLine3Year3"].value;
	 		
                // Saving Additional line descriptions entered by the user
	        //Saving Other Non Distributable Reserves Descriptions
		localStorage.OtherNonDistributableReservesDescLine1=document.forms["EquityForm"]["OtherNonDistributableReservesDescLine1"].value;
		localStorage.OtherNonDistributableReservesDescLine2=document.forms["EquityForm"]["OtherNonDistributableReservesDescLine2"].value;
	  	localStorage.OtherNonDistributableReservesDescLine3=document.forms["EquityForm"]["OtherNonDistributableReservesDescLine3"].value;
      	       
                //Saving Distributable Reserves Descriptions
		localStorage.OtherDistributableReservesDescLine1=document.forms["EquityForm"]["OtherDistributableReservesDescLine1"].value;
		localStorage.OtherDistributableReservesDescLine2=document.forms["EquityForm"]["OtherDistributableReservesDescLine2"].value;
	  	localStorage.OtherDistributableReservesDescLine3=document.forms["EquityForm"]["OtherDistributableReservesDescLine3"].value;
      	
  	
	
		
		//Saving a Total of Non Current Assets for export to the Summary Balance Sheet 
		
		 localStorage.TotalEquity0 = document.forms["EquityForm"]["TotalEquityYear0"].value;
		 localStorage.TotalEquity1 = document.forms["EquityForm"]["TotalEquityYear1"].value;
		 localStorage.TotalEquity2 = document.forms["EquityForm"]["TotalEquityYear2"].value;
		 localStorage.TotalEquity3 = document.forms["EquityForm"]["TotalEquityYear3"].value;
		 
}		


//==============================================================================================================================================	
	
function SaveShareholderAnalysisForm()
{
 		   // Save Date and Username into Income Statement Tracker======================================
		   
		   var today = new Date();
           var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		   var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		   localStorage.ShareholderAnalysisTrackerDateSaved = date;
		   localStorage.ShareholderAnalysisTrackerSavedBy = localStorage.username;
           //============================================================================================
      
	   localStorage.ShareholderName1        =  document.ShareholderForm.ShareholderName1.value;
       localStorage.ShareholderDate1        =  document.ShareholderForm.ShareholderDate1.value;
       localStorage.ShareholderGender1      =  document.ShareholderForm.ShareholderGender1.value;
       localStorage.ShareholderAge1         =  document.ShareholderForm.ShareholderAge1.value;
       localStorage.ShareholderPercentageShares1     =  document.ShareholderForm.ShareholderPercentageShares1.value;
       localStorage.ShareholderITCRef1      =  document.ShareholderForm.ShareholderITCRef1.value;
       localStorage.ShareholderITCDate1     =  document.ShareholderForm.ShareholderITCDate1.value;
       localStorage.ShareholderPaidDebts1   =  document.ShareholderForm.ShareholderPaidDebts1.value;
       localStorage.ShareholderDefaults1    =  document.ShareholderForm.ShareholderDefaults1.value;
       localStorage.ShareholderJudgements1  =  document.ShareholderForm.ShareholderJudgements1.value;
       localStorage.ShareholderTraceAlerts1 =  document.ShareholderForm.ShareholderTraceAlerts1.value;
       localStorage.ShareholderBlacklisted1 =  document.ShareholderForm.ShareholderBlacklisted1.value;
       localStorage.ShareholderFraudAlert1  =  document.ShareholderForm.ShareholderFraudAlert1.value;
       localStorage.ShareholderTotalScore1  =  document.ShareholderForm.ShareholderTotalScore1.value;
       localStorage.ShareholderName2        =  document.ShareholderForm.ShareholderName2.value;
       localStorage.ShareholderDate2        =  document.ShareholderForm.ShareholderDate2.value;
       localStorage.ShareholderGender2      =  document.ShareholderForm.ShareholderGender2.value;
       localStorage.ShareholderAge2         =  document.ShareholderForm.ShareholderAge2.value;
       localStorage.ShareholderPercentageShares2     =  document.ShareholderForm.ShareholderPercentageShares2.value;
       localStorage.ShareholderITCRef2      =  document.ShareholderForm.ShareholderITCRef2.value;
       localStorage.ShareholderITCDate2     =  document.ShareholderForm.ShareholderITCDate2.value;
       localStorage.ShareholderPaidDebts2   =  document.ShareholderForm.ShareholderPaidDebts2.value;
       localStorage.ShareholderDefaults2    =  document.ShareholderForm.ShareholderDefaults2.value;
       localStorage.ShareholderJudgements2  =  document.ShareholderForm.ShareholderJudgements2.value;
       localStorage.ShareholderTraceAlerts2 =  document.ShareholderForm.ShareholderTraceAlerts2.value;
       localStorage.ShareholderBlacklisted2 =  document.ShareholderForm.ShareholderBlacklisted2.value;
       localStorage.ShareholderFraudAlert2  =  document.ShareholderForm.ShareholderFraudAlert2.value;
       localStorage.ShareholderTotalScore2  =  document.ShareholderForm.ShareholderTotalScore2.value;
       localStorage.ShareholderName3        =  document.ShareholderForm.ShareholderName3.value;
       localStorage.ShareholderDate3        =  document.ShareholderForm.ShareholderDate3.value;
       localStorage.ShareholderGender3      =  document.ShareholderForm.ShareholderGender3.value;
       localStorage.ShareholderAge3         =  document.ShareholderForm.ShareholderAge3.value;
       localStorage.ShareholderPercentageShares3     =  document.ShareholderForm.ShareholderPercentageShares3.value;
       localStorage.ShareholderITCRef3      =  document.ShareholderForm.ShareholderITCRef3.value;
       localStorage.ShareholderITCDate3     =  document.ShareholderForm.ShareholderITCDate3.value;
       localStorage.ShareholderPaidDebts3   =  document.ShareholderForm.ShareholderPaidDebts3.value;
       localStorage.ShareholderDefaults3    =  document.ShareholderForm.ShareholderDefaults3.value;
       localStorage.ShareholderJudgements3  =  document.ShareholderForm.ShareholderJudgements3.value;
       localStorage.ShareholderTraceAlerts3 =  document.ShareholderForm.ShareholderTraceAlerts3.value;
       localStorage.ShareholderBlacklisted3 =  document.ShareholderForm.ShareholderBlacklisted3.value;
       localStorage.ShareholderFraudAlert3  =  document.ShareholderForm.ShareholderFraudAlert3.value;
       localStorage.ShareholderTotalScore3  =  document.ShareholderForm.ShareholderTotalScore3.value;
       localStorage.ShareholderName4        =  document.ShareholderForm.ShareholderName4.value;
       localStorage.ShareholderDate4        =  document.ShareholderForm.ShareholderDate4.value;
       localStorage.ShareholderGender4      =  document.ShareholderForm.ShareholderGender4.value;
       localStorage.ShareholderAge4         =  document.ShareholderForm.ShareholderAge4.value;
       localStorage.ShareholderPercentageShares4     =  document.ShareholderForm.ShareholderPercentageShares4.value;
       localStorage.ShareholderITCRef4      =  document.ShareholderForm.ShareholderITCRef4.value;
       localStorage.ShareholderITCDate4     =  document.ShareholderForm.ShareholderITCDate4.value;
       localStorage.ShareholderPaidDebts4   =  document.ShareholderForm.ShareholderPaidDebts4.value;
       localStorage.ShareholderDefaults4    =  document.ShareholderForm.ShareholderDefaults4.value;
       localStorage.ShareholderJudgements4  =  document.ShareholderForm.ShareholderJudgements4.value;
       localStorage.ShareholderTraceAlerts4 =  document.ShareholderForm.ShareholderTraceAlerts4.value;
       localStorage.ShareholderBlacklisted4 =  document.ShareholderForm.ShareholderBlacklisted4.value;
       localStorage.ShareholderFraudAlert4  =  document.ShareholderForm.ShareholderFraudAlert4.value;
       localStorage.ShareholderTotalScore4  =  document.ShareholderForm.ShareholderTotalScore4.value;
       localStorage.ShareholderName5        =  document.ShareholderForm.ShareholderName5.value;
       localStorage.ShareholderDate5        =  document.ShareholderForm.ShareholderDate5.value;
       localStorage.ShareholderGender5      =  document.ShareholderForm.ShareholderGender5.value;
       localStorage.ShareholderAge5         =  document.ShareholderForm.ShareholderAge5.value;
       localStorage.ShareholderPercentageShares5     =  document.ShareholderForm.ShareholderPercentageShares5.value;
       localStorage.ShareholderITCRef5      =  document.ShareholderForm.ShareholderITCRef5.value;
       localStorage.ShareholderITCDate5     =  document.ShareholderForm.ShareholderITCDate5.value;
       localStorage.ShareholderPaidDebts5   =  document.ShareholderForm.ShareholderPaidDebts5.value;
       localStorage.ShareholderDefaults5    =  document.ShareholderForm.ShareholderDefaults5.value;
       localStorage.ShareholderJudgements5  =  document.ShareholderForm.ShareholderJudgements5.value;
       localStorage.ShareholderTraceAlerts5 =  document.ShareholderForm.ShareholderTraceAlerts5.value;
       localStorage.ShareholderBlacklisted5 =  document.ShareholderForm.ShareholderBlacklisted5.value;
       localStorage.ShareholderFraudAlert5  =  document.ShareholderForm.ShareholderFraudAlert5.value;
       localStorage.ShareholderTotalScore5  =  document.ShareholderForm.ShareholderTotalScore5.value;
       localStorage.ShareholderComment      =  document.ShareholderForm.ShareholderComment.value;
        
       alert ("Shareholder Analysis Data Successfully Saved to Local Machine, Press OK to save to database");
}

	  
function BenchmarkOverrideForm_SaveIndustryOverridesBenchmarks()
{
         localStorage.CurrentRatioOverrideBenchmarkType_             =  document.BenchmarksOverrideForm.CurrentRatioOverrideBenchmarkType_.value;
         localStorage.CurrentRatioOverrideBenchmarkValue_            =  document.BenchmarksOverrideForm.CurrentRatioOverrideBenchmarkValue_.value;
         localStorage.CurrentRatioOverrideComment_                   =  document.BenchmarksOverrideForm.CurrentRatioOverrideComment_.value;
         localStorage.CurrentRatioBenchmarkFirstApproval_            =  document.BenchmarksOverrideForm.CurrentRatioBenchmarkFirstApproval_.value;
         localStorage.CurrentRatioBenchmarkSecondApproval_           =  document.BenchmarksOverrideForm.CurrentRatioBenchmarkSecondApproval_.value;
         localStorage.DebtorDaysOverrideBenchmarkType_               =  document.BenchmarksOverrideForm.DebtorDaysOverrideBenchmarkType_.value;
         localStorage.DebtorDaysOverrideBenchmarkValue_              =  document.BenchmarksOverrideForm.DebtorDaysOverrideBenchmarkValue_.value;
         localStorage.DebtorDaysOverrideComment_                     =  document.BenchmarksOverrideForm.DebtorDaysOverrideComment_.value;
         localStorage.DebtorDaysBenchmarkFirstApproval_              =  document.BenchmarksOverrideForm.DebtorDaysBenchmarkFirstApproval_.value;
         localStorage.DebtorDaysBenchmarkSecondApproval_             =  document.BenchmarksOverrideForm.DebtorDaysBenchmarkSecondApproval_.value;
         localStorage.TurnoverToWCOverrideBenchmarkType_             =  document.BenchmarksOverrideForm.TurnoverToWCOverrideBenchmarkType_.value;
         localStorage.TurnoverToWCOverrideBenchmarkValue_            =  document.BenchmarksOverrideForm.TurnoverToWCOverrideBenchmarkValue_.value;
         localStorage.TurnoverToWCOverrideComment_                   =  document.BenchmarksOverrideForm.TurnoverToWCOverrideComment_.value;
         localStorage.TurnoverToWCBenchmarkFirstApproval_            =  document.BenchmarksOverrideForm.TurnoverToWCBenchmarkFirstApproval_.value;
         localStorage.TurnoverToWCBenchmarkSecondApproval_           =  document.BenchmarksOverrideForm.TurnoverToWCBenchmarkSecondApproval_.value;
         localStorage.TurnoverGrowthOverrideBenchmarkType_           =  document.BenchmarksOverrideForm.TurnoverGrowthOverrideBenchmarkType_.value;
         localStorage.TurnoverGrowthOverrideBenchmarkValue_          =  document.BenchmarksOverrideForm.TurnoverGrowthOverrideBenchmarkValue_.value;
         localStorage.TurnoverGrowthOverrideComment_                 =  document.BenchmarksOverrideForm.TurnoverGrowthOverrideComment_.value;
         localStorage.TurnoverGrowthBenchmarkFirstApproval_          =  document.BenchmarksOverrideForm.TurnoverGrowthBenchmarkFirstApproval_.value;
         localStorage.TurnoverGrowthBenchmarkSecondApproval_         =  document.BenchmarksOverrideForm.TurnoverGrowthBenchmarkSecondApproval_.value;
         localStorage.GrossProfitMarginOverrideBenchmarkType_        =  document.BenchmarksOverrideForm.GrossProfitMarginOverrideBenchmarkType_.value;
         localStorage.GrossProfitMarginOverrideBenchmarkValue_       =  document.BenchmarksOverrideForm.GrossProfitMarginOverrideBenchmarkValue_.value;
         localStorage.GrossProfitMarginOverrideComment_              =  document.BenchmarksOverrideForm.GrossProfitMarginOverrideComment_.value;
         localStorage.GrossProfitMarginBenchmarkFirstApproval_       =  document.BenchmarksOverrideForm.GrossProfitMarginBenchmarkFirstApproval_.value;
         localStorage.GrossProfitMarginBenchmarkSecondApproval_      =  document.BenchmarksOverrideForm.GrossProfitMarginBenchmarkSecondApproval_.value;
         localStorage.OperatingProfitMarginOverrideBenchmarkType_    =  document.BenchmarksOverrideForm.OperatingProfitMarginOverrideBenchmarkType_.value;
         localStorage.OperatingProfitMarginOverrideBenchmarkValue_   =  document.BenchmarksOverrideForm.OperatingProfitMarginOverrideBenchmarkValue_.value;
         localStorage.OperatingProfitMarginOverrideComment_          =  document.BenchmarksOverrideForm.OperatingProfitMarginOverrideComment_.value;
         localStorage.OperatingProfitMarginBenchmarkFirstApproval_   =  document.BenchmarksOverrideForm.OperatingProfitMarginBenchmarkFirstApproval_.value;
         localStorage.OperatingProfitMarginBenchmarkSecondApproval_  =  document.BenchmarksOverrideForm.OperatingProfitMarginBenchmarkSecondApproval_.value;
         localStorage.ROAOverrideBenchmarkType_                      =  document.BenchmarksOverrideForm.ROAOverrideBenchmarkType_.value;
         localStorage.ROAOverrideBenchmarkValue_                     =  document.BenchmarksOverrideForm.ROAOverrideBenchmarkValue_.value;
         localStorage.ROAOverrideComment_                            =  document.BenchmarksOverrideForm.ROAOverrideComment_.value;
         localStorage.ROABenchmarkFirstApproval_                     =  document.BenchmarksOverrideForm.ROABenchmarkFirstApproval_.value;
         localStorage.ROABenchmarkSecondApproval_                    =  document.BenchmarksOverrideForm.ROABenchmarkSecondApproval_.value;
         localStorage.ROIOverrideBenchmarkType_                      =  document.BenchmarksOverrideForm.ROIOverrideBenchmarkType_.value;
         localStorage.ROIOverrideBenchmarkValue_                     =  document.BenchmarksOverrideForm.ROIOverrideBenchmarkValue_.value;
         localStorage.ROIOverrideComment_                            =  document.BenchmarksOverrideForm.ROIOverrideComment_.value;
         localStorage.ROIBenchmarkFirstApproval_                     =  document.BenchmarksOverrideForm.ROIBenchmarkFirstApproval_.value;
         localStorage.ROIBenchmarkSecondApproval_                    =  document.BenchmarksOverrideForm.ROIBenchmarkSecondApproval_.value;
         localStorage.LongtermDebtToEquityOverrideBenchmarkType_     =  document.BenchmarksOverrideForm.LongtermDebtToEquityOverrideBenchmarkType_.value;
         localStorage.LongtermDebtToEquityOverrideBenchmarkValue_    =  document.BenchmarksOverrideForm.LongtermDebtToEquityOverrideBenchmarkValue_.value;
         localStorage.LongtermDebtToEquityOverrideComment_           =  document.BenchmarksOverrideForm.LongtermDebtToEquityOverrideComment_.value;
         localStorage.LongtermDebtToEquityBenchmarkFirstApproval_    =  document.BenchmarksOverrideForm.LongtermDebtToEquityBenchmarkFirstApproval_.value;
         localStorage.LongtermDebtToEquityBenchmarkSecondApproval_   =  document.BenchmarksOverrideForm.LongtermDebtToEquityBenchmarkSecondApproval_.value;
         localStorage.DebtToTangibleNetWorthOverrideBenchmarkType_   =  document.BenchmarksOverrideForm.DebtToTangibleNetWorthOverrideBenchmarkType_.value;
         localStorage.DebtToTangibleNetWorthOverrideBenchmarkValue_  =  document.BenchmarksOverrideForm.DebtToTangibleNetWorthOverrideBenchmarkValue_.value;
         localStorage.DebtToTangibleNetWorthOverrideComment_         =  document.BenchmarksOverrideForm.DebtToTangibleNetWorthOverrideComment_.value;
         localStorage.DebtToTangibleNetWorthBenchmarkFirstApproval_  =  document.BenchmarksOverrideForm.DebtToTangibleNetWorthBenchmarkFirstApproval_.value;
         localStorage.DebtToTangibleNetWorthBenchmarkSecondApproval_ =  document.BenchmarksOverrideForm.DebtToTangibleNetWorthBenchmarkSecondApproval_.value;
         localStorage.EquityToTotalAssetsOverrideBenchmarkType_      =  document.BenchmarksOverrideForm.EquityToTotalAssetsOverrideBenchmarkType_.value;
         localStorage.EquityToTotalAssetsOverrideBenchmarkValue_     =  document.BenchmarksOverrideForm.EquityToTotalAssetsOverrideBenchmarkValue_.value;
         localStorage.EquityToTotalAssetsOverrideComment_            =  document.BenchmarksOverrideForm.EquityToTotalAssetsOverrideComment_.value;
         localStorage.EquityToTotalAssetsBenchmarkFirstApproval_     =  document.BenchmarksOverrideForm.EquityToTotalAssetsBenchmarkFirstApproval_.value;
         localStorage.EquityToTotalAssetsBenchmarkSecondApproval_    =  document.BenchmarksOverrideForm.EquityToTotalAssetsBenchmarkSecondApproval_.value;
         localStorage.InterestCoverOverrideBenchmarkType_            =  document.BenchmarksOverrideForm.InterestCoverOverrideBenchmarkType_.value;
         localStorage.InterestCoverOverrideBenchmarkValue_           =  document.BenchmarksOverrideForm.InterestCoverOverrideBenchmarkValue_.value;
         localStorage.InterestCoverOverrideComment_                  =  document.BenchmarksOverrideForm.InterestCoverOverrideComment_.value;
         localStorage.InterestCoverBenchmarkFirstApproval_           =  document.BenchmarksOverrideForm.InterestCoverBenchmarkFirstApproval_.value;
         localStorage.InterestCoverBenchmarkSecondApproval_          =  document.BenchmarksOverrideForm.InterestCoverBenchmarkSecondApproval_.value;
         localStorage.EBITDAToDebtOverrideBenchmarkType_             =  document.BenchmarksOverrideForm.EBITDAToDebtOverrideBenchmarkType_.value;
         localStorage.EBITDAToDebtOverrideBenchmarkValue_            =  document.BenchmarksOverrideForm.EBITDAToDebtOverrideBenchmarkValue_.value;
         localStorage.EBITDAToDebtOverrideComment_                   =  document.BenchmarksOverrideForm.EBITDAToDebtOverrideComment_.value;
         localStorage.EBITDAToDebtBenchmarkFirstApproval_            =  document.BenchmarksOverrideForm.EBITDAToDebtBenchmarkFirstApproval_.value;
         localStorage.EBITDAToDebtBenchmarkSecondApproval_           =  document.BenchmarksOverrideForm.EBITDAToDebtBenchmarkSecondApproval_.value;
         localStorage.BenchmarkOverrideFirstReviewerComment_         =  document.BenchmarksOverrideForm.BenchmarkOverrideFirstReviewerComment_.value;
         localStorage.BenchmarkOverrideSecondReviewerComment_        =  document.BenchmarksOverrideForm.BenchmarkOverrideSecondReviewerComment_.value;
	  
	     alert ("Industry benchmarks overrides successfully saved into local storage - now updating database");
}


function IndustryBenchmarksOverride_SaveData()
{
 		   // Save Date and Username into Income Statement Tracker======================================
		   
		   var today = new Date();
           var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
		   var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

		   
		   localStorage.IndustryBenchmarksOverridesTrackerDateSaved = date;
		   localStorage.IndustryBenchmarksOverridesTrackerSavedBy = localStorage.username;
           //============================================================================================
          
		 localStorage.CurrentRatioBenchmarkType                     =  document.BenchmarkOverrideForm.CurrentRatioBenchmarkType.value;
         localStorage.CurrentRatioGlobalAverage                     =  document.BenchmarkOverrideForm.CurrentRatioGlobalAverage.value;
         localStorage.CurrentRatioBenchmark_Trade                   =  document.BenchmarkOverrideForm.CurrentRatioBenchmark_Trade.value;
         localStorage.CurrentRatioBenchmark_Finance                 =  document.BenchmarkOverrideForm.CurrentRatioBenchmark_Finance.value;
         localStorage.CurrentRatioBenchmark_RealEstate              =  document.BenchmarkOverrideForm.CurrentRatioBenchmark_RealEstate.value;
         localStorage.CurrentRatioBenchmark_Manufacturing           =  document.BenchmarkOverrideForm.CurrentRatioBenchmark_Manufacturing.value;
         localStorage.CurrentRatioBenchmark_Construction            =  document.BenchmarkOverrideForm.CurrentRatioBenchmark_Construction.value;
         localStorage.CurrentRatioBenchmark_Agriculture             =  document.BenchmarkOverrideForm.CurrentRatioBenchmark_Agriculture.value;
         localStorage.CurrentRatioBenchmark_Parastatals             =  document.BenchmarkOverrideForm.CurrentRatioBenchmark_Parastatals.value;
         localStorage.CurrentRatioBenchmark_Transport               =  document.BenchmarkOverrideForm.CurrentRatioBenchmark_Transport.value;
         localStorage.CurrentRatioBenchmark_Mining                  =  document.BenchmarkOverrideForm.CurrentRatioBenchmark_Mining.value;
         localStorage.CurrentRatioBenchmark_DateUpdated             =  document.BenchmarkOverrideForm.CurrentRatioBenchmark_DateUpdated.value;
         localStorage.CurrentRatioBenchmarkComment                  =  document.BenchmarkOverrideForm.CurrentRatioBenchmarkComment.value;
         localStorage.QuickRatioBenchmarkType                       =  document.BenchmarkOverrideForm.QuickRatioBenchmarkType.value;
         localStorage.QuickRatioGlobalAverage                       =  document.BenchmarkOverrideForm.QuickRatioGlobalAverage.value;
         localStorage.QuickRatioBenchmark_Trade                     =  document.BenchmarkOverrideForm.QuickRatioBenchmark_Trade.value;
         localStorage.QuickRatioBenchmark_Finance                   =  document.BenchmarkOverrideForm.QuickRatioBenchmark_Finance.value;
         localStorage.QuickRatioBenchmark_RealEstate                =  document.BenchmarkOverrideForm.QuickRatioBenchmark_RealEstate.value;
         localStorage.QuickRatioBenchmark_Manufacturing             =  document.BenchmarkOverrideForm.QuickRatioBenchmark_Manufacturing.value;
         localStorage.QuickRatioBenchmark_Construction              =  document.BenchmarkOverrideForm.QuickRatioBenchmark_Construction.value;
         localStorage.QuickRatioBenchmark_Agriculture               =  document.BenchmarkOverrideForm.QuickRatioBenchmark_Agriculture.value;
         localStorage.QuickRatioBenchmark_Parastatals               =  document.BenchmarkOverrideForm.QuickRatioBenchmark_Parastatals.value;
         localStorage.QuickRatioBenchmark_Transport                 =  document.BenchmarkOverrideForm.QuickRatioBenchmark_Transport.value;
         localStorage.QuickRatioBenchmark_Mining                    =  document.BenchmarkOverrideForm.QuickRatioBenchmark_Mining.value;
         localStorage.QuickRatioBenchmark_DateUpdated               =  document.BenchmarkOverrideForm.QuickRatioBenchmark_DateUpdated.value;
         localStorage.QuickRatioBenchmarkComment                    =  document.BenchmarkOverrideForm.QuickRatioBenchmarkComment.value;
         localStorage.DebtorDaysBenchmarkType                       =  document.BenchmarkOverrideForm.DebtorDaysBenchmarkType.value;
         localStorage.DebtorDaysGlobalAverage                       =  document.BenchmarkOverrideForm.DebtorDaysGlobalAverage.value;
         localStorage.DebtorDaysBenchmark_Trade                     =  document.BenchmarkOverrideForm.DebtorDaysBenchmark_Trade.value;
         localStorage.DebtorDaysBenchmark_Finance                   =  document.BenchmarkOverrideForm.DebtorDaysBenchmark_Finance.value;
         localStorage.DebtorDaysBenchmark_RealEstate                =  document.BenchmarkOverrideForm.DebtorDaysBenchmark_RealEstate.value;
         localStorage.DebtorDaysBenchmark_Manufacturing             =  document.BenchmarkOverrideForm.DebtorDaysBenchmark_Manufacturing.value;
         localStorage.DebtorDaysBenchmark_Construction              =  document.BenchmarkOverrideForm.DebtorDaysBenchmark_Construction.value;
         localStorage.DebtorDaysBenchmark_Agriculture               =  document.BenchmarkOverrideForm.DebtorDaysBenchmark_Agriculture.value;
         localStorage.DebtorDaysBenchmark_Parastatals               =  document.BenchmarkOverrideForm.DebtorDaysBenchmark_Parastatals.value;
         localStorage.DebtorDaysBenchmark_Transport                 =  document.BenchmarkOverrideForm.DebtorDaysBenchmark_Transport.value;
         localStorage.DebtorDaysBenchmark_Mining                    =  document.BenchmarkOverrideForm.DebtorDaysBenchmark_Mining.value;
         localStorage.DebtorDaysBenchmark_DateUpdated               =  document.BenchmarkOverrideForm.DebtorDaysBenchmark_DateUpdated.value;
         localStorage.CurrentRatioBenchmarkComment                  =  document.BenchmarkOverrideForm.CurrentRatioBenchmarkComment.value;
         localStorage.CreditorDaysBenchmarkType                     =  document.BenchmarkOverrideForm.CreditorDaysBenchmarkType.value;
         localStorage.CreditorDaysGlobalAverage                     =  document.BenchmarkOverrideForm.CreditorDaysGlobalAverage.value;
         localStorage.CreditorDaysBenchmark_Trade                   =  document.BenchmarkOverrideForm.CreditorDaysBenchmark_Trade.value;
         localStorage.CreditorDaysBenchmark_Finance                 =  document.BenchmarkOverrideForm.CreditorDaysBenchmark_Finance.value;
         localStorage.CreditorDaysBenchmark_RealEstate              =  document.BenchmarkOverrideForm.CreditorDaysBenchmark_RealEstate.value;
         localStorage.CreditorDaysBenchmark_Manufacturing           =  document.BenchmarkOverrideForm.CreditorDaysBenchmark_Manufacturing.value;
         localStorage.CreditorDaysBenchmark_Construction            =  document.BenchmarkOverrideForm.CreditorDaysBenchmark_Construction.value;
         localStorage.CreditorDaysBenchmark_Agriculture             =  document.BenchmarkOverrideForm.CreditorDaysBenchmark_Agriculture.value;
         localStorage.CreditorDaysBenchmark_Parastatals             =  document.BenchmarkOverrideForm.CreditorDaysBenchmark_Parastatals.value;
         localStorage.CreditorDaysBenchmark_Transport               =  document.BenchmarkOverrideForm.CreditorDaysBenchmark_Transport.value;
         localStorage.CreditorDaysBenchmark_Mining                  =  document.BenchmarkOverrideForm.CreditorDaysBenchmark_Mining.value;
         localStorage.CreditorDaysBenchmark_DateUpdated             =  document.BenchmarkOverrideForm.CreditorDaysBenchmark_DateUpdated.value;
         localStorage.CreditorDaysBenchmarkComment                  =  document.BenchmarkOverrideForm.CreditorDaysBenchmarkComment.value;
         localStorage.TurnoverToWCBenchmarkType                     =  document.BenchmarkOverrideForm.TurnoverToWCBenchmarkType.value;
         localStorage.TurnoverToWCGlobalAverage                     =  document.BenchmarkOverrideForm.TurnoverToWCGlobalAverage.value;
         localStorage.TurnoverToWCBenchmark_Trade                   =  document.BenchmarkOverrideForm.TurnoverToWCBenchmark_Trade.value;
         localStorage.TurnoverToWCBenchmark_Finance                 =  document.BenchmarkOverrideForm.TurnoverToWCBenchmark_Finance.value;
         localStorage.TurnoverToWCBenchmark_RealEstate              =  document.BenchmarkOverrideForm.TurnoverToWCBenchmark_RealEstate.value;
         localStorage.TurnoverToWCBenchmark_Manufacturing           =  document.BenchmarkOverrideForm.TurnoverToWCBenchmark_Manufacturing.value;
         localStorage.TurnoverToWCBenchmark_Construction            =  document.BenchmarkOverrideForm.TurnoverToWCBenchmark_Construction.value;
         localStorage.TurnoverToWCBenchmark_Agriculture             =  document.BenchmarkOverrideForm.TurnoverToWCBenchmark_Agriculture.value;
         localStorage.TurnoverToWCBenchmark_Parastatals              =  document.BenchmarkOverrideForm.TurnoverToWCBenchmark_Parastatals.value;
         localStorage.TurnoverToWCBenchmark_Transport               =  document.BenchmarkOverrideForm.TurnoverToWCBenchmark_Transport.value;
         localStorage.TurnoverToWCBenchmark_Mining                  =  document.BenchmarkOverrideForm.TurnoverToWCBenchmark_Mining.value;
         localStorage.TurnoverToWCBenchmark_DateUpdated             =  document.BenchmarkOverrideForm.TurnoverToWCBenchmark_DateUpdated.value;
         localStorage.TurnoverToWCBenchmarkComment                  =  document.BenchmarkOverrideForm.TurnoverToWCBenchmarkComment.value;
         localStorage.TurnoverGrowthBenchmarkType                   =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmarkType.value;
         localStorage.TurnoverGrowthGlobalAverage                   =  document.BenchmarkOverrideForm.TurnoverGrowthGlobalAverage.value;
         localStorage.TurnoverGrowthBenchmark_Trade                 =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmark_Trade.value;
         localStorage.TurnoverGrowthBenchmark_Finance               =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmark_Finance.value;
         localStorage.TurnoverGrowthBenchmark_RealEstate            =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmark_RealEstate.value;
         localStorage.TurnoverGrowthBenchmark_Manufacturing         =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmark_Manufacturing.value;
         localStorage.TurnoverGrowthBenchmark_Construction          =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmark_Construction.value;
         localStorage.TurnoverGrowthBenchmark_Agriculture           =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmark_Agriculture.value;
         localStorage.TurnoverGrowthBenchmark_Parastatals           =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmark_Parastatals.value;
         localStorage.TurnoverGrowthBenchmark_Transport             =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmark_Transport.value;
         localStorage.TurnoverGrowthBenchmark_Mining                =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmark_Mining.value;
         localStorage.TurnoverGrowthBenchmark_DateUpdated           =  document.BenchmarkOverrideForm.TurnoverGrowthBenchmark_DateUpdated.value;
         localStorage.CurrentRatioBenchmarkComment                  =  document.BenchmarkOverrideForm.CurrentRatioBenchmarkComment.value;
         localStorage.GrossProfitMarginBenchmarkType                =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmarkType.value;
         localStorage.GrossProfitMarginGlobalAverage                =  document.BenchmarkOverrideForm.GrossProfitMarginGlobalAverage.value;
         localStorage.GrossProfitMarginBenchmark_Trade              =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmark_Trade.value;
         localStorage.GrossProfitMarginBenchmark_Finance            =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmark_Finance.value;
         localStorage.GrossProfitMarginBenchmark_RealEstate         =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmark_RealEstate.value;
         localStorage.GrossProfitMarginBenchmark_Manufacturing      =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmark_Manufacturing.value;
         localStorage.GrossProfitMarginBenchmark_Construction       =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmark_Construction.value;
         localStorage.GrossProfitMarginBenchmark_Agriculture        =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmark_Agriculture.value;
         localStorage.GrossProfitMarginBenchmark_Parastatals        =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmark_Parastatals.value;
         localStorage.GrossProfitMarginBenchmark_Transport          =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmark_Transport.value;
         localStorage.GrossProfitMarginBenchmark_Mining             =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmark_Mining.value;
         localStorage.GrossProfitMarginBenchmark_DateUpdated        =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmark_DateUpdated.value;
         localStorage.GrossProfitMarginBenchmarkComment             =  document.BenchmarkOverrideForm.GrossProfitMarginBenchmarkComment.value;
         localStorage.OperatingProfitMarginBenchmarkType            =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmarkType.value;
         localStorage.OperatingProfitMarginGlobalAverage            =  document.BenchmarkOverrideForm.OperatingProfitMarginGlobalAverage.value;
         localStorage.OperatingProfitMarginBenchmark_Trade          =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmark_Trade.value;
         localStorage.OperatingProfitMarginBenchmark_Finance        =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmark_Finance.value;
         localStorage.OperatingProfitMarginBenchmark_RealEstate     =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmark_RealEstate.value;
         localStorage.OperatingProfitMarginBenchmark_Manufacturing  =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmark_Manufacturing.value;
         localStorage.OperatingProfitMarginBenchmark_Construction   =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmark_Construction.value;
         localStorage.OperatingProfitMarginBenchmark_Agriculture    =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmark_Agriculture.value;
         localStorage.OperatingProfitMarginBenchmark_Parastatals    =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmark_Parastatals.value;
         localStorage.OperatingProfitMarginBenchmark_Transport      =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmark_Transport.value;
         localStorage.OperatingProfitMarginBenchmark_Mining         =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmark_Mining.value;
         localStorage.OperatingProfitMarginBenchmark_DateUpdated    =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmark_DateUpdated.value;
         localStorage.OperatingProfitMarginBenchmarkComment         =  document.BenchmarkOverrideForm.OperatingProfitMarginBenchmarkComment.value;
         localStorage.NetProfitMarginBenchmarkType                  =  document.BenchmarkOverrideForm.NetProfitMarginBenchmarkType.value;
         localStorage.NetProfitMarginGlobalAverage                  =  document.BenchmarkOverrideForm.NetProfitMarginGlobalAverage.value;
         localStorage.NetProfitMarginBenchmark_Trade                =  document.BenchmarkOverrideForm.NetProfitMarginBenchmark_Trade.value;
         localStorage.NetProfitMarginBenchmark_Finance              =  document.BenchmarkOverrideForm.NetProfitMarginBenchmark_Finance.value;
         localStorage.NetProfitMarginBenchmark_RealEstate           =  document.BenchmarkOverrideForm.NetProfitMarginBenchmark_RealEstate.value;
         localStorage.NetProfitMarginBenchmark_Manufacturing        =  document.BenchmarkOverrideForm.NetProfitMarginBenchmark_Manufacturing.value;
         localStorage.NetProfitMarginBenchmark_Construction         =  document.BenchmarkOverrideForm.NetProfitMarginBenchmark_Construction.value;
         localStorage.NetProfitMarginBenchmark_Agriculture          =  document.BenchmarkOverrideForm.NetProfitMarginBenchmark_Agriculture.value;
         localStorage.NetProfitMarginBenchmark_Parastatals          =  document.BenchmarkOverrideForm.NetProfitMarginBenchmark_Parastatals.value;
         localStorage.NetProfitMarginBenchmark_Transport            =  document.BenchmarkOverrideForm.NetProfitMarginBenchmark_Transport.value;
         localStorage.NetProfitMarginBenchmark_Mining               =  document.BenchmarkOverrideForm.NetProfitMarginBenchmark_Mining.value;
         localStorage.NetProfitMarginBenchmark_DateUpdated          =  document.BenchmarkOverrideForm.NetProfitMarginBenchmark_DateUpdated.value;
         localStorage.NetProfitMarginBenchmarkComment               =  document.BenchmarkOverrideForm.NetProfitMarginBenchmarkComment.value;
         localStorage.ROEBenchmarkType                              =  document.BenchmarkOverrideForm.ROEBenchmarkType.value;
         localStorage.ROEGlobalAverage                              =  document.BenchmarkOverrideForm.ROEGlobalAverage.value;
         localStorage.ROEBenchmark_Trade                            =  document.BenchmarkOverrideForm.ROEBenchmark_Trade.value;
         localStorage.ROEBenchmark_Finance                          =  document.BenchmarkOverrideForm.ROEBenchmark_Finance.value;
         localStorage.ROEBenchmark_RealEstate                       =  document.BenchmarkOverrideForm.ROEBenchmark_RealEstate.value;
         localStorage.ROEBenchmark_Manufacturing                    =  document.BenchmarkOverrideForm.ROEBenchmark_Manufacturing.value;
         localStorage.ROEBenchmark_Construction                     =  document.BenchmarkOverrideForm.ROEBenchmark_Construction.value;
         localStorage.ROEBenchmark_Agriculture                      =  document.BenchmarkOverrideForm.ROEBenchmark_Agriculture.value;
         localStorage.ROEBenchmark_Parastatals                       =  document.BenchmarkOverrideForm.ROEBenchmark_Parastatals.value;
         localStorage.ROEBenchmark_Transport                        =  document.BenchmarkOverrideForm.ROEBenchmark_Transport.value;
         localStorage.ROEBenchmark_Mining                           =  document.BenchmarkOverrideForm.ROEBenchmark_Mining.value;
         localStorage.ROEBenchmark_DateUpdated                      =  document.BenchmarkOverrideForm.ROEBenchmark_DateUpdated.value;
         localStorage.CurrentRatioBenchmarkComment                  =  document.BenchmarkOverrideForm.CurrentRatioBenchmarkComment.value;
         localStorage.ROABenchmarkType                              =  document.BenchmarkOverrideForm.ROABenchmarkType.value;
         localStorage.ROAGlobalAverage                              =  document.BenchmarkOverrideForm.ROAGlobalAverage.value;
         localStorage.ROABenchmark_Trade                            =  document.BenchmarkOverrideForm.ROABenchmark_Trade.value;
         localStorage.ROABenchmark_Finance                          =  document.BenchmarkOverrideForm.ROABenchmark_Finance.value;
         localStorage.ROABenchmark_RealEstate                       =  document.BenchmarkOverrideForm.ROABenchmark_RealEstate.value;
         localStorage.ROABenchmark_Manufacturing                    =  document.BenchmarkOverrideForm.ROABenchmark_Manufacturing.value;
         localStorage.ROABenchmark_Construction                     =  document.BenchmarkOverrideForm.ROABenchmark_Construction.value;
         localStorage.ROABenchmark_Agriculture                      =  document.BenchmarkOverrideForm.ROABenchmark_Agriculture.value;
         localStorage.ROABenchmark_Parastatals                       =  document.BenchmarkOverrideForm.ROABenchmark_Parastatals.value;
         localStorage.ROABenchmark_Transport                        =  document.BenchmarkOverrideForm.ROABenchmark_Transport.value;
         localStorage.ROABenchmark_Mining                           =  document.BenchmarkOverrideForm.ROABenchmark_Mining.value;
         localStorage.ROABenchmark_DateUpdated                      =  document.BenchmarkOverrideForm.ROABenchmark_DateUpdated.value;
         localStorage.ROABenchmarkComment                           =  document.BenchmarkOverrideForm.ROABenchmarkComment.value;
         localStorage.ROIBenchmarkType                              =  document.BenchmarkOverrideForm.ROIBenchmarkType.value;
         localStorage.ROIGlobalAverage                              =  document.BenchmarkOverrideForm.ROIGlobalAverage.value;
         localStorage.ROIBenchmark_Trade                            =  document.BenchmarkOverrideForm.ROIBenchmark_Trade.value;
         localStorage.ROIBenchmark_Finance                          =  document.BenchmarkOverrideForm.ROIBenchmark_Finance.value;
         localStorage.ROIBenchmark_RealEstate                       =  document.BenchmarkOverrideForm.ROIBenchmark_RealEstate.value;
         localStorage.ROIBenchmark_Manufacturing                    =  document.BenchmarkOverrideForm.ROIBenchmark_Manufacturing.value;
         localStorage.ROIBenchmark_Construction                     =  document.BenchmarkOverrideForm.ROIBenchmark_Construction.value;
         localStorage.ROIBenchmark_Agriculture                      =  document.BenchmarkOverrideForm.ROIBenchmark_Agriculture.value;
         localStorage.ROIBenchmark_Parastatals                      =  document.BenchmarkOverrideForm.ROIBenchmark_Parastatals.value;
         localStorage.ROIBenchmark_Transport                        =  document.BenchmarkOverrideForm.ROIBenchmark_Transport.value;
         localStorage.ROIBenchmark_Mining                           =  document.BenchmarkOverrideForm.ROIBenchmark_Mining.value;
         localStorage.ROIBenchmark_DateUpdated                      =  document.BenchmarkOverrideForm.ROIBenchmark_DateUpdated.value;
         localStorage.ROIBenchmarkComment                           =  document.BenchmarkOverrideForm.ROIBenchmarkComment.value;
         localStorage.GearingRatioBenchmarkType                     =  document.BenchmarkOverrideForm.GearingRatioBenchmarkType.value;
         localStorage.GearingRatioGlobalAverage                     =  document.BenchmarkOverrideForm.GearingRatioGlobalAverage.value;
         localStorage.GearingRatioBenchmark_Trade                   =  document.BenchmarkOverrideForm.GearingRatioBenchmark_Trade.value;
         localStorage.GearingRatioBenchmark_Finance                 =  document.BenchmarkOverrideForm.GearingRatioBenchmark_Finance.value;
         localStorage.GearingRatioBenchmark_RealEstate              =  document.BenchmarkOverrideForm.GearingRatioBenchmark_RealEstate.value;
         localStorage.GearingRatioBenchmark_Manufacturing           =  document.BenchmarkOverrideForm.GearingRatioBenchmark_Manufacturing.value;
         localStorage.GearingRatioBenchmark_Construction            =  document.BenchmarkOverrideForm.GearingRatioBenchmark_Construction.value;
         localStorage.GearingRatioBenchmark_Agriculture             =  document.BenchmarkOverrideForm.GearingRatioBenchmark_Agriculture.value;
         localStorage.GearingRatioBenchmark_Parastatals             =  document.BenchmarkOverrideForm.GearingRatioBenchmark_Parastatals.value;
         localStorage.GearingRatioBenchmark_Transport               =  document.BenchmarkOverrideForm.GearingRatioBenchmark_Transport.value;
         localStorage.GearingRatioBenchmark_Mining                  =  document.BenchmarkOverrideForm.GearingRatioBenchmark_Mining.value;
         localStorage.GearingRatioBenchmark_DateUpdated             =  document.BenchmarkOverrideForm.GearingRatioBenchmark_DateUpdated.value;
         localStorage.GearingRatioBenchmarkComment                  =  document.BenchmarkOverrideForm.GearingRatioBenchmarkComment.value;
         localStorage.LongtermDebtToEquityBenchmarkType             =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmarkType.value;
         localStorage.LongtermDebtToEquityGlobalAverage             =  document.BenchmarkOverrideForm.LongtermDebtToEquityGlobalAverage.value;
         localStorage.LongtermDebtToEquityBenchmark_Trade           =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmark_Trade.value;
         localStorage.LongtermDebtToEquityBenchmark_Finance         =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmark_Finance.value;
         localStorage.LongtermDebtToEquityBenchmark_RealEstate      =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmark_RealEstate.value;
         localStorage.LongtermDebtToEquityBenchmark_Manufacturing   =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmark_Manufacturing.value;
         localStorage.LongtermDebtToEquityBenchmark_Construction    =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmark_Construction.value;
         localStorage.LongtermDebtToEquityBenchmark_Agriculture     =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmark_Agriculture.value;
         localStorage.LongtermDebtToEquityBenchmark_Parastatals     =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmark_Parastatals.value;
         localStorage.LongtermDebtToEquityBenchmark_Transport       =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmark_Transport.value;
         localStorage.LongtermDebtToEquityBenchmark_Mining          =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmark_Mining.value;
         localStorage.LongtermDebtToEquityBenchmark_DateUpdated     =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmark_DateUpdated.value;
         localStorage.LongtermDebtToEquityBenchmarkComment          =  document.BenchmarkOverrideForm.LongtermDebtToEquityBenchmarkComment.value;
         localStorage.DebtToTangibleNetWorthBenchmarkType           =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmarkType.value;
         localStorage.DebtToTangibleNetWorthGlobalAverage           =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthGlobalAverage.value;
         localStorage.DebtToTangibleNetWorthBenchmark_Trade         =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmark_Trade.value;
         localStorage.DebtToTangibleNetWorthBenchmark_Finance       =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmark_Finance.value;
         localStorage.DebtToTangibleNetWorthBenchmark_RealEstate    =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmark_RealEstate.value;
         localStorage.DebtToTangibleNetWorthBenchmark_Manufacturing =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmark_Manufacturing.value;
         localStorage.DebtToTangibleNetWorthBenchmark_Construction  =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmark_Construction.value;
         localStorage.DebtToTangibleNetWorthBenchmark_Agriculture   =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmark_Agriculture.value;
         localStorage.DebtToTangibleNetWorthBenchmark_Parastatals   =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmark_Parastatals.value;
         localStorage.DebtToTangibleNetWorthBenchmark_Transport     =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmark_Transport.value;
         localStorage.DebtToTangibleNetWorthBenchmark_Mining        =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmark_Mining.value;
         localStorage.DebtToTangibleNetWorthBenchmark_DateUpdated   =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmark_DateUpdated.value;
         localStorage.DebtToTangibleNetWorthBenchmarkComment        =  document.BenchmarkOverrideForm.DebtToTangibleNetWorthBenchmarkComment.value;
         localStorage.EquityToTotalAssetsBenchmarkType              =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmarkType.value;
         localStorage.EquityToTotalAssetsGlobalAverage              =  document.BenchmarkOverrideForm.EquityToTotalAssetsGlobalAverage.value;
         localStorage.EquityToTotalAssetsBenchmark_Trade            =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmark_Trade.value;
         localStorage.EquityToTotalAssetsBenchmark_Finance          =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmark_Finance.value;
         localStorage.EquityToTotalAssetsBenchmark_RealEstate       =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmark_RealEstate.value;
         localStorage.EquityToTotalAssetsBenchmark_Manufacturing    =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmark_Manufacturing.value;
         localStorage.EquityToTotalAssetsBenchmark_Construction     =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmark_Construction.value;
         localStorage.EquityToTotalAssetsBenchmark_Agriculture      =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmark_Agriculture.value;
         localStorage.EquityToTotalAssetsBenchmark_Parastatals      =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmark_Parastatals.value;
         localStorage.EquityToTotalAssetsBenchmark_Transport        =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmark_Transport.value;
         localStorage.EquityToTotalAssetsBenchmark_Mining           =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmark_Mining.value;
         localStorage.EquityToTotalAssetsBenchmark_DateUpdated      =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmark_DateUpdated.value;
         localStorage.EquityToTotalAssetsBenchmarkComment           =  document.BenchmarkOverrideForm.EquityToTotalAssetsBenchmarkComment.value;
         localStorage.SolvencyBenchmarkType                         =  document.BenchmarkOverrideForm.SolvencyBenchmarkType.value;
         localStorage.SolvencyGlobalAverage                         =  document.BenchmarkOverrideForm.SolvencyGlobalAverage.value;
         localStorage.SolvencyBenchmark_Trade                       =  document.BenchmarkOverrideForm.SolvencyBenchmark_Trade.value;
         localStorage.SolvencyBenchmark_Finance                     =  document.BenchmarkOverrideForm.SolvencyBenchmark_Finance.value;
         localStorage.SolvencyBenchmark_RealEstate                  =  document.BenchmarkOverrideForm.SolvencyBenchmark_RealEstate.value;
         localStorage.SolvencyBenchmark_Manufacturing               =  document.BenchmarkOverrideForm.SolvencyBenchmark_Manufacturing.value;
         localStorage.SolvencyBenchmark_Construction                =  document.BenchmarkOverrideForm.SolvencyBenchmark_Construction.value;
         localStorage.SolvencyBenchmark_Agriculture                 =  document.BenchmarkOverrideForm.SolvencyBenchmark_Agriculture.value;
         localStorage.SolvencyBenchmark_Parastatals                  =  document.BenchmarkOverrideForm.SolvencyBenchmark_Parastatals.value;
         localStorage.SolvencyBenchmark_Transport                   =  document.BenchmarkOverrideForm.SolvencyBenchmark_Transport.value;
         localStorage.SolvencyBenchmark_Mining                      =  document.BenchmarkOverrideForm.SolvencyBenchmark_Mining.value;
         localStorage.SolvencyBenchmark_DateUpdated                 =  document.BenchmarkOverrideForm.SolvencyBenchmark_DateUpdated.value;
         localStorage.SolvencyBenchmarkComment                      =  document.BenchmarkOverrideForm.SolvencyBenchmarkComment.value;
         localStorage.InterestCoverBenchmarkType                    =  document.BenchmarkOverrideForm.InterestCoverBenchmarkType.value;
         localStorage.InterestCoverGlobalAverage                    =  document.BenchmarkOverrideForm.InterestCoverGlobalAverage.value;
         localStorage.InterestCoverBenchmark_Trade                  =  document.BenchmarkOverrideForm.InterestCoverBenchmark_Trade.value;
         localStorage.InterestCoverBenchmark_Finance                =  document.BenchmarkOverrideForm.InterestCoverBenchmark_Finance.value;
         localStorage.InterestCoverBenchmark_RealEstate             =  document.BenchmarkOverrideForm.InterestCoverBenchmark_RealEstate.value;
         localStorage.InterestCoverBenchmark_Manufacturing          =  document.BenchmarkOverrideForm.InterestCoverBenchmark_Manufacturing.value;
         localStorage.InterestCoverBenchmark_Construction           =  document.BenchmarkOverrideForm.InterestCoverBenchmark_Construction.value;
         localStorage.InterestCoverBenchmark_Agriculture            =  document.BenchmarkOverrideForm.InterestCoverBenchmark_Agriculture.value;
         localStorage.InterestCoverBenchmark_Parastatals             =  document.BenchmarkOverrideForm.InterestCoverBenchmark_Parastatals.value;
         localStorage.InterestCoverBenchmark_Transport              =  document.BenchmarkOverrideForm.InterestCoverBenchmark_Transport.value;
         localStorage.InterestCoverBenchmark_Mining                 =  document.BenchmarkOverrideForm.InterestCoverBenchmark_Mining.value;
         localStorage.InterestCoverBenchmark_DateUpdated            =  document.BenchmarkOverrideForm.InterestCoverBenchmark_DateUpdated.value;
         localStorage.InterestCoverBenchmarkComment                 =  document.BenchmarkOverrideForm.InterestCoverBenchmarkComment.value;
         localStorage.EBITDAToDebtBenchmarkType                     =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmarkType.value;
         localStorage.EBITDAToDebtGlobalAverage                     =  document.BenchmarkOverrideForm.EBITDAToDebtGlobalAverage.value;
         localStorage.EBITDAToDebtBenchmark_Trade                   =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmark_Trade.value;
         localStorage.EBITDAToDebtBenchmark_Finance                 =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmark_Finance.value;
         localStorage.EBITDAToDebtBenchmark_RealEstate              =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmark_RealEstate.value;
         localStorage.EBITDAToDebtBenchmark_Manufacturing           =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmark_Manufacturing.value;
         localStorage.EBITDAToDebtBenchmark_Construction            =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmark_Construction.value;
         localStorage.EBITDAToDebtBenchmark_Agriculture             =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmark_Agriculture.value;
         localStorage.EBITDAToDebtBenchmark_Parastatals             =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmark_Parastatals.value;
         localStorage.EBITDAToDebtBenchmark_Transport               =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmark_Transport.value;
         localStorage.EBITDAToDebtBenchmark_Mining                  =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmark_Mining.value;
         localStorage.EBITDAToDebtBenchmark_DateUpdated             =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmark_DateUpdated.value;
         localStorage.EBITDAToDebtBenchmarkComment                  =  document.BenchmarkOverrideForm.EBITDAToDebtBenchmarkComment.value;
         localStorage.TotalAssetsTurnoverBenchmarkType              =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmarkType.value;
         localStorage.TotalAssetsTurnoverGlobalAverage              =  document.BenchmarkOverrideForm.TotalAssetsTurnoverGlobalAverage.value;
         localStorage.TotalAssetsTurnoverBenchmark_Trade            =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmark_Trade.value;
         localStorage.TotalAssetsTurnoverBenchmark_Finance          =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmark_Finance.value;
         localStorage.TotalAssetsTurnoverBenchmark_RealEstate       =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmark_RealEstate.value;
         localStorage.TotalAssetsTurnoverBenchmark_Manufacturing    =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmark_Manufacturing.value;
         localStorage.TotalAssetsTurnoverBenchmark_Construction     =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmark_Construction.value;
         localStorage.TotalAssetsTurnoverBenchmark_Agriculture      =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmark_Agriculture.value;
         localStorage.TotalAssetsTurnoverBenchmark_Parastatals      =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmark_Parastatals.value;
         localStorage.TotalAssetsTurnoverBenchmark_Transport        =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmark_Transport.value;
         localStorage.TotalAssetsTurnoverBenchmark_Mining           =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmark_Mining.value;
         localStorage.TotalAssetsTurnoverBenchmark_DateUpdated      =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmark_DateUpdated.value;
         localStorage.TotalAssetsTurnoverBenchmarkComment           =  document.BenchmarkOverrideForm.TotalAssetsTurnoverBenchmarkComment.value;
         localStorage.FixedlAssetsTurnoverBenchmarkType             =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmarkType.value;
         localStorage.FixedlAssetsTurnoverGlobalAverage             =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverGlobalAverage.value;
         localStorage.FixedlAssetsTurnoverBenchmark_Trade           =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmark_Trade.value;
         localStorage.FixedlAssetsTurnoverBenchmark_Finance         =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmark_Finance.value;
         localStorage.FixedlAssetsTurnoverBenchmark_RealEstate      =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmark_RealEstate.value;
         localStorage.FixedlAssetsTurnoverBenchmark_Manufacturing   =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmark_Manufacturing.value;
         localStorage.FixedlAssetsTurnoverBenchmark_Construction    =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmark_Construction.value;
         localStorage.FixedlAssetsTurnoverBenchmark_Agriculture     =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmark_Agriculture.value;
         localStorage.FixedlAssetsTurnoverBenchmark_Parastatals     =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmark_Parastatals.value;
         localStorage.FixedlAssetsTurnoverBenchmark_Transport       =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmark_Transport.value;
         localStorage.FixedlAssetsTurnoverBenchmark_Mining          =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmark_Mining.value;
         localStorage.FixedlAssetsTurnoverBenchmark_DateUpdated     =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmark_DateUpdated.value;
         localStorage.FixedlAssetsTurnoverBenchmarkComment          =  document.BenchmarkOverrideForm.FixedlAssetsTurnoverBenchmarkComment.value;
	  
	     alert ("Industry benchmarks successfully saved into local storage - now updating database");
}
function ShareholderAnalysisRecalculate()
{   
	   //Set Conditional Formatting for the black-listing and fraud-alert flag
	   var elem = document.getElementById('ShareholderForm').elements;
	   for(var i = 0; i < elem.length; i++)
       {       
		 if (elem[i].value == "Yes") {elem[i].style.backgroundColor = "Red";}
		 if (elem[i].value == "No") {elem[i].style.backgroundColor = "Green";} 
	   }
		/**
		 var TotalScore1 = ToNumber(document.ShareholderForm.ShareholderTotalScore1.value);
		   var TotalScore2 = ToNumber(document.ShareholderForm.ShareholderTotalScore2.value);
		   var TotalScore3 = ToNumber(document.ShareholderForm.ShareholderTotalScore3.value);
	       var TotalScore4 = ToNumber(document.ShareholderForm.ShareholderTotalScore4.value);
	       var TotalScore5 = ToNumber(document.ShareholderForm.ShareholderTotalScore5.value);
	       //Calculate the Grand Total Score
	       var GrandTotalScore = TotalScore1 + TotalScore2 + TotalScore3 + TotalScore4 + TotalScore5;
     
		 var NoOfShareholders = 5;
         
		  //Exclude the blank shareholder fields from the average calculations
		  
		  if      (document.ShareholderForm.ShareholderName1.value =="") 
		  {        NoOfShareholders = NoOfShareholders - 1 ; 
		           GrandTotalScore = GrandTotalScore - TotalScore1;  
	      }
		  if (document.ShareholderForm.ShareholderName2.value =="") 
		  {        NoOfShareholders = NoOfShareholders - 1; 
		           GrandTotalScore = GrandTotalScore - TotalScore2;
				    
		  }
		  if (document.ShareholderForm.ShareholderName3.value =="") 
		  {        NoOfShareholders = NoOfShareholders - 1; GrandTotalScore -= TotalScore3; }
		  if (document.ShareholderForm.ShareholderName4.value =="") 
		  {        NoOfShareholders = NoOfShareholders - 1; GrandTotalScore -= TotalScore4; }
		  if (document.ShareholderForm.ShareholderName5.value =="") 
		  {        NoOfShareholders = NoOfShareholders - 1; GrandTotalScore -= TotalScore5; }
		    document.ShareholderForm.ShareholderAverageScore.value = GrandTotalScore / NoOfShareholders;
	**/	  
}

function ShareholderAnalysisConditionalFormat(elem)
{
           
		   //Apply conditional formating to the Fraud Alerts and Blacklisted Flags and show red background on a "Yes" value
		   if (elem.value == "Yes")
		   {
		     elem.style.backgroundColor = "Red";
		   }
		   else
		   {
		      elem.style.backgroundColor = "Green";
		   }
}
//============================================================================================================================================
function RecalculatePortersForm()
		{
		// Perform conditional formatting for the selected rating
		   //var val = M.value;
		   var IndexOfForceToUpdate = 0;
           var PreviousIndexOfForceToUpdate = 0;
		   var RatingScore = 0;
		   var TempForceTotal = 0;
		   var SelectedIndex = 0;
		   var elem = document.getElementById('PortersForm').elements;
          // var x = 1;
		   
		   // 
		   var GrandTotal = 0;
		   for(var i = 9; i < elem.length; i++)
           {

			   // Get the index of the element on focus and the Total Score input box of each of the five forces based on the element name
			   PreviousIndexOfForceToUpdate = IndexOfForceToUpdate;
			   switch (elem[i].name)
			   {
				   //case M.name:
		           //     SelectedIndex = i;          // Get index of the element on focus  
	               //     break;
				   case "ThreatsOfNewEntryScore": 
				        IndexOfForceToUpdate = i;
						break;
				 
			       case "CompetitiveRivalryScore": 
				        IndexOfForceToUpdate = i;
						break; 
				   case "ThreatsOfSubstitutionScore":
				        IndexOfForceToUpdate = i;
						break; 
				   case "SupplierPowerScore":
				        IndexOfForceToUpdate = i;
						break;
				   case "BuyerPowerScore":
				        IndexOfForceToUpdate = i;
						break;  
	               
			   }
			   
	
			   /** if the element type = select-one then 
			       1. Perform conditional formatting based on the value
				   2. Update the score on the right
				   3. Add the element score to the relevant subtotal using the IndexOfForceToUpdate variable determined with the switch statement above
			   **/
			   RatingScore = 0;
			   if (elem[i].type == 'select-one') 
			      {
				    console.log(i + "= " +elem[i].name);
			   	     switch (elem[i].value) 
				       {
			             case "Low":
			               elem[i].style.backgroundColor = "green";
			               RatingScore = 1;
					
					       break;
			             case "Medium":
			               elem[i].style.backgroundColor = "orange";
			               RatingScore = 0;
					
					       break;  
			             case "High":
			               elem[i].style.backgroundColor = "red";
					       RatingScore = -1;
					
			               break;  
		                  // default:
		                }
				  
					 elem[i+1].value = RatingScore; GrandTotal += RatingScore;
                 
				 
	
				  // add the element score
				//if (isnan(elem[IndexOfForceToUpdate].value))
				//   {elem[IndexOfForceToUpdate-1].value) + alert("not a number")};
				   
			
                //x = parseInt((elem[IndexOfForceToUpdate].value),10) ;
				//alert (elem[i-1].value + x);			
			      }
		          if (PreviousIndexOfForceToUpdate == IndexOfForceToUpdate)
				        {  TempForceTotal += RatingScore;}
				
				  if (PreviousIndexOfForceToUpdate !== IndexOfForceToUpdate)
			     	    {  TempForceTotal = 0;}
			      if (IndexOfForceToUpdate !== 0) {elem[IndexOfForceToUpdate].value = TempForceTotal};
				  
				  //Update the force ratings and perform conditional formating
				  if (IndexOfForceToUpdate !== 0)
				  {
					if   (TempForceTotal==0)
		            {
                      elem[IndexOfForceToUpdate-1].style.backgroundColor = "orange"
			          elem[IndexOfForceToUpdate-1].value = "Medium";
			
			        }
		            if (TempForceTotal >0)
		            {		   
		              elem[IndexOfForceToUpdate-1].style.backgroundColor = "green"
			          elem[IndexOfForceToUpdate-1].value = "Low";
					
			    	}	
		            if (TempForceTotal <0)
		            {
				      elem[IndexOfForceToUpdate-1].style.backgroundColor = "red"
					  elem[IndexOfForceToUpdate-1].value = "High";
			        }
		    	  }
		    } 
		   
		// Update grand Summary rating and summary score
		   document.forms["PortersForm"]["SummaryScore"].value =  GrandTotal;
		   
		   if   (GrandTotal==0)
		        {
                    document.forms["PortersForm"]["SummaryRating"].style.backgroundColor = "orange"
			        document.forms["PortersForm"]["SummaryRating"].value = "Medium";
			
			    }
		   if (GrandTotal >0)
		        {		   
		            document.forms["PortersForm"]["SummaryRating"].style.backgroundColor = "green"
			        document.forms["PortersForm"]["SummaryRating"].value = "Low";
					
				}	
		   if (GrandTotal <0)
		        {
				    document.forms["PortersForm"]["SummaryRating"].style.backgroundColor = "red"
					document.forms["PortersForm"]["SummaryRating"].value = "High";
			    }
		    		
}
	   
function ResetPortersFormValues()
       {
		   // Perform conditional formatting for the selected rating
		   var IndexOfForceToUpdate = 0;
           var PreviousIndexOfForceToUpdate = 0;
		   
		   var elem = document.getElementById('PortersForm').elements;
         
		   
		   // 
		   
		   for(var i = 0; i < elem.length; i++)
           {

			   // Get the index of the element on focus and the Total Score input box of each of the five forces based on the element name
			   PreviousIndexOfForceToUpdate = IndexOfForceToUpdate;
			   switch (elem[i].name)
			   {
		
				   case "ThreatsOfNewEntryScore": 
				        IndexOfForceToUpdate = i;
						break;
				 
			       case "CompetitiveRivalryScore": 
				        IndexOfForceToUpdate = i;
						break; 
				   case "ThreatsOfSubstitutionScore":
				        IndexOfForceToUpdate = i;
						break; 
				   case "SupplierPowerScore":
				        IndexOfForceToUpdate = i;
						break;
				   case "BuyerPowerScore":
				        IndexOfForceToUpdate = i;
						break;  
	               
			   } //end of switch
			   
	
			   /** if the element type = select-one then 
			       1. Perform conditional formatting based on the value
				   2. Update the score on the right
				   3. Add the element score to the relevant subtotal using the IndexOfForceToUpdate variable determined with the switch statement above
			   **/
			  
			   if (elem[i].type == 'select-one') 
			      {
				    if (elem[i].id !== "skip")
					{
				       //Reset select-one values to medium with orange background-color
				       elem[i].value = "Medium"; elem[i].style.backgroundColor = "orange";
				       //Reset individual score to 0
					   elem[i+1].value = 0;
				      //Reset force totals to 0, medium and orange background-color
					   elem[IndexOfForceToUpdate].value = 0;
				       elem[IndexOfForceToUpdate-1].style.backgroundColor = "orange";
			           elem[IndexOfForceToUpdate-1].value = "Medium";
					}
			      }
		    } //end of for loop
		   
		    // Reset grand Summary rating and summary score to Medium and 0 respectively
		    document.forms["PortersForm"]["SummaryScore"].value =  0;
		    document.forms["PortersForm"]["SummaryRating"].style.backgroundColor = "orange";
		    document.forms["PortersForm"]["SummaryRating"].value = "Medium";		
}
//===========================================================================================================================================================================
function ProgressTrackerForm_LoadData()
{
   document.ProgressTrackerForm.CompanyDataTrackerDateSaved.value =  localStorage.CompanyDataTrackerDateSaved;
   document.ProgressTrackerForm.CompanyDataTrackerSavedBy.value =  localStorage.CompanyDataTrackerSavedBy;
   document.ProgressTrackerForm.CompanyDataTracker1stReviewDate.value =  localStorage.CompanyDataTracker1stReviewDate;
   document.ProgressTrackerForm.CompanyDataTracker1stReviewer.value =  localStorage.CompanyDataTracker1stReviewer;
   document.ProgressTrackerForm.CompanyDataTracker2ndReviewDate.value =  localStorage.CompanyDataTracker2ndReviewDate;
   document.ProgressTrackerForm.CompanyDataTracker2ndReviewer.value =  localStorage.CompanyDataTracker2ndReviewer;
   document.ProgressTrackerForm.CompanyDataTracker1stReviewComment.value =  localStorage.CompanyDataTracker1stReviewComment;
   document.ProgressTrackerForm.CompanyDataTracker2ndReviewComment.value =  localStorage.CompanyDataTracker2ndReviewComment;
   document.ProgressTrackerForm.LoanDataTrackerDateSaved.value =  localStorage.LoanDataTrackerDateSaved;
   document.ProgressTrackerForm.LoanDataTrackerSavedBy.value =  localStorage.LoanDataTrackerSavedBy;
   document.ProgressTrackerForm.LoanDataTracker1stReviewDate.value =  localStorage.LoanDataTracker1stReviewDate;
   document.ProgressTrackerForm.LoanDataTracker1stReviewer.value =  localStorage.LoanDataTracker1stReviewer;
   document.ProgressTrackerForm.LoanDataTracker2ndReviewDate.value =  localStorage.LoanDataTracker2ndReviewDate;
   document.ProgressTrackerForm.LoanDataTracker2ndReviewer.value =  localStorage.LoanDataTracker2ndReviewer;
   document.ProgressTrackerForm.LoanDataTracker1stReviewComment.value =  localStorage.LoanDataTracker1stReviewComment;
   document.ProgressTrackerForm.LoanDataTracker2ndReviewComment.value =  localStorage.LoanDataTracker2ndReviewComment;
   document.ProgressTrackerForm.IncomeStatementTrackerDateSaved.value =  localStorage.IncomeStatementTrackerDateSaved;
   document.ProgressTrackerForm.IncomeStatementTrackerSavedBy.value =  localStorage.IncomeStatementTrackerSavedBy;
   document.ProgressTrackerForm.IncomeStatementTracker1stReviewDate.value =  localStorage.IncomeStatementTracker1stReviewDate;
   document.ProgressTrackerForm.IncomeStatementTracker1stReviewer.value =  localStorage.IncomeStatementTracker1stReviewer;
   document.ProgressTrackerForm.IncomeStatementTracker2ndReviewDate.value =  localStorage.IncomeStatementTracker2ndReviewDate;
   document.ProgressTrackerForm.IncomeStatementTracker2ndReviewer.value =  localStorage.IncomeStatementTracker2ndReviewer;
   document.ProgressTrackerForm.IncomeStatementTracker1stReviewComment.value =  localStorage.IncomeStatementTracker1stReviewComment;
   document.ProgressTrackerForm.IncomeStatementTracker2ndReviewComment.value =  localStorage.IncomeStatementTracker2ndReviewComment;
   document.ProgressTrackerForm.CurrentAssetsTrackerDateSaved.value =  localStorage.CurrentAssetsTrackerDateSaved;
   document.ProgressTrackerForm.CurrentAssetsTrackerSavedBy.value =  localStorage.CurrentAssetsTrackerSavedBy;
   document.ProgressTrackerForm.CurrentAssetsTracker1stReviewDate.value =  localStorage.CurrentAssetsTracker1stReviewDate;
   document.ProgressTrackerForm.CurrentAssetsTracker1stReviewer.value =  localStorage.CurrentAssetsTracker1stReviewer;
   document.ProgressTrackerForm.CurrentAssetsTracker2ndReviewDate.value =  localStorage.CurrentAssetsTracker2ndReviewDate;
   document.ProgressTrackerForm.CurrentAssetsTracker2ndReviewer.value =  localStorage.CurrentAssetsTracker2ndReviewer;
   document.ProgressTrackerForm.CurrentAssetsTracker1stReviewComment.value =  localStorage.CurrentAssetsTracker1stReviewComment;
   document.ProgressTrackerForm.CurrentAssetsTracker2ndReviewComment.value =  localStorage.CurrentAssetsTracker2ndReviewComment;
   document.ProgressTrackerForm.NonCurrentAssetsTrackerDateSaved.value =  localStorage.NonCurrentAssetsTrackerDateSaved;
   document.ProgressTrackerForm.NonCurrentAssetsTrackerSavedBy.value =  localStorage.NonCurrentAssetsTrackerSavedBy;
   document.ProgressTrackerForm.NonCurrentAssetsTracker1stReviewDate.value =  localStorage.NonCurrentAssetsTracker1stReviewDate;
   document.ProgressTrackerForm.NonCurrentAssetsTracker1stReviewer.value =  localStorage.NonCurrentAssetsTracker1stReviewer;
   document.ProgressTrackerForm.NonCurrentAssetsTracker2ndReviewDate.value =  localStorage.NonCurrentAssetsTracker2ndReviewDate;
   document.ProgressTrackerForm.NonCurrentAssetsTracker2ndReviewer.value =  localStorage.NonCurrentAssetsTracker2ndReviewer;
   document.ProgressTrackerForm.NonCurrentAssetsTracker1stReviewComment.value =  localStorage.NonCurrentAssetsTracker1stReviewComment;
   document.ProgressTrackerForm.NonCurrentAssetsTracker2ndReviewComment.value =  localStorage.NonCurrentAssetsTracker2ndReviewComment;
   document.ProgressTrackerForm.CurrentLiabilitiesTrackerDateSaved.value =  localStorage.CurrentLiabilitiesTrackerDateSaved;
   document.ProgressTrackerForm.CurrentLiabilitiesTrackerSavedBy.value =  localStorage.CurrentLiabilitiesTrackerSavedBy;
   document.ProgressTrackerForm.CurrentLiabilitiesTracker1stReviewDate.value =  localStorage.CurrentLiabilitiesTracker1stReviewDate;
   document.ProgressTrackerForm.CurrentLiabilitiesTracker1stReviewer.value =  localStorage.CurrentLiabilitiesTracker1stReviewer;
   document.ProgressTrackerForm.CurrentLiabilitiesTracker2ndReviewDate.value =  localStorage.CurrentLiabilitiesTracker2ndReviewDate;
   document.ProgressTrackerForm.CurrentLiabilitiesTracker2ndReviewer.value =  localStorage.CurrentLiabilitiesTracker2ndReviewer;
   document.ProgressTrackerForm.CurrentLiabilitiesTracker1stReviewComment.value =  localStorage.CurrentLiabilitiesTracker1stReviewComment;
   document.ProgressTrackerForm.CurrentLiabilitiesTracker2ndReviewComment.value =  localStorage.CurrentLiabilitiesTracker2ndReviewComment;
   document.ProgressTrackerForm.NonCurrentLiabilitiesTrackerDateSaved.value =  localStorage.NonCurrentLiabilitiesTrackerDateSaved;
   document.ProgressTrackerForm.NonCurrentLiabilitiesTrackerSavedBy.value =  localStorage.NonCurrentLiabilitiesTrackerSavedBy;
   document.ProgressTrackerForm.NonCurrentLiabilitiesTracker1stReviewDate.value =  localStorage.NonCurrentLiabilitiesTracker1stReviewDate;
   document.ProgressTrackerForm.NonCurrentLiabilitiesTracker1stReviewer.value =  localStorage.NonCurrentLiabilitiesTracker1stReviewer;
   document.ProgressTrackerForm.NonCurrentLiabilitiesTracker2ndReviewDate.value =  localStorage.NonCurrentLiabilitiesTracker2ndReviewDate;
   document.ProgressTrackerForm.NonCurrentLiabilitiesTracker2ndReviewer.value =  localStorage.NonCurrentLiabilitiesTracker2ndReviewer;
   document.ProgressTrackerForm.NonCurrentLiabilitiesTracker1stReviewComment.value =  localStorage.NonCurrentLiabilitiesTracker1stReviewComment;
   document.ProgressTrackerForm.NonCurrentLiabilitiesTracker2ndReviewComment.value =  localStorage.NonCurrentLiabilitiesTracker2ndReviewComment;
   document.ProgressTrackerForm.EquityTrackerDateSaved.value =  localStorage.EquityTrackerDateSaved;
   document.ProgressTrackerForm.EquityTrackerSavedBy.value =  localStorage.EquityTrackerSavedBy;
   document.ProgressTrackerForm.EquityTracker1stReviewDate.value =  localStorage.EquityTracker1stReviewDate;
   document.ProgressTrackerForm.EquityTracker1stReviewer.value =  localStorage.EquityTracker1stReviewer;
   document.ProgressTrackerForm.EquityTracker2ndReviewDate.value =  localStorage.EquityTracker2ndReviewDate;
   document.ProgressTrackerForm.EquityTracker2ndReviewer.value =  localStorage.EquityTracker2ndReviewer;
   document.ProgressTrackerForm.EquityTracker1stReviewComment.value =  localStorage.EquityTracker1stReviewComment;
   document.ProgressTrackerForm.EquityTracker2ndReviewComment.value =  localStorage.EquityTracker2ndReviewComment;
   document.ProgressTrackerForm.ManagementAnalysisTrackerDateSaved.value =  localStorage.ManagementAnalysisTrackerDateSaved;
   document.ProgressTrackerForm.ManagementAnalysisTrackerSavedBy.value =  localStorage.ManagementAnalysisTrackerSavedBy;
   document.ProgressTrackerForm.ManagementAnalysisTracker1stReviewDate.value =  localStorage.ManagementAnalysisTracker1stReviewDate;
   document.ProgressTrackerForm.ManagementAnalysisTracker1stReviewer.value =  localStorage.ManagementAnalysisTracker1stReviewer;
   document.ProgressTrackerForm.ManagementAnalysisTracker2ndReviewDate.value =  localStorage.ManagementAnalysisTracker2ndReviewDate;
   document.ProgressTrackerForm.ManagementAnalysisTracker2ndReviewer.value =  localStorage.ManagementAnalysisTracker2ndReviewer;
   document.ProgressTrackerForm.ManagementAnalysisTracker1stReviewComment.value =  localStorage.ManagementAnalysisTracker1stReviewComment;
   document.ProgressTrackerForm.ManagementAnalysisTracker2ndReviewComment.value =  localStorage.ManagementAnalysisTracker2ndReviewComment;
   document.ProgressTrackerForm.IndustryAnalysisTrackerDateSaved.value =  localStorage.IndustryAnalysisTrackerDateSaved;
   document.ProgressTrackerForm.IndustryAnalysisTrackerSavedBy.value =  localStorage.IndustryAnalysisTrackerSavedBy;
   document.ProgressTrackerForm.IndustryAnalysisTracker1stReviewDate.value =  localStorage.IndustryAnalysisTracker1stReviewDate;
   document.ProgressTrackerForm.IndustryAnalysisTracker1stReviewer.value =  localStorage.IndustryAnalysisTracker1stReviewer;
   document.ProgressTrackerForm.IndustryAnalysisTracker2ndReviewDate.value =  localStorage.IndustryAnalysisTracker2ndReviewDate;
   document.ProgressTrackerForm.IndustryAnalysisTracker2ndReviewer.value =  localStorage.IndustryAnalysisTracker2ndReviewer;
   document.ProgressTrackerForm.IndustryAnalysisTracker1stReviewComment.value =  localStorage.IndustryAnalysisTracker1stReviewComment;
   document.ProgressTrackerForm.IndustryAnalysisTracker2ndReviewComment.value =  localStorage.IndustryAnalysisTracker2ndReviewComment;
   document.ProgressTrackerForm.ShareholderAnalysisTrackerDateSaved.value =  localStorage.ShareholderAnalysisTrackerDateSaved;
   document.ProgressTrackerForm.ShareholderAnalysisTrackerSavedBy.value =  localStorage.ShareholderAnalysisTrackerSavedBy;
   document.ProgressTrackerForm.ShareholderAnalysisTracker1stReviewDate.value =  localStorage.ShareholderAnalysisTracker1stReviewDate;
   document.ProgressTrackerForm.ShareholderAnalysisTracker1stReviewer.value =  localStorage.ShareholderAnalysisTracker1stReviewer;
   document.ProgressTrackerForm.ShareholderAnalysisTracker2ndReviewDate.value =  localStorage.ShareholderAnalysisTracker2ndReviewDate;
   document.ProgressTrackerForm.ShareholderAnalysisTracker2ndReviewer.value =  localStorage.ShareholderAnalysisTracker2ndReviewer;
   document.ProgressTrackerForm.ShareholderAnalysisTracker1stReviewComment.value =  localStorage.ShareholderAnalysisTracker1stReviewComment;
   document.ProgressTrackerForm.ShareholderAnalysisTracker2ndReviewComment.value =  localStorage.ShareholderAnalysisTracker2ndReviewComment;
   document.ProgressTrackerForm.BehavioralAnalysisTrackerDateSaved.value =  localStorage.BehavioralAnalysisTrackerDateSaved;
   document.ProgressTrackerForm.BehavioralAnalysisTrackerSavedBy.value =  localStorage.BehavioralAnalysisTrackerSavedBy;
   document.ProgressTrackerForm.BehavioralAnalysisTracker1stReviewDate.value =  localStorage.BehavioralAnalysisTracker1stReviewDate;
   document.ProgressTrackerForm.BehavioralAnalysisTracker1stReviewer.value =  localStorage.BehavioralAnalysisTracker1stReviewer;
   document.ProgressTrackerForm.BehavioralAnalysisTracker2ndReviewDate.value =  localStorage.BehavioralAnalysisTracker2ndReviewDate;
   document.ProgressTrackerForm.BehavioralAnalysisTracker2ndReviewer.value =  localStorage.BehavioralAnalysisTracker2ndReviewer;
   document.ProgressTrackerForm.BehavioralAnalysisTracker1stReviewComment.value =  localStorage.BehavioralAnalysisTracker1stReviewComment;
   document.ProgressTrackerForm.BehavioralAnalysisTracker2ndReviewComment.value =  localStorage.BehavioralAnalysisTracker2ndReviewComment;
   document.ProgressTrackerForm.IndustryBenchmarksOverridesTrackerDateSaved.value =  localStorage.IndustryBenchmarksOverridesTrackerDateSaved;
   document.ProgressTrackerForm.IndustryBenchmarksOverridesTrackerSavedBy.value =  localStorage.IndustryBenchmarksOverridesTrackerSavedBy;
   document.ProgressTrackerForm.IndustryBenchmarksOverridesTracker1stReviewDate.value =  localStorage.IndustryBenchmarksOverridesTracker1stReviewDate;
   document.ProgressTrackerForm.IndustryBenchmarksOverridesTracker1stReviewer.value =  localStorage.IndustryBenchmarksOverridesTracker1stReviewer;
   document.ProgressTrackerForm.IndustryBenchmarksOverridesTracker2ndReviewDate.value =  localStorage.IndustryBenchmarksOverridesTracker2ndReviewDate;
   document.ProgressTrackerForm.IndustryBenchmarksOverridesTracker2ndReviewer.value =  localStorage.IndustryBenchmarksOverridesTracker2ndReviewer;
   document.ProgressTrackerForm.IndustryBenchmarksOverridesTracker1stReviewComment.value =  localStorage.IndustryBenchmarksOverridesTracker1stReviewComment;
   document.ProgressTrackerForm.IndustryBenchmarksOverridesTracker2ndReviewComment.value =  localStorage.IndustryBenchmarksOverridesTracker2ndReviewComment;
}
